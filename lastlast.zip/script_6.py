# UPDATED MOBILE ORDERING COMPONENT - components/mobile/WaiterOrderTaking.js
mobile_ordering_updated_js = '''
// components/mobile/WaiterOrderTaking.js - UPDATED FOR ENHANCED BILLING INTEGRATION
import React, { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import toast from 'react-hot-toast';

const WaiterOrderTaking = () => {
    const { user } = useAuth();
    const [tables, setTables] = useState([]);
    const [selectedTable, setSelectedTable] = useState(null);
    const [menuItems, setMenuItems] = useState([]);
    const [cart, setCart] = useState([]);
    const [customerInfo, setCustomerInfo] = useState({
        name: 'Guest',
        phone: '',
        count: 1
    });
    const [categories, setCategories] = useState([]);
    const [selectedCategory, setSelectedCategory] = useState('all');
    const [loading, setLoading] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        fetchTables();
        fetchMenu();
    }, []);

    const fetchTables = async () => {
        try {
            const response = await fetch('/api/tables/', {
                headers: { Authorization: `Bearer ${user.access}` }
            });
            const data = await response.json();
            
            // Filter to show available and occupied tables
            const availableTables = data.filter(table => 
                table.is_active && ['available', 'occupied'].includes(table.status)
            );
            
            setTables(availableTables);
        } catch (error) {
            console.error('Error fetching tables:', error);
            toast.error('Failed to load tables');
        }
    };

    const fetchMenu = async () => {
        try {
            const response = await fetch('/api/menu/items/', {
                headers: { Authorization: `Bearer ${user.access}` }
            });
            const data = await response.json();
            const availableItems = data.results || data;
            
            // Only show available items
            const filteredItems = availableItems.filter(item => item.available);
            setMenuItems(filteredItems);

            // Extract unique categories
            const uniqueCategories = [...new Set(
                filteredItems.map(item => item.category?.name_en).filter(Boolean)
            )];
            setCategories(uniqueCategories);
        } catch (error) {
            console.error('Error fetching menu:', error);
            toast.error('Failed to load menu');
        }
    };

    const addToCart = (menuItem) => {
        const existingItem = cart.find(item => item.id === menuItem.id);
        if (existingItem) {
            setCart(cart.map(item => 
                item.id === menuItem.id 
                    ? { ...item, quantity: item.quantity + 1 }
                    : item
            ));
        } else {
            setCart([...cart, { ...menuItem, quantity: 1, special_instructions: '' }]);
        }
        
        // Visual feedback
        toast.success(`Added ${menuItem.name_en} to cart`);
    };

    const removeFromCart = (itemId) => {
        setCart(cart.filter(item => item.id !== itemId));
    };

    const updateQuantity = (itemId, quantity) => {
        if (quantity === 0) {
            removeFromCart(itemId);
        } else {
            setCart(cart.map(item => 
                item.id === itemId ? { ...item, quantity } : item
            ));
        }
    };

    const updateSpecialInstructions = (itemId, instructions) => {
        setCart(cart.map(item => 
            item.id === itemId ? { ...item, special_instructions: instructions } : item
        ));
    };

    const calculateTotal = () => {
        return cart.reduce((total, item) => total + (item.price * item.quantity), 0);
    };

    const submitOrder = async () => {
        if (!selectedTable || cart.length === 0) {
            toast.error('Please select a table and add items to cart');
            return;
        }

        if (customerInfo.count < 1) {
            toast.error('Customer count must be at least 1');
            return;
        }

        setLoading(true);
        
        try {
            // Prepare order data with enhanced billing integration
            const orderData = {
                table_id: selectedTable.id,
                customer_name: customerInfo.name,
                customer_phone: customerInfo.phone,
                customer_count: parseInt(customerInfo.count),
                special_instructions: cart.some(item => item.special_instructions) 
                    ? cart.filter(item => item.special_instructions)
                           .map(item => `${item.name_en}: ${item.special_instructions}`)
                           .join('; ')
                    : '',
                items: cart.map(item => ({
                    menu_item_id: item.id,
                    quantity: item.quantity,
                    price: item.price,  // Lock in current price
                    special_instructions: item.special_instructions || ''
                })),
                // Enhanced billing integration flags
                add_to_enhanced_billing: true,
                waiter_id: user.id
            };

            console.log('Submitting order:', orderData);

            const response = await fetch('/api/tables/create_order/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${user.access}`
                },
                body: JSON.stringify(orderData)
            });

            const result = await response.json();
            console.log('Order response:', result);

            if (response.ok && result.success) {
                // Success - order sent to kitchen and added to enhanced billing
                toast.success(
                    `Order ${result.order_number} sent to kitchen!\\n` +
                    `Table ${selectedTable.table_number} is now occupied.\\n` +
                    `Order added to Enhanced Billing dashboard.`,
                    { duration: 5000 }
                );
                
                // Show order summary
                const orderSummary = cart.map(item => 
                    `${item.name_en} x ${item.quantity}`
                ).join(', ');
                
                toast.success(
                    `Items: ${orderSummary}\\n` +
                    `Total: ₹${calculateTotal().toFixed(2)}`,
                    { duration: 4000 }
                );
                
                // Clear form
                setCart([]);
                setSelectedTable(null);
                setCustomerInfo({ name: 'Guest', phone: '', count: 1 });
                
                // Refresh tables to show updated status
                fetchTables();
                
            } else {
                throw new Error(result.error || result.message || 'Unknown error');
            }
        } catch (error) {
            console.error('Error submitting order:', error);
            toast.error(`Failed to submit order: ${error.message}`);
        } finally {
            setLoading(false);
        }
    };

    const filteredMenuItems = React.useMemo(() => {
        let filtered = selectedCategory === 'all' 
            ? menuItems 
            : menuItems.filter(item => item.category?.name_en === selectedCategory);
        
        if (searchTerm) {
            filtered = filtered.filter(item => 
                item.name_en.toLowerCase().includes(searchTerm.toLowerCase()) ||
                item.name_hi.toLowerCase().includes(searchTerm.toLowerCase())
            );
        }
        
        return filtered;
    }, [menuItems, selectedCategory, searchTerm]);

    const getTableStatusColor = (tableStatus) => {
        switch(tableStatus) {
            case 'available': return 'bg-green-100 text-green-800 border-green-300';
            case 'occupied': return 'bg-red-100 text-red-800 border-red-300';
            case 'reserved': return 'bg-yellow-100 text-yellow-800 border-yellow-300';
            default: return 'bg-gray-100 text-gray-800 border-gray-300';
        }
    };

    return (
        <div className="min-h-screen bg-gray-50 p-4">
            {/* Header */}
            <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
                <h1 className="text-2xl font-bold text-gray-900 mb-2">
                    📱 Mobile Order Taking
                </h1>
                <p className="text-gray-600">
                    Select table → Add items → Send to kitchen & enhanced billing
                </p>
                
                {selectedTable && (
                    <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                        <p className="text-sm text-blue-800">
                            <strong>Selected:</strong> Table {selectedTable.table_number} 
                            (Capacity: {selectedTable.capacity}, Status: {selectedTable.status})
                        </p>
                    </div>
                )}
            </div>

            {/* Table Selection */}
            {!selectedTable && (
                <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
                    <h2 className="text-xl font-semibold mb-4 flex items-center">
                        🪑 Select Table
                    </h2>
                    
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                        {tables.map(table => (
                            <button
                                key={table.id}
                                onClick={() => setSelectedTable(table)}
                                className={`p-4 rounded-lg border-2 transition-all ${getTableStatusColor(table.status)} hover:shadow-md active:scale-95`}
                                disabled={table.status === 'maintenance'}
                            >
                                <div className="text-lg font-bold">T{table.table_number}</div>
                                <div className="text-xs capitalize">{table.status}</div>
                                <div className="text-xs">Cap: {table.capacity}</div>
                            </button>
                        ))}
                    </div>
                    
                    <div className="mt-4 flex gap-4 text-xs">
                        <span className="flex items-center gap-1">
                            <div className="w-3 h-3 bg-green-200 rounded"></div>
                            Available
                        </span>
                        <span className="flex items-center gap-1">
                            <div className="w-3 h-3 bg-red-200 rounded"></div>
                            Occupied
                        </span>
                        <span className="flex items-center gap-1">
                            <div className="w-3 h-3 bg-yellow-200 rounded"></div>
                            Reserved
                        </span>
                    </div>
                </div>
            )}

            {/* Order Taking Interface */}
            {selectedTable && (
                <div className="space-y-6">
                    {/* Selected Table Info */}
                    <div className="bg-white rounded-lg shadow-sm p-6">
                        <div className="flex justify-between items-center">
                            <div>
                                <h2 className="text-xl font-semibold">
                                    Table {selectedTable.table_number}
                                </h2>
                                <p className="text-gray-600">
                                    Capacity: {selectedTable.capacity} | Status: {selectedTable.status}
                                </p>
                            </div>
                            <button
                                onClick={() => setSelectedTable(null)}
                                className="px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg transition"
                            >
                                Change Table
                            </button>
                        </div>
                    </div>

                    {/* Customer Information */}
                    <div className="bg-white rounded-lg shadow-sm p-6">
                        <h3 className="text-lg font-semibold mb-4">👥 Customer Information</h3>
                        
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">
                                    Customer Name
                                </label>
                                <input
                                    type="text"
                                    value={customerInfo.name}
                                    onChange={(e) => setCustomerInfo({...customerInfo, name: e.target.value})}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                    placeholder="Enter customer name"
                                />
                            </div>
                            
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">
                                    Phone Number
                                </label>
                                <input
                                    type="tel"
                                    value={customerInfo.phone}
                                    onChange={(e) => setCustomerInfo({...customerInfo, phone: e.target.value})}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                    placeholder="Phone number (optional)"
                                />
                            </div>
                            
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">
                                    Number of Guests
                                </label>
                                <input
                                    type="number"
                                    value={customerInfo.count}
                                    onChange={(e) => setCustomerInfo({...customerInfo, count: parseInt(e.target.value) || 1})}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                    min="1"
                                    max={selectedTable.capacity}
                                />
                            </div>
                        </div>
                    </div>

                    {/* Menu Search and Categories */}
                    <div className="bg-white rounded-lg shadow-sm p-6">
                        <div className="flex flex-col sm:flex-row gap-4 mb-4">
                            <div className="flex-1">
                                <input
                                    type="text"
                                    placeholder="Search menu items..."
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                />
                            </div>
                            
                            <div className="flex gap-2 flex-wrap">
                                <button
                                    onClick={() => setSelectedCategory('all')}
                                    className={`px-4 py-2 rounded-lg transition ${
                                        selectedCategory === 'all'
                                            ? 'bg-blue-600 text-white'
                                            : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                                    }`}
                                >
                                    All Items
                                </button>
                                
                                {categories.map(category => (
                                    <button
                                        key={category}
                                        onClick={() => setSelectedCategory(category)}
                                        className={`px-4 py-2 rounded-lg transition ${
                                            selectedCategory === category
                                                ? 'bg-blue-600 text-white'
                                                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                                        }`}
                                    >
                                        {category}
                                    </button>
                                ))}
                            </div>
                        </div>

                        {/* Menu Items Grid */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                            {filteredMenuItems.map(item => (
                                <div key={item.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition">
                                    <div className="flex justify-between items-start mb-2">
                                        <div className="flex-1">
                                            <h4 className="font-semibold text-gray-900">{item.name_en}</h4>
                                            {item.name_hi && (
                                                <p className="text-sm text-gray-600">{item.name_hi}</p>
                                            )}
                                            {item.description_en && (
                                                <p className="text-xs text-gray-500 mt-1">{item.description_en}</p>
                                            )}
                                        </div>
                                        <div className="text-right ml-4">
                                            <p className="font-bold text-green-600">₹{item.price}</p>
                                        </div>
                                    </div>
                                    
                                    <button
                                        onClick={() => addToCart(item)}
                                        className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 active:scale-95 transition font-medium"
                                    >
                                        Add to Cart
                                    </button>
                                </div>
                            ))}
                        </div>

                        {filteredMenuItems.length === 0 && (
                            <div className="text-center py-8 text-gray-500">
                                {searchTerm ? 'No items found matching your search' : 'No items available in this category'}
                            </div>
                        )}
                    </div>

                    {/* Cart Summary */}
                    {cart.length > 0 && (
                        <div className="bg-white rounded-lg shadow-sm p-6">
                            <h3 className="text-lg font-semibold mb-4 flex items-center">
                                🛒 Order Summary ({cart.length} items)
                            </h3>
                            
                            <div className="space-y-4 mb-6">
                                {cart.map(item => (
                                    <div key={item.id} className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg">
                                        <div className="flex-1">
                                            <h4 className="font-medium">{item.name_en}</h4>
                                            <div className="flex items-center gap-3 mt-2">
                                                <div className="flex items-center gap-2">
                                                    <button
                                                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                                                        className="w-8 h-8 bg-red-100 text-red-600 rounded-full hover:bg-red-200 transition"
                                                    >
                                                        -
                                                    </button>
                                                    <span className="w-8 text-center font-medium">{item.quantity}</span>
                                                    <button
                                                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                                                        className="w-8 h-8 bg-green-100 text-green-600 rounded-full hover:bg-green-200 transition"
                                                    >
                                                        +
                                                    </button>
                                                </div>
                                                <span className="text-lg font-semibold text-green-600">
                                                    ₹{(item.price * item.quantity).toFixed(2)}
                                                </span>
                                            </div>
                                            
                                            <input
                                                type="text"
                                                placeholder="Special instructions (optional)"
                                                value={item.special_instructions}
                                                onChange={(e) => updateSpecialInstructions(item.id, e.target.value)}
                                                className="mt-2 w-full px-3 py-1 text-sm border border-gray-300 rounded focus:ring-1 focus:ring-blue-500"
                                            />
                                        </div>
                                        
                                        <button
                                            onClick={() => removeFromCart(item.id)}
                                            className="text-red-500 hover:text-red-700 font-bold"
                                        >
                                            ✕
                                        </button>
                                    </div>
                                ))}
                            </div>

                            <div className="border-t pt-4">
                                <div className="flex justify-between items-center text-xl font-bold mb-4">
                                    <span>Total:</span>
                                    <span className="text-green-600">₹{calculateTotal().toFixed(2)}</span>
                                </div>

                                <button
                                    onClick={submitOrder}
                                    disabled={loading}
                                    className={`w-full py-4 px-6 rounded-lg font-semibold text-lg transition ${
                                        loading
                                            ? 'bg-gray-400 cursor-not-allowed'
                                            : 'bg-green-600 hover:bg-green-700 active:scale-95'
                                    } text-white`}
                                >
                                    {loading ? (
                                        <span className="flex items-center justify-center">
                                            <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                            </svg>
                                            Sending to Kitchen...
                                        </span>
                                    ) : (
                                        '🍴 Send to Kitchen & Enhanced Billing'
                                    )}
                                </button>
                                
                                <p className="text-sm text-gray-600 text-center mt-2">
                                    Order will be sent to kitchen and appear in Enhanced Billing dashboard
                                </p>
                            </div>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
};

export default WaiterOrderTaking;
'''

with open('mobile_ordering_updated.js', 'w') as f:
    f.write(mobile_ordering_updated_js)

print("✅ Created updated mobile ordering component with enhanced billing integration")
print("File saved: mobile_ordering_updated.js")