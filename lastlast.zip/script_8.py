# UPDATED STAFF MANAGEMENT COMPONENT - components/staff/StaffManagement.js
staff_management_updated_js = '''
// components/staff/StaffManagement.js - COMPLETELY UPDATED FOR SEPARATE STAFF DATA
import React, { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import toast from 'react-hot-toast';

const StaffManagement = () => {
    const { user } = useAuth();
    const [staffProfiles, setStaffProfiles] = useState([]);
    const [attendanceRecords, setAttendanceRecords] = useState([]);
    const [payrollRecords, setPayrollRecords] = useState([]);
    const [leaveRequests, setLeaveRequests] = useState([]);
    const [selectedStaff, setSelectedStaff] = useState(null);
    const [activeTab, setActiveTab] = useState('profiles');
    const [currentMonth, setCurrentMonth] = useState(new Date().getMonth() + 1);
    const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
    const [loading, setLoading] = useState(false);

    // Add Staff Modal State
    const [showAddStaffModal, setShowAddStaffModal] = useState(false);
    const [newStaffData, setNewStaffData] = useState({
        full_name: '',
        phone: '',
        address: '',
        department: 'service',
        position: '',
        hire_date: new Date().toISOString().split('T')[0],
        base_salary: '',
        hourly_rate: '',
        emergency_contact: '',
        emergency_phone: '',
        notes: ''
    });

    // Attendance Marking Modal
    const [showAttendanceModal, setShowAttendanceModal] = useState(false);
    const [attendanceData, setAttendanceData] = useState({
        staff_id: null,
        date: new Date().toISOString().split('T')[0],
        status: 'present',
        check_in: '',
        check_out: '',
        notes: ''
    });

    useEffect(() => {
        fetchStaffProfiles();
        fetchAttendanceRecords();
        fetchPayrollRecords();
        fetchLeaveRequests();
    }, [currentMonth, currentYear]);

    const fetchStaffProfiles = async () => {
        try {
            const response = await fetch('/api/staff/profiles/', {
                headers: { Authorization: `Bearer ${user.access}` }
            });
            const data = await response.json();
            setStaffProfiles(data.results || data);
        } catch (error) {
            console.error('Error fetching staff profiles:', error);
            toast.error('Failed to load staff profiles');
        }
    };

    const fetchAttendanceRecords = async () => {
        try {
            const response = await fetch(`/api/staff/attendance/?month=${currentMonth}&year=${currentYear}`, {
                headers: { Authorization: `Bearer ${user.access}` }
            });
            const data = await response.json();
            setAttendanceRecords(data.results || data);
        } catch (error) {
            console.error('Error fetching attendance:', error);
        }
    };

    const fetchPayrollRecords = async () => {
        try {
            const response = await fetch(`/api/staff/payroll/?month=${currentMonth}&year=${currentYear}`, {
                headers: { Authorization: `Bearer ${user.access}` }
            });
            const data = await response.json();
            setPayrollRecords(data.results || data);
        } catch (error) {
            console.error('Error fetching payroll:', error);
        }
    };

    const fetchLeaveRequests = async () => {
        try {
            const response = await fetch('/api/staff/leave-requests/', {
                headers: { Authorization: `Bearer ${user.access}` }
            });
            const data = await response.json();
            setLeaveRequests(data.results || data);
        } catch (error) {
            console.error('Error fetching leave requests:', error);
        }
    };

    const addNewStaff = async () => {
        if (!newStaffData.full_name || !newStaffData.department || !newStaffData.position) {
            toast.error('Please fill in all required fields (Name, Department, Position)');
            return;
        }

        setLoading(true);
        try {
            const response = await fetch('/api/staff/profiles/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${user.access}`
                },
                body: JSON.stringify({
                    ...newStaffData,
                    base_salary: parseFloat(newStaffData.base_salary) || 0,
                    hourly_rate: parseFloat(newStaffData.hourly_rate) || 0,
                    employment_status: 'active'
                })
            });

            if (response.ok) {
                const result = await response.json();
                toast.success('Staff member added successfully!');
                fetchStaffProfiles();
                setShowAddStaffModal(false);
                setNewStaffData({
                    full_name: '', phone: '', address: '', department: 'service',
                    position: '', hire_date: new Date().toISOString().split('T')[0],
                    base_salary: '', hourly_rate: '', emergency_contact: '',
                    emergency_phone: '', notes: ''
                });
            } else {
                const error = await response.json();
                toast.error('Failed to add staff: ' + (error.error || JSON.stringify(error)));
            }
        } catch (error) {
            console.error('Error adding staff:', error);
            toast.error('Network error occurred');
        } finally {
            setLoading(false);
        }
    };

    const deleteStaff = async (staffId, staffName) => {
        if (!window.confirm(`Are you sure you want to delete ${staffName}? This will also delete all related attendance and payroll records.`)) {
            return;
        }

        setLoading(true);
        try {
            const response = await fetch(`/api/staff/profiles/${staffId}/`, {
                method: 'DELETE',
                headers: { Authorization: `Bearer ${user.access}` }
            });

            if (response.ok) {
                toast.success('Staff member deleted successfully!');
                fetchStaffProfiles();
                setSelectedStaff(null);
            } else {
                const error = await response.json();
                toast.error('Failed to delete staff: ' + (error.error || 'Unknown error'));
            }
        } catch (error) {
            console.error('Error deleting staff:', error);
            toast.error('Network error occurred');
        } finally {
            setLoading(false);
        }
    };

    const markAttendance = async () => {
        if (!attendanceData.staff_id || !attendanceData.status) {
            toast.error('Please select staff and status');
            return;
        }

        setLoading(true);
        try {
            const response = await fetch('/api/staff/attendance/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${user.access}`
                },
                body: JSON.stringify(attendanceData)
            });

            if (response.ok) {
                toast.success('Attendance marked successfully!');
                fetchAttendanceRecords();
                setShowAttendanceModal(false);
                setAttendanceData({
                    staff_id: null,
                    date: new Date().toISOString().split('T')[0],
                    status: 'present',
                    check_in: '',
                    check_out: '',
                    notes: ''
                });
            } else {
                const error = await response.json();
                toast.error('Failed to mark attendance: ' + (error.error || 'Unknown error'));
            }
        } catch (error) {
            console.error('Error marking attendance:', error);
            toast.error('Network error occurred');
        } finally {
            setLoading(false);
        }
    };

    const generatePayroll = async (staffId) => {
        setLoading(true);
        try {
            const response = await fetch('/api/staff/payroll/generate/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${user.access}`
                },
                body: JSON.stringify({
                    staff_id: staffId,
                    month: currentMonth,
                    year: currentYear
                })
            });

            if (response.ok) {
                const result = await response.json();
                toast.success('Payroll generated successfully!');
                fetchPayrollRecords();
            } else {
                const error = await response.json();
                toast.error('Failed to generate payroll: ' + (error.error || 'Unknown error'));
            }
        } catch (error) {
            console.error('Error generating payroll:', error);
            toast.error('Network error occurred');
        } finally {
            setLoading(false);
        }
    };

    const getStaffAttendance = (staffId) => {
        return attendanceRecords.filter(record => record.staff === staffId);
    };

    const getStaffPayroll = (staffId) => {
        return payrollRecords.find(record => 
            record.staff === staffId && 
            record.month === currentMonth && 
            record.year === currentYear
        );
    };

    const calculateMonthlyStats = (staffId) => {
        const attendance = getStaffAttendance(staffId);
        const present = attendance.filter(record => record.status === 'present').length;
        const absent = attendance.filter(record => record.status === 'absent').length;
        const totalHours = attendance.reduce((sum, record) => sum + (record.total_hours || 0), 0);
        const overtimeHours = attendance.reduce((sum, record) => sum + (record.overtime_hours || 0), 0);
        
        return { present, absent, totalHours, overtimeHours };
    };

    const getDepartmentColor = (department) => {
        switch(department) {
            case 'kitchen': return 'bg-red-100 text-red-800';
            case 'service': return 'bg-blue-100 text-blue-800';
            case 'housekeeping': return 'bg-green-100 text-green-800';
            case 'management': return 'bg-purple-100 text-purple-800';
            case 'billing': return 'bg-yellow-100 text-yellow-800';
            default: return 'bg-gray-100 text-gray-800';
        }
    };

    const getStatusColor = (status) => {
        switch(status) {
            case 'active': return 'bg-green-100 text-green-800';
            case 'inactive': return 'bg-gray-100 text-gray-800';
            case 'terminated': return 'bg-red-100 text-red-800';
            case 'on_leave': return 'bg-yellow-100 text-yellow-800';
            default: return 'bg-gray-100 text-gray-800';
        }
    };

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-3xl font-bold text-gray-900">
                        👥 Staff Management
                    </h1>
                    <p className="text-gray-600 mt-1">
                        Separate staff data for attendance and payroll management (not connected to base users)
                    </p>
                </div>
                
                <div className="flex gap-3">
                    <button
                        onClick={() => setShowAddStaffModal(true)}
                        className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition"
                    >
                        + Add Staff
                    </button>
                    
                    <button
                        onClick={() => setShowAttendanceModal(true)}
                        className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition"
                    >
                        📝 Mark Attendance
                    </button>
                </div>
            </div>

            {/* Month/Year Selector */}
            <div className="bg-white rounded-lg shadow-sm p-4">
                <div className="flex gap-4 items-center">
                    <span className="font-medium">View Period:</span>
                    <select
                        value={currentMonth}
                        onChange={(e) => setCurrentMonth(Number(e.target.value))}
                        className="border rounded px-3 py-2"
                    >
                        {Array.from({length: 12}, (_, i) => (
                            <option key={i + 1} value={i + 1}>
                                {new Date(2024, i).toLocaleString('default', { month: 'long' })}
                            </option>
                        ))}
                    </select>
                    
                    <select
                        value={currentYear}
                        onChange={(e) => setCurrentYear(Number(e.target.value))}
                        className="border rounded px-3 py-2"
                    >
                        {Array.from({length: 5}, (_, i) => (
                            <option key={2022 + i} value={2022 + i}>
                                {2022 + i}
                            </option>
                        ))}
                    </select>
                </div>
            </div>

            {/* Navigation Tabs */}
            <div className="bg-white rounded-lg shadow-sm">
                <div className="border-b border-gray-200">
                    <nav className="flex space-x-8 px-6">
                        {[
                            { id: 'profiles', name: 'Staff Profiles', icon: '👤' },
                            { id: 'attendance', name: 'Attendance', icon: '📋' },
                            { id: 'payroll', name: 'Payroll', icon: '💰' },
                            { id: 'leaves', name: 'Leave Requests', icon: '🏖️' }
                        ].map(tab => (
                            <button
                                key={tab.id}
                                onClick={() => setActiveTab(tab.id)}
                                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                                    activeTab === tab.id
                                        ? 'border-blue-500 text-blue-600'
                                        : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                                }`}
                            >
                                {tab.icon} {tab.name}
                            </button>
                        ))}
                    </nav>
                </div>

                <div className="p-6">
                    {/* Staff Profiles Tab */}
                    {activeTab === 'profiles' && (
                        <div className="space-y-6">
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                {staffProfiles.map(staff => {
                                    const monthlyStats = calculateMonthlyStats(staff.id);
                                    const payroll = getStaffPayroll(staff.id);
                                    
                                    return (
                                        <div key={staff.id} className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition">
                                            <div className="flex justify-between items-start mb-4">
                                                <div>
                                                    <h3 className="font-semibold text-lg">{staff.full_name}</h3>
                                                    <p className="text-gray-600 text-sm">{staff.position}</p>
                                                    <p className="text-gray-500 text-xs">{staff.employee_id}</p>
                                                </div>
                                                
                                                <div className="flex flex-col gap-2">
                                                    <span className={`px-2 py-1 text-xs rounded-full ${getDepartmentColor(staff.department)}`}>
                                                        {staff.department}
                                                    </span>
                                                    <span className={`px-2 py-1 text-xs rounded-full ${getStatusColor(staff.employment_status)}`}>
                                                        {staff.employment_status}
                                                    </span>
                                                </div>
                                            </div>
                                            
                                            <div className="space-y-2 text-sm mb-4">
                                                <div className="flex justify-between">
                                                    <span className="text-gray-600">Hire Date:</span>
                                                    <span>{new Date(staff.hire_date).toLocaleDateString()}</span>
                                                </div>
                                                <div className="flex justify-between">
                                                    <span className="text-gray-600">Base Salary:</span>
                                                    <span>₹{staff.base_salary}</span>
                                                </div>
                                                <div className="flex justify-between">
                                                    <span className="text-gray-600">This Month Present:</span>
                                                    <span className="font-medium text-green-600">{monthlyStats.present} days</span>
                                                </div>
                                                <div className="flex justify-between">
                                                    <span className="text-gray-600">Total Hours:</span>
                                                    <span>{monthlyStats.totalHours.toFixed(1)}h</span>
                                                </div>
                                            </div>
                                            
                                            <div className="flex gap-2">
                                                <button
                                                    onClick={() => setSelectedStaff(staff)}
                                                    className="flex-1 px-3 py-2 text-xs bg-blue-100 text-blue-700 rounded hover:bg-blue-200 transition"
                                                >
                                                    View Details
                                                </button>
                                                
                                                {!payroll && (
                                                    <button
                                                        onClick={() => generatePayroll(staff.id)}
                                                        disabled={loading}
                                                        className="flex-1 px-3 py-2 text-xs bg-green-100 text-green-700 rounded hover:bg-green-200 transition disabled:opacity-50"
                                                    >
                                                        Generate Payroll
                                                    </button>
                                                )}
                                                
                                                <button
                                                    onClick={() => deleteStaff(staff.id, staff.full_name)}
                                                    className="px-3 py-2 text-xs bg-red-100 text-red-700 rounded hover:bg-red-200 transition"
                                                >
                                                    Delete
                                                </button>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                            
                            {staffProfiles.length === 0 && (
                                <div className="text-center py-12">
                                    <svg className="w-16 h-16 text-gray-300 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                                    </svg>
                                    <p className="text-gray-500 text-lg">No staff profiles found</p>
                                    <p className="text-gray-400 text-sm mt-2">Add your first staff member to get started</p>
                                </div>
                            )}
                        </div>
                    )}

                    {/* Attendance Tab */}
                    {activeTab === 'attendance' && (
                        <div>
                            <div className="mb-6">
                                <h2 className="text-xl font-semibold mb-2">
                                    Attendance Records - {new Date(currentYear, currentMonth - 1).toLocaleString('default', { month: 'long', year: 'numeric' })}
                                </h2>
                            </div>
                            
                            <div className="overflow-x-auto">
                                <table className="min-w-full bg-white border border-gray-300 rounded-lg">
                                    <thead>
                                        <tr className="bg-gray-50">
                                            <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Staff</th>
                                            <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                                            <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                            <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Check In</th>
                                            <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Check Out</th>
                                            <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Hours</th>
                                            <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Overtime</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {attendanceRecords.map(record => {
                                            const staff = staffProfiles.find(s => s.id === record.staff);
                                            return (
                                                <tr key={`${record.staff}-${record.date}`} className="border-t">
                                                    <td className="px-4 py-3">
                                                        <div>
                                                            <div className="font-medium">{staff?.full_name || 'Unknown'}</div>
                                                            <div className="text-sm text-gray-500">{staff?.employee_id}</div>
                                                        </div>
                                                    </td>
                                                    <td className="px-4 py-3 text-sm">{new Date(record.date).toLocaleDateString()}</td>
                                                    <td className="px-4 py-3">
                                                        <span className={`px-2 py-1 text-xs rounded-full ${
                                                            record.status === 'present' ? 'bg-green-100 text-green-800' :
                                                            record.status === 'absent' ? 'bg-red-100 text-red-800' :
                                                            record.status === 'half_day' ? 'bg-yellow-100 text-yellow-800' :
                                                            'bg-gray-100 text-gray-800'
                                                        }`}>
                                                            {record.status.replace('_', ' ')}
                                                        </span>
                                                    </td>
                                                    <td className="px-4 py-3 text-sm">{record.check_in || '-'}</td>
                                                    <td className="px-4 py-3 text-sm">{record.check_out || '-'}</td>
                                                    <td className="px-4 py-3 text-sm">{record.total_hours ? `${record.total_hours}h` : '-'}</td>
                                                    <td className="px-4 py-3 text-sm">{record.overtime_hours ? `${record.overtime_hours}h` : '-'}</td>
                                                </tr>
                                            );
                                        })}
                                    </tbody>
                                </table>
                                
                                {attendanceRecords.length === 0 && (
                                    <div className="text-center py-12">
                                        <p className="text-gray-500">No attendance records found for this period</p>
                                    </div>
                                )}
                            </div>
                        </div>
                    )}

                    {/* Payroll Tab */}
                    {activeTab === 'payroll' && (
                        <div>
                            <div className="mb-6">
                                <h2 className="text-xl font-semibold mb-2">
                                    Payroll - {new Date(currentYear, currentMonth - 1).toLocaleString('default', { month: 'long', year: 'numeric' })}
                                </h2>
                            </div>
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                {payrollRecords.map(payroll => {
                                    const staff = staffProfiles.find(s => s.id === payroll.staff);
                                    return (
                                        <div key={payroll.id} className="bg-gray-50 rounded-lg p-6">
                                            <div className="flex justify-between items-start mb-4">
                                                <div>
                                                    <h3 className="font-semibold text-lg">{staff?.full_name}</h3>
                                                    <p className="text-gray-600 text-sm">{staff?.employee_id}</p>
                                                </div>
                                                <span className={`px-3 py-1 text-sm rounded-full ${
                                                    payroll.payment_status === 'paid' ? 'bg-green-100 text-green-800' :
                                                    payroll.payment_status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                                                    'bg-red-100 text-red-800'
                                                }`}>
                                                    {payroll.payment_status}
                                                </span>
                                            </div>
                                            
                                            <div className="space-y-3">
                                                <div className="grid grid-cols-2 gap-4 text-sm">
                                                    <div>
                                                        <span className="text-gray-600">Days Present:</span>
                                                        <span className="ml-2 font-medium">{payroll.days_present}</span>
                                                    </div>
                                                    <div>
                                                        <span className="text-gray-600">Total Hours:</span>
                                                        <span className="ml-2 font-medium">{payroll.total_hours}h</span>
                                                    </div>
                                                    <div>
                                                        <span className="text-gray-600">Overtime:</span>
                                                        <span className="ml-2 font-medium">{payroll.overtime_hours}h</span>
                                                    </div>
                                                    <div>
                                                        <span className="text-gray-600">Base Salary:</span>
                                                        <span className="ml-2 font-medium">₹{payroll.base_salary}</span>
                                                    </div>
                                                </div>
                                                
                                                <div className="border-t pt-3">
                                                    <div className="flex justify-between items-center">
                                                        <span className="font-semibold">Net Salary:</span>
                                                        <span className="text-xl font-bold text-green-600">₹{payroll.net_salary}</span>
                                                    </div>
                                                </div>
                                                
                                                {payroll.payment_date && (
                                                    <div className="text-sm text-gray-600">
                                                        Paid on: {new Date(payroll.payment_date).toLocaleDateString()}
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                            
                            {payrollRecords.length === 0 && (
                                <div className="text-center py-12">
                                    <p className="text-gray-500">No payroll records found for this period</p>
                                    <p className="text-gray-400 text-sm mt-2">Generate payroll for staff members from the Profiles tab</p>
                                </div>
                            )}
                        </div>
                    )}

                    {/* Leave Requests Tab */}
                    {activeTab === 'leaves' && (
                        <div>
                            <div className="mb-6">
                                <h2 className="text-xl font-semibold mb-2">Leave Requests</h2>
                            </div>
                            
                            <div className="space-y-4">
                                {leaveRequests.map(leave => {
                                    const staff = staffProfiles.find(s => s.id === leave.staff);
                                    return (
                                        <div key={leave.id} className="bg-white border border-gray-200 rounded-lg p-4">
                                            <div className="flex justify-between items-start">
                                                <div>
                                                    <h3 className="font-medium">{staff?.full_name}</h3>
                                                    <p className="text-sm text-gray-600">
                                                        {leave.leave_type} leave from {new Date(leave.start_date).toLocaleDateString()} 
                                                        to {new Date(leave.end_date).toLocaleDateString()} ({leave.total_days} days)
                                                    </p>
                                                    <p className="text-sm text-gray-500 mt-2">{leave.reason}</p>
                                                </div>
                                                
                                                <span className={`px-3 py-1 text-sm rounded-full ${
                                                    leave.status === 'approved' ? 'bg-green-100 text-green-800' :
                                                    leave.status === 'rejected' ? 'bg-red-100 text-red-800' :
                                                    'bg-yellow-100 text-yellow-800'
                                                }`}>
                                                    {leave.status}
                                                </span>
                                            </div>
                                        </div>
                                    );
                                })}
                                
                                {leaveRequests.length === 0 && (
                                    <div className="text-center py-12">
                                        <p className="text-gray-500">No leave requests found</p>
                                    </div>
                                )}
                            </div>
                        </div>
                    )}
                </div>
            </div>

            {/* Add Staff Modal */}
            {showAddStaffModal && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                    <div className="bg-white rounded-lg p-6 w-full max-w-2xl mx-4 max-h-[90vh] overflow-y-auto">
                        <h3 className="text-xl font-semibold mb-6">Add New Staff Member</h3>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Full Name *</label>
                                <input
                                    type="text"
                                    value={newStaffData.full_name}
                                    onChange={(e) => setNewStaffData({...newStaffData, full_name: e.target.value})}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                    required
                                />
                            </div>
                            
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                                <input
                                    type="tel"
                                    value={newStaffData.phone}
                                    onChange={(e) => setNewStaffData({...newStaffData, phone: e.target.value})}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                />
                            </div>
                            
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Department *</label>
                                <select
                                    value={newStaffData.department}
                                    onChange={(e) => setNewStaffData({...newStaffData, department: e.target.value})}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                    required
                                >
                                    <option value="service">Service</option>
                                    <option value="kitchen">Kitchen</option>
                                    <option value="housekeeping">Housekeeping</option>
                                    <option value="management">Management</option>
                                    <option value="billing">Billing</option>
                                    <option value="security">Security</option>
                                </select>
                            </div>
                            
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Position *</label>
                                <input
                                    type="text"
                                    value={newStaffData.position}
                                    onChange={(e) => setNewStaffData({...newStaffData, position: e.target.value})}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                    required
                                />
                            </div>
                            
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Hire Date</label>
                                <input
                                    type="date"
                                    value={newStaffData.hire_date}
                                    onChange={(e) => setNewStaffData({...newStaffData, hire_date: e.target.value})}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                />
                            </div>
                            
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Base Salary (₹)</label>
                                <input
                                    type="number"
                                    value={newStaffData.base_salary}
                                    onChange={(e) => setNewStaffData({...newStaffData, base_salary: e.target.value})}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                    min="0"
                                />
                            </div>
                            
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Hourly Rate (₹)</label>
                                <input
                                    type="number"
                                    value={newStaffData.hourly_rate}
                                    onChange={(e) => setNewStaffData({...newStaffData, hourly_rate: e.target.value})}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                    min="0"
                                    step="0.01"
                                />
                            </div>
                            
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Emergency Contact</label>
                                <input
                                    type="text"
                                    value={newStaffData.emergency_contact}
                                    onChange={(e) => setNewStaffData({...newStaffData, emergency_contact: e.target.value})}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                />
                            </div>
                            
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Emergency Phone</label>
                                <input
                                    type="tel"
                                    value={newStaffData.emergency_phone}
                                    onChange={(e) => setNewStaffData({...newStaffData, emergency_phone: e.target.value})}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                />
                            </div>
                        </div>
                        
                        <div className="mb-6">
                            <label className="block text-sm font-medium text-gray-700 mb-1">Address</label>
                            <textarea
                                value={newStaffData.address}
                                onChange={(e) => setNewStaffData({...newStaffData, address: e.target.value})}
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                rows="2"
                            />
                        </div>
                        
                        <div className="mb-6">
                            <label className="block text-sm font-medium text-gray-700 mb-1">Notes</label>
                            <textarea
                                value={newStaffData.notes}
                                onChange={(e) => setNewStaffData({...newStaffData, notes: e.target.value})}
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                rows="3"
                            />
                        </div>
                        
                        <div className="flex gap-3">
                            <button
                                onClick={() => setShowAddStaffModal(false)}
                                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition"
                            >
                                Cancel
                            </button>
                            <button
                                onClick={addNewStaff}
                                disabled={loading}
                                className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition disabled:opacity-50"
                            >
                                {loading ? 'Adding...' : 'Add Staff Member'}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Mark Attendance Modal */}
            {showAttendanceModal && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                    <div className="bg-white rounded-lg p-6 w-full max-w-md mx-4">
                        <h3 className="text-lg font-semibold mb-4">Mark Attendance</h3>
                        
                        <div className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Staff Member *</label>
                                <select
                                    value={attendanceData.staff_id || ''}
                                    onChange={(e) => setAttendanceData({...attendanceData, staff_id: parseInt(e.target.value)})}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                    required
                                >
                                    <option value="">Select Staff Member</option>
                                    {staffProfiles.map(staff => (
                                        <option key={staff.id} value={staff.id}>
                                            {staff.full_name} ({staff.employee_id})
                                        </option>
                                    ))}
                                </select>
                            </div>
                            
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
                                <input
                                    type="date"
                                    value={attendanceData.date}
                                    onChange={(e) => setAttendanceData({...attendanceData, date: e.target.value})}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                />
                            </div>
                            
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Status *</label>
                                <select
                                    value={attendanceData.status}
                                    onChange={(e) => setAttendanceData({...attendanceData, status: e.target.value})}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                    required
                                >
                                    <option value="present">Present</option>
                                    <option value="absent">Absent</option>
                                    <option value="half_day">Half Day</option>
                                    <option value="leave">Leave</option>
                                    <option value="holiday">Holiday</option>
                                </select>
                            </div>
                            
                            {attendanceData.status === 'present' && (
                                <>
                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-1">Check In Time</label>
                                        <input
                                            type="time"
                                            value={attendanceData.check_in}
                                            onChange={(e) => setAttendanceData({...attendanceData, check_in: e.target.value})}
                                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                        />
                                    </div>
                                    
                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-1">Check Out Time</label>
                                        <input
                                            type="time"
                                            value={attendanceData.check_out}
                                            onChange={(e) => setAttendanceData({...attendanceData, check_out: e.target.value})}
                                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                        />
                                    </div>
                                </>
                            )}
                            
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Notes</label>
                                <textarea
                                    value={attendanceData.notes}
                                    onChange={(e) => setAttendanceData({...attendanceData, notes: e.target.value})}
                                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                                    rows="2"
                                />
                            </div>
                        </div>
                        
                        <div className="flex gap-3 mt-6">
                            <button
                                onClick={() => setShowAttendanceModal(false)}
                                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition"
                            >
                                Cancel
                            </button>
                            <button
                                onClick={markAttendance}
                                disabled={loading}
                                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition disabled:opacity-50"
                            >
                                {loading ? 'Marking...' : 'Mark Attendance'}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Staff Detail Modal */}
            {selectedStaff && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
                    <div className="bg-white rounded-lg p-6 w-full max-w-2xl mx-4 max-h-[90vh] overflow-y-auto">
                        <div className="flex justify-between items-start mb-6">
                            <div>
                                <h3 className="text-xl font-semibold">{selectedStaff.full_name}</h3>
                                <p className="text-gray-600">{selectedStaff.employee_id} • {selectedStaff.position}</p>
                            </div>
                            <button
                                onClick={() => setSelectedStaff(null)}
                                className="text-gray-500 hover:text-gray-700"
                            >
                                ✕
                            </button>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <h4 className="font-semibold mb-3">Basic Information</h4>
                                <div className="space-y-2 text-sm">
                                    <div><span className="text-gray-600">Department:</span> {selectedStaff.department}</div>
                                    <div><span className="text-gray-600">Position:</span> {selectedStaff.position}</div>
                                    <div><span className="text-gray-600">Phone:</span> {selectedStaff.phone || 'Not provided'}</div>
                                    <div><span className="text-gray-600">Hire Date:</span> {new Date(selectedStaff.hire_date).toLocaleDateString()}</div>
                                    <div><span className="text-gray-600">Status:</span> {selectedStaff.employment_status}</div>
                                </div>
                            </div>
                            
                            <div>
                                <h4 className="font-semibold mb-3">Compensation</h4>
                                <div className="space-y-2 text-sm">
                                    <div><span className="text-gray-600">Base Salary:</span> ₹{selectedStaff.base_salary}</div>
                                    <div><span className="text-gray-600">Hourly Rate:</span> ₹{selectedStaff.hourly_rate}</div>
                                </div>
                            </div>
                            
                            <div>
                                <h4 className="font-semibold mb-3">Emergency Contact</h4>
                                <div className="space-y-2 text-sm">
                                    <div><span className="text-gray-600">Name:</span> {selectedStaff.emergency_contact || 'Not provided'}</div>
                                    <div><span className="text-gray-600">Phone:</span> {selectedStaff.emergency_phone || 'Not provided'}</div>
                                </div>
                            </div>
                            
                            <div>
                                <h4 className="font-semibold mb-3">Monthly Stats</h4>
                                <div className="space-y-2 text-sm">
                                    {(() => {
                                        const stats = calculateMonthlyStats(selectedStaff.id);
                                        return (
                                            <>
                                                <div><span className="text-gray-600">Days Present:</span> {stats.present}</div>
                                                <div><span className="text-gray-600">Days Absent:</span> {stats.absent}</div>
                                                <div><span className="text-gray-600">Total Hours:</span> {stats.totalHours.toFixed(1)}h</div>
                                                <div><span className="text-gray-600">Overtime:</span> {stats.overtimeHours.toFixed(1)}h</div>
                                            </>
                                        );
                                    })()}
                                </div>
                            </div>
                        </div>
                        
                        {selectedStaff.address && (
                            <div className="mt-6">
                                <h4 className="font-semibold mb-3">Address</h4>
                                <p className="text-sm text-gray-600">{selectedStaff.address}</p>
                            </div>
                        )}
                        
                        {selectedStaff.notes && (
                            <div className="mt-6">
                                <h4 className="font-semibold mb-3">Notes</h4>
                                <p className="text-sm text-gray-600">{selectedStaff.notes}</p>
                            </div>
                        )}
                        
                        <div className="flex gap-3 mt-6">
                            <button
                                onClick={() => setSelectedStaff(null)}
                                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition"
                            >
                                Close
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default StaffManagement;
'''

with open('staff_management_updated.js', 'w') as f:
    f.write(staff_management_updated_js)

print("✅ Created updated Staff Management component with separate staff data")
print("File saved: staff_management_updated.js")