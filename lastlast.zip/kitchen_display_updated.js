
// pages/kitchen/display.js - KITCHEN DISPLAY WITH FULL AUDIO ALERT SYSTEM
import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/context/AuthContext';
import toast from 'react-hot-toast';

const KitchenDisplay = () => {
    const { user } = useAuth();
    const [kitchenOrders, setKitchenOrders] = useState([]);
    const [audioAlerts, setAudioAlerts] = useState([]);
    const [stats, setStats] = useState({});
    const [loading, setLoading] = useState(true);
    const [audioEnabled, setAudioEnabled] = useState(true);
    const [volume, setVolume] = useState(80);
    const [filterStatus, setFilterStatus] = useState('all');

    // Audio references
    const audioContextRef = useRef();
    const audioElementsRef = useRef({});

    // Auto refresh
    const intervalRef = useRef();
    const [lastUpdate, setLastUpdate] = useState(new Date());

    useEffect(() => {
        initializeAudio();
        fetchKitchenData();

        // Auto refresh every 10 seconds for kitchen display
        intervalRef.current = setInterval(() => {
            fetchKitchenData();
        }, 10000);

        return () => {
            if (intervalRef.current) {
                clearInterval(intervalRef.current);
            }
        };
    }, []);

    const initializeAudio = () => {
        // Initialize Web Audio API for better control
        try {
            audioContextRef.current = new (window.AudioContext || window.webkitAudioContext)();

            // Preload common alert sounds
            const alertSounds = {
                'new_order': '/audio/new_order_alert.mp3',
                'order_ready': '/audio/order_ready_alert.mp3',
                'urgent_order': '/audio/urgent_order_alert.mp3'
            };

            Object.entries(alertSounds).forEach(([type, src]) => {
                const audio = new Audio(src);
                audio.volume = volume / 100;
                audio.preload = 'auto';
                audioElementsRef.current[type] = audio;
            });
        } catch (error) {
            console.warn('Audio initialization failed:', error);
        }
    };

    const fetchKitchenData = async () => {
        try {
            const response = await fetch('/api/kitchen/active_orders_with_audio/', {
                headers: user?.access ? { Authorization: `Bearer ${user.access}` } : {}
            });

            if (response.ok) {
                const data = await response.json();

                // Check for new audio alerts
                if (audioEnabled && data.audio_alerts && data.audio_alerts.length > 0) {
                    data.audio_alerts.forEach(alert => {
                        playAudioAlert(alert);
                        showVisualAlert(alert);
                    });
                }

                setKitchenOrders(data.kitchen_orders || []);
                setStats(data.kitchen_stats || {});
                setLastUpdate(new Date());

                if (loading) setLoading(false);
            }
        } catch (error) {
            console.error('Error fetching kitchen data:', error);
            if (!loading) {
                toast.error('Connection lost - trying to reconnect...');
            }
        }
    };

    const playAudioAlert = (alert) => {
        if (!audioEnabled) return;

        try {
            let audioElement = audioElementsRef.current[alert.type];

            if (!audioElement) {
                // Fallback to text-to-speech
                if ('speechSynthesis' in window) {
                    const utterance = new SpeechSynthesisUtterance(alert.message);
                    utterance.volume = volume / 100;
                    utterance.rate = 0.9;
                    speechSynthesis.speak(utterance);
                }
                return;
            }

            audioElement.volume = volume / 100;
            audioElement.currentTime = 0;

            const playPromise = audioElement.play();
            if (playPromise) {
                playPromise.catch(error => {
                    console.warn('Audio play failed:', error);
                    // Fallback to text-to-speech
                    if ('speechSynthesis' in window) {
                        const utterance = new SpeechSynthesisUtterance(alert.message);
                        utterance.volume = volume / 100;
                        speechSynthesis.speak(utterance);
                    }
                });
            }

            // Repeat if required
            const repeatCount = alert.repeat_count || 1;
            if (repeatCount > 1) {
                let repeats = 1;
                const repeatInterval = setInterval(() => {
                    if (repeats < repeatCount) {
                        audioElement.currentTime = 0;
                        audioElement.play().catch(() => {});
                        repeats++;
                    } else {
                        clearInterval(repeatInterval);
                    }
                }, (alert.repeat_interval || 3) * 1000);
            }
        } catch (error) {
            console.error('Audio playback error:', error);
        }
    };

    const showVisualAlert = (alert) => {
        const alertColors = {
            'new_order': 'bg-blue-500',
            'order_ready': 'bg-green-500',
            'urgent_order': 'bg-red-500'
        };

        toast.success(alert.message, {
            duration: 5000,
            className: `text-white ${alertColors[alert.type] || 'bg-blue-500'}`,
            icon: alert.type === 'new_order' ? '🔔' : alert.type === 'order_ready' ? '✅' : '🚨'
        });
    };

    const updateItemStatus = async (orderItemId, newStatus) => {
        try {
            const response = await fetch('/api/kitchen/update_item_status/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${user?.access}`
                },
                body: JSON.stringify({
                    order_item_id: orderItemId,
                    new_status: newStatus,
                    chef_name: 'Kitchen Staff'
                })
            });

            if (response.ok) {
                const data = await response.json();

                // Play audio if item is ready
                if (data.audio_alert && audioEnabled) {
                    playAudioAlert(data.audio_alert);
                    showVisualAlert(data.audio_alert);
                }

                // Refresh data
                fetchKitchenData();

                toast.success(data.message);
            } else {
                const error = await response.json();
                toast.error(error.error || 'Failed to update status');
            }
        } catch (error) {
            console.error('Error updating item status:', error);
            toast.error('Network error');
        }
    };

    const markOrderComplete = async (orderId) => {
        try {
            const response = await fetch('/api/kitchen/mark_order_complete/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${user?.access}`
                },
                body: JSON.stringify({
                    table_order_id: orderId,
                    chef_name: 'Kitchen Staff'
                })
            });

            if (response.ok) {
                const data = await response.json();

                // Play completion audio
                if (data.audio_alert && audioEnabled) {
                    playAudioAlert(data.audio_alert);
                    showVisualAlert(data.audio_alert);
                }

                fetchKitchenData();
                toast.success(data.message);
            }
        } catch (error) {
            console.error('Error marking order complete:', error);
            toast.error('Network error');
        }
    };

    const getStatusColor = (status) => {
        switch(status) {
            case 'pending': return 'bg-yellow-100 text-yellow-800 border-yellow-300';
            case 'in_progress': return 'bg-blue-100 text-blue-800 border-blue-300';
            case 'ready': return 'bg-green-100 text-green-800 border-green-300';
            default: return 'bg-gray-100 text-gray-800 border-gray-300';
        }
    };

    const getPriorityColor = (priority) => {
        switch(priority) {
            case 4: return 'bg-red-500 text-white';
            case 3: return 'bg-orange-500 text-white';
            case 2: return 'bg-blue-500 text-white';
            default: return 'bg-gray-500 text-white';
        }
    };

    const getItemStatusColor = (status) => {
        switch(status) {
            case 'pending': return 'bg-red-100 text-red-700';
            case 'preparing': return 'bg-yellow-100 text-yellow-700';
            case 'ready': return 'bg-green-100 text-green-700';
            default: return 'bg-gray-100 text-gray-700';
        }
    };

    const filteredOrders = kitchenOrders.filter(order => {
        if (filterStatus === 'all') return true;
        return order.status === filterStatus;
    });

    if (loading) {
        return (
            <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">
                <div className="text-center">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white mx-auto mb-4"></div>
                    <p className="text-xl">Loading Kitchen Display...</p>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gray-900 text-white p-4">
            {/* Header */}
            <div className="bg-gray-800 rounded-lg p-6 mb-6">
                <div className="flex justify-between items-center">
                    <div>
                        <h1 className="text-3xl font-bold mb-2">🍳 Kitchen Display System</h1>
                        <p className="text-gray-300">
                            Real-time orders from mobile ordering • Audio alerts enabled
                        </p>
                    </div>

                    <div className="text-right">
                        <div className="text-sm text-gray-400 mb-2">
                            Last updated: {lastUpdate.toLocaleTimeString()}
                        </div>
                        <div className="flex items-center gap-4">
                            <div className={`w-3 h-3 rounded-full ${
                                Date.now() - lastUpdate.getTime() < 30000 ? 'bg-green-400' : 'bg-red-400'
                            }`}></div>
                            <span className="text-sm">
                                {Date.now() - lastUpdate.getTime() < 30000 ? 'Connected' : 'Disconnected'}
                            </span>
                        </div>
                    </div>
                </div>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                <div className="bg-blue-600 rounded-lg p-4 text-center">
                    <div className="text-2xl font-bold">{stats.pending_orders || 0}</div>
                    <div className="text-sm opacity-90">Pending</div>
                </div>
                <div className="bg-yellow-600 rounded-lg p-4 text-center">
                    <div className="text-2xl font-bold">{stats.in_progress_orders || 0}</div>
                    <div className="text-sm opacity-90">In Progress</div>
                </div>
                <div className="bg-red-600 rounded-lg p-4 text-center">
                    <div className="text-2xl font-bold">{stats.urgent_orders || 0}</div>
                    <div className="text-sm opacity-90">Urgent</div>
                </div>
                <div className="bg-orange-600 rounded-lg p-4 text-center">
                    <div className="text-2xl font-bold">{stats.high_priority_orders || 0}</div>
                    <div className="text-sm opacity-90">High Priority</div>
                </div>
            </div>

            {/* Controls */}
            <div className="bg-gray-800 rounded-lg p-4 mb-6">
                <div className="flex justify-between items-center">
                    <div className="flex gap-4 items-center">
                        <span className="text-sm font-medium">Filter:</span>
                        <select
                            value={filterStatus}
                            onChange={(e) => setFilterStatus(e.target.value)}
                            className="bg-gray-700 text-white px-3 py-2 rounded border border-gray-600"
                        >
                            <option value="all">All Orders</option>
                            <option value="pending">Pending</option>
                            <option value="in_progress">In Progress</option>
                        </select>
                    </div>

                    <div className="flex gap-4 items-center">
                        <label className="flex items-center gap-2">
                            <input
                                type="checkbox"
                                checked={audioEnabled}
                                onChange={(e) => setAudioEnabled(e.target.checked)}
                                className="form-checkbox"
                            />
                            <span className="text-sm">Audio Alerts</span>
                        </label>

                        <div className="flex items-center gap-2">
                            <span className="text-sm">Volume:</span>
                            <input
                                type="range"
                                min="0"
                                max="100"
                                value={volume}
                                onChange={(e) => {
                                    const newVolume = parseInt(e.target.value);
                                    setVolume(newVolume);
                                    // Update audio elements volume
                                    Object.values(audioElementsRef.current).forEach(audio => {
                                        if (audio) audio.volume = newVolume / 100;
                                    });
                                }}
                                className="w-20"
                            />
                            <span className="text-sm w-8">{volume}%</span>
                        </div>
                    </div>
                </div>
            </div>

            {/* Orders Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                {filteredOrders.length === 0 ? (
                    <div className="col-span-full bg-gray-800 rounded-lg p-12 text-center">
                        <div className="text-6xl mb-4">🍽️</div>
                        <h2 className="text-2xl font-bold mb-2">No Active Orders</h2>
                        <p className="text-gray-400">Orders from mobile app will appear here automatically</p>
                    </div>
                ) : (
                    filteredOrders.map(order => (
                        <div key={order.id} className="bg-gray-800 rounded-lg p-6 border-l-4 border-l-blue-500">
                            {/* Order Header */}
                            <div className="flex justify-between items-start mb-4">
                                <div>
                                    <h3 className="text-xl font-bold">Table {order.table_number}</h3>
                                    <p className="text-gray-400 text-sm">Order #{order.order_number}</p>
                                    <p className="text-gray-400 text-sm">{order.customer_name} • {order.customer_count} guests</p>
                                </div>

                                <div className="flex flex-col items-end gap-2">
                                    <span className={`px-3 py-1 text-xs font-bold rounded-full ${getPriorityColor(order.priority)}`}>
                                        Priority {order.priority}
                                    </span>
                                    <span className={`px-3 py-1 text-xs rounded-full ${getStatusColor(order.status)}`}>
                                        {order.status.replace('_', ' ')}
                                    </span>
                                </div>
                            </div>

                            {/* Time Info */}
                            <div className="flex justify-between items-center mb-4 text-sm">
                                <span className="text-gray-400">
                                    Time: {order.time_since_order} min ago
                                </span>
                                <span className="text-gray-400">
                                    Items: {order.total_items}
                                </span>
                            </div>

                            {/* Order Items */}
                            <div className="space-y-3 mb-6">
                                {order.items.map(item => (
                                    <div key={item.id} className="bg-gray-700 rounded-lg p-4">
                                        <div className="flex justify-between items-start mb-2">
                                            <div className="flex-1">
                                                <h4 className="font-semibold">{item.name_en}</h4>
                                                {item.name_hi && (
                                                    <p className="text-sm text-gray-400">{item.name_hi}</p>
                                                )}
                                                <div className="flex items-center gap-2 mt-1">
                                                    <span className="text-lg font-bold">×{item.quantity}</span>
                                                    <span className={`px-2 py-1 text-xs rounded ${getItemStatusColor(item.status)}`}>
                                                        {item.status}
                                                    </span>
                                                </div>
                                            </div>

                                            <div className="text-right">
                                                <div className="text-sm text-gray-400">
                                                    {item.time_since_ordered} min
                                                </div>
                                                <div className="text-xs text-gray-500">
                                                    Est: {item.estimated_prep_time}m
                                                </div>
                                            </div>
                                        </div>

                                        {item.special_instructions && (
                                            <div className="bg-yellow-900 bg-opacity-30 border border-yellow-600 rounded p-2 mb-3">
                                                <p className="text-sm text-yellow-300">
                                                    <strong>Special:</strong> {item.special_instructions}
                                                </p>
                                            </div>
                                        )}

                                        {/* Item Actions */}
                                        <div className="flex gap-2">
                                            {item.status === 'pending' && (
                                                <button
                                                    onClick={() => updateItemStatus(item.id, 'preparing')}
                                                    className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 px-3 rounded text-sm transition"
                                                >
                                                    Start Preparing
                                                </button>
                                            )}

                                            {item.status === 'preparing' && (
                                                <button
                                                    onClick={() => updateItemStatus(item.id, 'ready')}
                                                    className="flex-1 bg-green-600 hover:bg-green-700 text-white py-2 px-3 rounded text-sm transition"
                                                >
                                                    Mark Ready
                                                </button>
                                            )}

                                            {item.status === 'ready' && (
                                                <div className="flex-1 bg-green-800 text-green-200 py-2 px-3 rounded text-sm text-center">
                                                    Ready to Serve
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                ))}
                            </div>

                            {/* Order Special Instructions */}
                            {order.special_instructions && (
                                <div className="bg-yellow-900 bg-opacity-30 border border-yellow-600 rounded p-3 mb-4">
                                    <p className="text-sm text-yellow-300">
                                        <strong>Order Note:</strong> {order.special_instructions}
                                    </p>
                                </div>
                            )}

                            {/* Order Actions */}
                            <div className="flex gap-3">
                                {order.status === 'pending' && order.items.some(item => item.status === 'pending') && (
                                    <button
                                        onClick={() => {
                                            order.items.forEach(item => {
                                                if (item.status === 'pending') {
                                                    updateItemStatus(item.id, 'preparing');
                                                }
                                            });
                                        }}
                                        className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-3 px-4 rounded font-semibold transition"
                                    >
                                        Start All Items
                                    </button>
                                )}

                                {order.status === 'in_progress' && order.items.every(item => ['ready', 'served'].includes(item.status)) && (
                                    <button
                                        onClick={() => markOrderComplete(order.id)}
                                        className="flex-1 bg-green-600 hover:bg-green-700 text-white py-3 px-4 rounded font-semibold transition"
                                    >
                                        🔔 Order Complete
                                    </button>
                                )}

                                <button
                                    onClick={() => window.location.reload()}
                                    className="px-4 py-3 bg-gray-600 hover:bg-gray-700 text-white rounded transition"
                                >
                                    ↻
                                </button>
                            </div>
                        </div>
                    ))
                )}
            </div>

            {/* Footer */}
            <div className="mt-8 text-center text-gray-500 text-sm">
                <p>Kitchen Display System • Auto-refresh every 10 seconds • Audio alerts {audioEnabled ? 'enabled' : 'disabled'}</p>
            </div>
        </div>
    );
};

export default KitchenDisplay;
