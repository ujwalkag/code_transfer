# Complete Production-Ready Implementation Commands

## 1. CREATE APP STRUCTURE
cd hotel-management-backend

# Create directories
mkdir -p apps/tables apps/staff apps/inventory
mkdir -p apps/tables/migrations apps/staff/migrations apps/inventory/migrations

## 2. CREATE APP CONFIGURATION FILES

# Tables app configuration
echo 'default_app_config = "apps.tables.apps.TablesConfig"' > apps/tables/__init__.py
touch apps/tables/migrations/__init__.py

cat > apps/tables/apps.py << 'EOF'
from django.apps import AppConfig

class TablesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.tables'
    verbose_name = 'Table Management'
EOF

# Staff app configuration  
echo 'default_app_config = "apps.staff.apps.StaffConfig"' > apps/staff/__init__.py
touch apps/staff/migrations/__init__.py

cat > apps/staff/apps.py << 'EOF'
from django.apps import AppConfig

class StaffConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.staff'
    verbose_name = 'Staff Management'
EOF

# Inventory app configuration
echo 'default_app_config = "apps.inventory.apps.InventoryConfig"' > apps/inventory/__init__.py
touch apps/inventory/migrations/__init__.py

cat > apps/inventory/apps.py << 'EOF'
from django.apps import AppConfig

class InventoryConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.inventory'
    verbose_name = 'Inventory Management'
EOF

## 3. COPY PRODUCTION-READY CODE FILES

# TABLES APP FILES:
# Copy content from tables_permissions.py [file 56] to apps/tables/permissions.py
# Copy content from tables_models.py [file 57] to apps/tables/models.py  
# Copy content from tables_serializers.py [file 58] to apps/tables/serializers.py
# Copy content from tables_views.py [file 59] to apps/tables/views.py
# Copy content from tables_urls.py [file 60] to apps/tables/urls.py
# Copy content from tables_admin.py [file 61] to apps/tables/admin.py

# STAFF APP FILES:
# Copy content from staff_permissions.py [file 62] to apps/staff/permissions.py
# For models.py, serializers.py, views.py, urls.py, admin.py - use the content from complete_staff_app.md [file 52]

# INVENTORY APP FILES:
# Copy content from inventory_permissions.py [file 63] to apps/inventory/permissions.py  
# For models.py, serializers.py, views.py, urls.py, admin.py - use the content from complete_inventory_app.md [file 53]

## 4. UPDATE DJANGO SETTINGS

# Add to config/settings.py INSTALLED_APPS:
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',

    'rest_framework',
    'rest_framework_simplejwt', 
    'rest_framework_simplejwt.token_blacklist',
    'corsheaders',
    'channels',                    # ADD THIS
    'django_extensions',           # ADD THIS
    
    # Existing apps
    'apps.users',
    'apps.menu',
    'apps.rooms',
    'apps.bills', 
    'apps.notifications',
    
    # NEW APPS - ADD THESE:
    'apps.tables',
    'apps.staff',
    'apps.inventory',
]

# Add WebSocket configuration at end of settings.py:
ASGI_APPLICATION = 'config.asgi.application'

CHANNEL_LAYERS = {
    'default': {
        'BACKEND': 'channels_redis.core.RedisChannelLayer',
        'CONFIG': {
            "hosts": [('127.0.0.1', 6379)],
        },
    },
}

REDIS_URL = 'redis://localhost:6379/0'
CELERY_BROKER_URL = REDIS_URL
CELERY_RESULT_BACKEND = REDIS_URL

## 5. UPDATE URLS

# Add to config/urls.py urlpatterns:
path('api/tables/', include('apps.tables.urls')),
path('api/staff/', include('apps.staff.urls')),
path('api/inventory/', include('apps.inventory.urls')),

## 6. RUN MIGRATIONS

# Check for issues
python manage.py check

# Create migrations
python manage.py makemigrations tables
python manage.py makemigrations staff  
python manage.py makemigrations inventory

# Apply all migrations
python manage.py migrate

## 7. CREATE SAMPLE DATA

python manage.py shell

# Run in Django shell:
from apps.tables.models import RestaurantTable
from apps.inventory.models import InventoryCategory

# Create tables 13, 14, 15
RestaurantTable.objects.create(table_number="13", capacity=4, location="Window Side")
RestaurantTable.objects.create(table_number="14", capacity=6, location="Center Hall")
RestaurantTable.objects.create(table_number="15", capacity=2, location="Corner")

# Create inventory categories
InventoryCategory.objects.create(name="Vegetables", description="Fresh vegetables")
InventoryCategory.objects.create(name="Meat & Seafood", description="Fresh meat and seafood")
InventoryCategory.objects.create(name="Dairy", description="Milk products")

print("✅ Sample data created successfully!")
exit()

## 8. TEST THE SYSTEM

# Start development server
python manage.py runserver

# Test APIs (in another terminal):
curl -X GET "http://localhost:8000/api/tables/tables/" -H "Authorization: Bearer YOUR_JWT_TOKEN"
curl -X GET "http://localhost:8000/api/staff/profiles/" -H "Authorization: Bearer YOUR_JWT_TOKEN"
curl -X GET "http://localhost:8000/api/inventory/categories/" -H "Authorization: Bearer YOUR_JWT_TOKEN"

## 9. ACCESS ADMIN PANEL

# Create superuser if needed
python manage.py createsuperuser

# Visit http://localhost:8000/admin/ - you'll see new apps:
# - Table Management (Restaurant Tables, Table Orders, Order Items, Kitchen Display Items)
# - Staff Management (Staff Profiles, Attendance, Payment Records, Advance Payments)
# - Inventory Management (Categories, Items, Stock Movements, Low Stock Alerts)

## 10. PERMISSION VERIFICATION

# Test with different user roles:
# STAFF USER should be able to:
# ✅ Create tables and orders
# ✅ View kitchen display
# ✅ Generate bills
# ✅ View inventory items
# ✅ Mark attendance

# ADMIN USER should be able to:
# ✅ All staff operations PLUS
# ✅ Manage staff profiles and payments
# ✅ Modify inventory and stock
# ✅ Access all system settings

## PRODUCTION-READY FEATURES INCLUDED:

✅ Complete error handling and validation
✅ Proper database relationships with cascading
✅ Signal-based automatic updates
✅ Comprehensive admin interface
✅ Role-based permissions matching your existing system
✅ Search, filtering, and pagination support
✅ Bulk operations for efficiency
✅ Production-quality serializers with proper validation
✅ Comprehensive API documentation through ViewSets
✅ Proper HTTP status codes and error responses
✅ Database optimizations with select_related and prefetch_related
✅ Proper model properties for computed fields
✅ Django admin customizations for better usability

## NEXT PHASE READY:
- WebSocket consumers for real-time kitchen display
- Frontend React components
- Advanced reporting and analytics
- Mobile app integration
- Advanced inventory automation