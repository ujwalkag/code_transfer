
# apps/bills/urls.py - UPDATE TO INCLUDE ENHANCED BILLING ENDPOINTS

from . import views
from django.urls import path
from .analytics import BillHistoryView, BillAnalyticsView, BillSummaryView
from .views import (
    CreateRestaurantBillView,
    CreateRoomBillView,
    BillPDFView,
    BillDetailView,
    DailyBillReportView,
    get_orders_ready_for_billing,      # ADD THIS
    generate_bill_from_order,          # ADD THIS
)

urlpatterns = [
    path("create/restaurant/", CreateRestaurantBillView.as_view(), name="create-restaurant-bill"),
    path("create/room/", CreateRoomBillView.as_view(), name="create-room-bill"),
    path("summary/", BillSummaryView.as_view(), name="bill-summary"),
    path("analytics/", BillAnalyticsView.as_view()),
    path("history/", BillHistoryView.as_view(), name="bill-history"),
    path("<int:bill_id>/pdf/", BillPDFView.as_view(), name="bill-pdf"),
    path("<int:bill_id>/", BillDetailView.as_view(), name="bill-detail"),
    path("daily-report/", DailyBillReportView.as_view(), name="daily-report"),
    # ADD THESE NEW ENHANCED BILLING ENDPOINTS:
    path("orders_ready_for_billing/", get_orders_ready_for_billing, name="orders-ready-billing"),
    path("generate_bill_from_order/", generate_bill_from_order, name="generate-bill-from-order"),
]
