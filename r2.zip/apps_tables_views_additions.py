
# apps/tables/views.py - ADD THESE FUNCTIONS TO EXISTING FILE

from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404
from .models import RestaurantTable, TableOrder, OrderItem
from apps.menu.models import MenuItem

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_tables_layout(request):
    """Get all tables with current status for mobile waiter interface"""
    tables = RestaurantTable.objects.all().order_by('table_number')

    table_data = []
    for table in tables:
        # Check for active orders
        current_order = table.orders.filter(status__in=['pending', 'in_progress']).first()

        table_data.append({
            'id': table.id,
            'table_number': table.table_number,
            'capacity': table.capacity,
            'location': getattr(table, 'location', 'Main Hall'),  # Default location
            'is_occupied': table.is_occupied if hasattr(table, 'is_occupied') else bool(current_order),
            'is_active': getattr(table, 'is_active', True),  # Default active
            'current_order': {
                'id': current_order.id,
                'order_number': current_order.order_number,
                'customer_name': current_order.customer_name,
                'status': current_order.status,
                'total_amount': float(current_order.total_amount)
            } if current_order else None
        })

    return Response(table_data)

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def create_waiter_order(request):
    """Create order from mobile waiter interface"""
    data = request.data
    table_id = data.get('table_id') or data.get('table')
    items = data.get('items', [])

    if not table_id or not items:
        return Response({'error': 'table_id and items are required'}, 
                       status=status.HTTP_400_BAD_REQUEST)

    try:
        table = get_object_or_404(RestaurantTable, id=table_id)

        # Create the order - adapt to your TableOrder model structure
        order = TableOrder.objects.create(
            table=table,
            waiter=request.user,
            customer_name=data.get('customer_name', 'Guest'),
            customer_phone=data.get('customer_phone', ''),
            customer_count=data.get('customer_count', 1),
            special_instructions=data.get('special_instructions', ''),
            status='pending'
        )

        # Add order items
        total_amount = 0
        for item_data in items:
            menu_item_id = item_data.get('menu_item_id') or item_data.get('menu_item')
            menu_item = get_object_or_404(MenuItem, id=menu_item_id)

            order_item = OrderItem.objects.create(
                table_order=order,
                menu_item=menu_item,
                quantity=item_data.get('quantity', 1),
                price=menu_item.price,
                special_instructions=item_data.get('special_instructions', '')
            )
            total_amount += order_item.quantity * order_item.price

        # Update order total
        order.total_amount = total_amount
        order.save()

        # Mark table as occupied if it has that field
        if hasattr(table, 'is_occupied'):
            table.is_occupied = True
            table.save()

        return Response({
            'success': True,
            'order_id': order.id,
            'order_number': order.order_number,
            'total_amount': float(order.total_amount),
            'message': 'Order created successfully'
        })

    except Exception as e:
        return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
