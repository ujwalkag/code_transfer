
# apps/tables/mobile_urls.py - CREATE THIS FILE

from django.urls import path
from . import views

urlpatterns = [
    path('tables_layout/', views.get_tables_layout, name='mobile-tables-layout'),
    path('create_order/', views.create_waiter_order, name='mobile-create-order'),
]
