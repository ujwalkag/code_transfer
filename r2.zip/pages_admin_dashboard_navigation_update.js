
# pages/admin/dashboard.js - ADD NAVIGATION CARDS TO EXISTING FILE

// In the main navigation section, add these LinkCard components:

<LinkCard href="/admin/staff-management" label="👥 Staff Management / कर्मचारी प्रबंधन" />
<LinkCard href="/admin/enhanced-billing" label="💳 Enhanced Billing / एक-क्लिक बिलिंग" />
<LinkCard href="/waiter/mobile-orders" label="📱 Mobile Orders / मोबाइल ऑर्डर" />

// Also update the QuickActionCard section with:
<QuickActionCard 
  href="/admin/staff-management"
  icon="👥"
  title="Staff Management"
  subtitle="Attendance & Payroll"
  description="Track staff attendance, manage schedules, and process payroll"
/>

<QuickActionCard 
  href="/admin/enhanced-billing" 
  icon="💳"
  title="Enhanced Billing"
  subtitle="One-Click Bills"
  description="Generate bills with automatic GST calculation"
/>
