
# NAVIGATION AND ROUTING FIXES NEEDED:

## 1. UPDATE ADMIN DASHBOARD:

### pages/admin/dashboard.js - ADD NAVIGATION CARDS:
```javascript
// Add these cards to the dashboard
<LinkCard href="/admin/staff-management" label="👥 Staff Management" />
<LinkCard href="/admin/enhanced-billing" label="💳 Enhanced Billing" />
<LinkCard href="/waiter/mobile-orders" label="📱 Mobile Orders" />
```

## 2. UPDATE MAIN NAVIGATION:

### components/Sidebar.js or main navigation - ADD LINKS:
```javascript
const navigationItems = [
  // ... existing items
  { name: 'Staff Management', href: '/admin/staff-management', icon: '👥', roles: ['admin'] },
  { name: 'Enhanced Billing', href: '/admin/enhanced-billing', icon: '💳', roles: ['admin', 'staff'] },
  { name: 'Mobile Orders', href: '/waiter/mobile-orders', icon: '📱', roles: ['waiter', 'staff'] },
];
```

## 3. UPDATE BACKEND URLS:

### config/urls.py - ENSURE THESE ARE INCLUDED:
```python
urlpatterns = [
    # ... existing urls
    path('api/staff/', include('apps.staff.urls')),
    path('api/tables/mobile/', include('apps.tables.mobile_urls')),  # ADD THIS
    # Enhanced billing endpoints should be in bills urls
]
```
