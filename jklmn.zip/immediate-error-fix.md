# IMMEDIATE ERROR FIX - NO BREAKING CHANGES

## 🚨 STEP 1: Fix apps/staff/admin.py (Import Error)

Your `apps/staff/admin.py` is trying to import models that don't exist. Here are the **EXACT** fixes:

### Option A: Update admin.py to match existing models

```python
# apps/staff/admin.py - FIXED IMPORTS (No breaking changes)
from django.contrib import admin
from .models import StaffProfile  # Only import what exists

@admin.register(StaffProfile)
class StaffProfileAdmin(admin.ModelAdmin):
    list_display = ['name', 'employee_id', 'department', 'position', 'is_active']
    list_filter = ['department', 'is_active']
    search_fields = ['name', 'employee_id']
```

### Option B: Add missing models to your existing apps/staff/models.py

```python
# apps/staff/models.py - ADD ONLY MISSING MODELS (Keep existing StaffProfile)
from django.db import models

# Keep your existing StaffProfile model as-is
class StaffProfile(models.Model):
    # Your existing fields here - DON'T CHANGE
    pass

# Add only the missing models that admin.py is looking for
class AttendanceRecord(models.Model):
    staff = models.ForeignKey(StaffProfile, on_delete=models.CASCADE)
    date = models.DateField()
    check_in = models.TimeField(null=True, blank=True)
    check_out = models.TimeField(null=True, blank=True)
    hours_worked = models.DecimalField(max_digits=4, decimal_places=2, default=0)
    status = models.CharField(max_length=20, choices=[
        ('present', 'Present'),
        ('absent', 'Absent'),
        ('late', 'Late'),
    ], default='present')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'staff_attendance_records'
        unique_together = ['staff', 'date']

    def __str__(self):
        return f"{self.staff.name} - {self.date}"

class AdvancePayment(models.Model):
    staff = models.ForeignKey(StaffProfile, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    reason = models.CharField(max_length=200)
    date_requested = models.DateField()
    date_approved = models.DateField(null=True, blank=True)
    is_approved = models.BooleanField(default=False)
    is_paid = models.BooleanField(default=False)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'staff_advance_payments'

    def __str__(self):
        return f"{self.staff.name} - ₹{self.amount}"
```

## 🚨 STEP 2: Add ONLY Missing StaffProfileViewSet

### apps/staff/views.py - ADD ONLY THE MISSING VIEWSET

```python
# apps/staff/views.py - MINIMAL FIX (Don't break existing code)
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from .models import StaffProfile
from .serializers import StaffProfileSerializer

# Add ONLY this missing ViewSet - don't change existing code
class StaffProfileViewSet(viewsets.ModelViewSet):
    """Missing ViewSet that was causing the error"""
    queryset = StaffProfile.objects.all()
    serializer_class = StaffProfileSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        queryset = StaffProfile.objects.all()
        department = self.request.query_params.get('department')
        is_active = self.request.query_params.get('is_active')
        
        if department:
            queryset = queryset.filter(department=department)
        if is_active is not None:
            queryset = queryset.filter(is_active=is_active.lower() == 'true')
            
        return queryset.order_by('name')
    
    @action(detail=False, methods=['get'])
    def department_stats(self, request):
        """Get staff count by department"""
        from django.db.models import Count
        stats = StaffProfile.objects.values('department').annotate(
            total=Count('id'),
            active=Count('id', filter=models.Q(is_active=True))
        )
        return Response(list(stats))

# Don't add any other ViewSets unless they already exist
```

### apps/staff/serializers.py - ADD ONLY MISSING SERIALIZER

```python
# apps/staff/serializers.py - MINIMAL ADDITION
from rest_framework import serializers
from .models import StaffProfile

class StaffProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = StaffProfile
        fields = '__all__'
        read_only_fields = ['created_at', 'updated_at']

# Don't add other serializers unless needed
```

## 🚨 STEP 3: Fix Existing apps/staff/urls.py 

Check your current `apps/staff/urls.py`. If it has the StaffProfileViewSet reference, make sure it matches:

```python
# apps/staff/urls.py - MINIMAL FIX
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
# Only register the ViewSet that exists
router.register(r'profiles', views.StaffProfileViewSet, basename='staff-profile')

urlpatterns = [
    path('', include(router.urls)),
]
```

## ⚡ IMMEDIATE COMMANDS TO FIX ERROR

```bash
# 1. First, fix the admin.py file (choose Option A or B above)

# 2. Add the missing models if you chose Option B
python manage.py makemigrations staff

# 3. Apply migrations  
python manage.py migrate

# 4. Test the fix
python manage.py check

# 5. If successful, run server
python manage.py runserver
```

## 🔍 VERIFICATION STEPS

1. **Check your current apps/staff/models.py** - what models do you actually have?
2. **Check your current apps/staff/admin.py** - what imports are failing?
3. **Choose the minimal fix** - either update admin.py imports OR add missing models
4. **Don't change any existing functionality** - only fix the import error

## 📋 CURRENT ERROR ROOT CAUSE

Your `apps/staff/admin.py` file has:
```python
from .models import StaffProfile, AttendanceRecord, AdvancePayment
```

But your `apps/staff/models.py` only has `StaffProfile`, not the other two models.

**SOLUTION**: Either remove the imports from admin.py OR add the missing models to models.py.

Let me know which option you prefer, and I'll provide the exact code to paste without breaking anything!