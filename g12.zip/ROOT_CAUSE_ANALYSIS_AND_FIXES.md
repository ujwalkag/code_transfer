## 🎯 EXACT ROOT CAUSE ANALYSIS & SOLUTIONS

### 📍 **ISSUE 1: ROLE ASSIGNMENT SYSTEM**

**Current Role System Structure:**
- ✅ **Backend supports:** `admin`, `staff`, `waiter`, `biller` roles
- ✅ **Backend has permission fields:** `can_create_orders`, `can_generate_bills`, `can_access_kitchen`
- ❌ **Frontend Staff Creation:** Only creates `staff` role - missing role selection dropdown
- ❌ **Role Management UI:** No interface to assign/change roles after creation

**SOLUTION: Add Role Selection to Staff Creation**

```jsx
// IN StaffManagement.js - Update the Add Staff Modal
<div className="space-y-4">
  {/* Existing fields... */}
  
  {/* ADD ROLE SELECTION DROPDOWN */}
  <select
    value={newStaffData.role}
    onChange={(e) => setNewStaffData({...newStaffData, role: e.target.value})}
    className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
  >
    <option value="staff">Staff</option>
    <option value="waiter">Waiter</option>
    <option value="biller">Biller</option>
  </select>
  
  {/* ADD PERMISSIONS CHECKBOXES */}
  <div className="space-y-2">
    <label className="text-sm font-medium">Permissions:</label>
    
    <label className="flex items-center space-x-2">
      <input
        type="checkbox"
        checked={newStaffData.can_create_orders}
        onChange={(e) => setNewStaffData({...newStaffData, can_create_orders: e.target.checked})}
      />
      <span>Can Create Orders</span>
    </label>
    
    <label className="flex items-center space-x-2">
      <input
        type="checkbox"
        checked={newStaffData.can_generate_bills}
        onChange={(e) => setNewStaffData({...newStaffData, can_generate_bills: e.target.checked})}
      />
      <span>Can Generate Bills</span>
    </label>
    
    <label className="flex items-center space-x-2">
      <input
        type="checkbox"
        checked={newStaffData.can_access_kitchen}
        onChange={(e) => setNewStaffData({...newStaffData, can_access_kitchen: e.target.checked})}
      />
      <span>Can Access Kitchen</span>
    </label>
  </div>
</div>
```

**Updated Staff Creation Function:**
```jsx
const addNewStaff = async () => {
  // ... existing validation ...
  
  try {
    // Create user with selected role and permissions
    const userResponse = await fetch('/api/users/staff/', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${user.access}`
      },
      body: JSON.stringify({
        email: newStaffData.email,
        password: newStaffData.password,
        first_name: newStaffData.full_name.split(' ')[0],
        last_name: newStaffData.full_name.split(' ').slice(1).join(' '),
        role: newStaffData.role, // ADD THIS
        can_create_orders: newStaffData.can_create_orders, // ADD THIS
        can_generate_bills: newStaffData.can_generate_bills, // ADD THIS
        can_access_kitchen: newStaffData.can_access_kitchen // ADD THIS
      })
    });
    
    // ... rest of the function stays the same ...
  }
};
```

---

### 📍 **ISSUE 2: MOBILE INTERFACE NOT WORKING**

**Exact Root Causes Found:**

1. **Frontend AuthContext Mismatch:**
   - Mobile orders uses: `@/context/AuthContext` 
   - But there are TWO AuthContext files:
     - `/context/AuthContext.js` (newer, uses sessionStorage)
     - `/AuthContext.js` (older, uses localStorage)

2. **Role Guard Missing 'waiter':**
   - Mobile page: `withRoleGuard(EnhancedWaiterOrders, ['admin', 'staff', 'waiter'])`
   - But users created as 'staff' role, not 'waiter' role

3. **Permission System Mismatch:**
   - Backend permissions check: `can_create_orders` field
   - But staff created without this permission set to True

4. **Backend User Creation Missing Permission Assignment:**
   - Creating staff with role='staff' but not setting `can_create_orders=True`

**SOLUTIONS:**

### Fix 1: Update Backend User Creation to Auto-Set Permissions

```python
# In apps/users/views.py - Update StaffUserViewSet.create()
def create(self, request):
    """Create a new staff user"""
    try:
        email = request.data.get("email", "").strip().lower()
        password = request.data.get("password", "").strip()
        role = request.data.get("role", "staff")  # ADD THIS
        
        # ... existing validation ...
        
        # Create user with proper permissions
        with transaction.atomic():
            user_data = {
                'email': email,
                'password': password,
                'role': role  # ADD THIS
            }
            if first_name:
                user_data['first_name'] = first_name
            if last_name:
                user_data['last_name'] = last_name
            
            user = CustomUser.objects.create_user(**user_data)
            
            # AUTO-SET PERMISSIONS BASED ON ROLE
            if role == 'waiter':
                user.can_create_orders = True
                user.can_generate_bills = False
                user.can_access_kitchen = False
            elif role == 'staff':
                user.can_create_orders = True  # ADD THIS
                user.can_generate_bills = True
                user.can_access_kitchen = True
            elif role == 'biller':
                user.can_create_orders = False
                user.can_generate_bills = True
                user.can_access_kitchen = False
                
            user.save()
            
            return Response({
                'message': 'Staff user created successfully',
                'user': UserSerializer(user).data
            }, status=status.HTTP_201_CREATED)
```

### Fix 2: Update Mobile Interface Role Guard

```jsx
// In mobile-orders.js - Fix the role guard
export default withRoleGuard(EnhancedWaiterOrders, ['admin', 'staff', 'waiter']);
```

### Fix 3: Add Debug Mode to Mobile Interface

```jsx
// In mobile-orders.js - Add debug logging
const fetchInitialData = async () => {
  if (!user?.access) {
    console.log('DEBUG: No user access token');
    return;
  }

  console.log('DEBUG: User data:', user);
  console.log('DEBUG: User role:', user.role);
  console.log('DEBUG: Token:', user.access.substring(0, 20) + '...');

  try {
    setLoading(true);

    const tablesRes = await fetch('/api/tables/mobile/tables_layout/', {
      headers: { Authorization: `Bearer ${user.access}` }
    });

    console.log('DEBUG: Tables response status:', tablesRes.status);
    console.log('DEBUG: Tables response headers:', Object.fromEntries(tablesRes.headers.entries()));

    if (!tablesRes.ok) {
      const errorText = await tablesRes.text();
      console.log('DEBUG: Tables error response:', errorText);
      toast.error(`Tables API error: ${tablesRes.status} - ${errorText}`);
    } else {
      const tablesData = await tablesRes.json();
      console.log('DEBUG: Tables data received:', tablesData);
      setTables(Array.isArray(tablesData) ? tablesData : tablesData.results || []);
    }

    // ... similar debug logging for menu and categories ...
  } catch (error) {
    console.error('DEBUG: Network error:', error);
    toast.error('Network error: ' + error.message);
  } finally {
    setLoading(false);
  }
};
```

### Fix 4: Backend Permission Fix for Mobile API

```python
# In apps/tables/views.py - Update mobile API permissions
@api_view(['GET'])
@permission_classes([IsAuthenticated])  # Remove role restrictions temporarily for testing
def get_tables_layout(request):
    """Get all tables with current status for mobile waiter interface"""
    
    # ADD DEBUG LOGGING
    print(f"DEBUG: User accessing tables: {request.user.email}")
    print(f"DEBUG: User role: {getattr(request.user, 'role', 'No role')}")
    print(f"DEBUG: User permissions: can_create_orders={getattr(request.user, 'can_create_orders', False)}")
    
    tables = RestaurantTable.objects.all().order_by('table_number')

    table_data = []
    for table in tables:
        current_order = table.orders.filter(status__in=['pending', 'in_progress']).first()
        table_data.append({
            'id': table.id,
            'table_number': table.table_number,
            'capacity': table.capacity,
            'location': table.location,
            'is_occupied': table.is_occupied,
            'is_active': table.is_active,
            'current_order': {
                'id': current_order.id,
                'order_number': current_order.order_number,
                'customer_name': current_order.customer_name,
                'status': current_order.status,
                'total_amount': float(current_order.total_amount)
            } if current_order else None
        })

    print(f"DEBUG: Returning {len(table_data)} tables")
    return Response(table_data)
```

---

### 🚀 **DEPLOYMENT STEPS:**

1. **Update Frontend Staff Creation:**
   - Add role dropdown and permission checkboxes to staff modal
   - Update addNewStaff function to send role and permissions

2. **Update Backend User Creation:**
   - Modify StaffUserViewSet.create() to accept role parameter
   - Auto-assign permissions based on role

3. **Fix Mobile Interface:**
   - Add debug logging to identify exact authentication issue
   - Temporarily remove role restrictions from mobile APIs for testing

4. **Test Role Assignment:**
   - Create users with different roles (staff, waiter, biller)
   - Verify permissions are correctly assigned
   - Test mobile interface access with different roles

### ⚡ **IMMEDIATE TESTING COMMANDS:**

```bash
# Test mobile API directly
curl -X GET "https://hotelrshammad.co.in/api/tables/mobile/tables_layout/" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -v

# Check user permissions in Django admin or shell
python manage.py shell
>>> from apps.users.models import CustomUser
>>> user = CustomUser.objects.get(email="test@hotel.com")
>>> print(f"Role: {user.role}")
>>> print(f"Can create orders: {user.can_create_orders}")
>>> print(f"Can generate bills: {user.can_generate_bills}")
>>> print(f"Can access kitchen: {user.can_access_kitchen}")
```

**The mobile interface should work immediately after these fixes because all the frontend and backend code exists - it's just permission and role assignment issues blocking access.**