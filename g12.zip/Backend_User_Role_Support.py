# apps/users/views.py - ADD ROLE SUPPORT TO EXISTING StaffUserViewSet

# UPDATE the existing create method in StaffUserViewSet class:

def create(self, request):
    """Create a new staff user WITH ROLE AND PERMISSION SUPPORT"""
    try:
        email = request.data.get("email", "").strip().lower()
        password = request.data.get("password", "").strip()
        first_name = request.data.get("first_name", "").strip()
        last_name = request.data.get("last_name", "").strip()
        
        # NEW: Get role and permissions from request
        role = request.data.get("role", "staff")
        can_create_orders = request.data.get("can_create_orders", False)
        can_generate_bills = request.data.get("can_generate_bills", False)
        can_access_kitchen = request.data.get("can_access_kitchen", False)
        
        # Validation
        if not email or not password:
            return Response(
                {"error": "Email and password are required."}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        if len(password) < 8:
            return Response(
                {"error": "Password must be at least 8 characters long."}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        if CustomUser.objects.filter(email=email).exists():
            return Response(
                {"error": "Email already exists."}, 
                status=status.HTTP_409_CONFLICT
            )
        
        # Validate role
        valid_roles = ['admin', 'staff', 'waiter', 'biller']
        if role not in valid_roles:
            return Response(
                {"error": f"Invalid role. Must be one of: {', '.join(valid_roles)}"}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Create user with role and permissions
        with transaction.atomic():
            user_data = {
                'email': email,
                'password': password,
                'role': role  # ADD THIS
            }
            if first_name:
                user_data['first_name'] = first_name
            if last_name:
                user_data['last_name'] = last_name
            
            user = CustomUser.objects.create_user(**user_data)
            
            # Set permissions based on role and explicit permissions
            if role == 'waiter':
                user.can_create_orders = True
                user.can_generate_bills = False
                user.can_access_kitchen = False
            elif role == 'staff':
                user.can_create_orders = True
                user.can_generate_bills = True
                user.can_access_kitchen = True
            elif role == 'biller':
                user.can_create_orders = False
                user.can_generate_bills = True
                user.can_access_kitchen = False
            elif role == 'admin':
                user.can_create_orders = True
                user.can_generate_bills = True
                user.can_access_kitchen = True
            
            # Override with explicit permissions if provided
            if 'can_create_orders' in request.data:
                user.can_create_orders = can_create_orders
            if 'can_generate_bills' in request.data:
                user.can_generate_bills = can_generate_bills
            if 'can_access_kitchen' in request.data:
                user.can_access_kitchen = can_access_kitchen
                
            user.save()
            
            return Response({
                'message': f'{role.capitalize()} user created successfully',
                'user': UserSerializer(user).data
            }, status=status.HTTP_201_CREATED)
        
    except Exception as e:
        return Response(
            {'error': f'Failed to create user: {str(e)}'}, 
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

# ADD this method to the existing StaffUserViewSet class:
@action(detail=True, methods=['patch'])
def update_permissions(self, request, pk=None):
    """Update user role and permissions"""
    try:
        user = CustomUser.objects.get(id=pk)
        
        # Prevent modifying admin users
        if user.role == 'admin' and request.user.role != 'admin':
            return Response(
                {'error': 'Cannot modify admin permissions'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Get new role and permissions
        new_role = request.data.get('role', user.role)
        can_create_orders = request.data.get('can_create_orders', user.can_create_orders)
        can_generate_bills = request.data.get('can_generate_bills', user.can_generate_bills)
        can_access_kitchen = request.data.get('can_access_kitchen', user.can_access_kitchen)
        
        # Validate role
        valid_roles = ['admin', 'staff', 'waiter', 'biller']
        if new_role not in valid_roles:
            return Response(
                {'error': f'Invalid role. Must be one of: {", ".join(valid_roles)}'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Update user
        user.role = new_role
        user.can_create_orders = can_create_orders
        user.can_generate_bills = can_generate_bills
        user.can_access_kitchen = can_access_kitchen
        user.save()
        
        return Response({
            'message': 'Permissions updated successfully',
            'user': UserSerializer(user).data
        }, status=status.HTTP_200_OK)
        
    except CustomUser.DoesNotExist:
        return Response(
            {'error': 'User not found'}, 
            status=status.HTTP_404_NOT_FOUND
        )
    except Exception as e:
        return Response(
            {'error': f'An error occurred: {str(e)}'}, 
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )

# UPDATE the existing list method to show all roles, not just 'staff':
def list(self, request):
    """List all staff users (all non-admin roles)"""
    try:
        # Show staff, waiter, and biller roles (exclude admin for security)
        staff_users = CustomUser.objects.filter(role__in=['staff', 'waiter', 'biller'])
        serializer = UserSerializer(staff_users, many=True)
        return Response({
            'count': staff_users.count(),
            'results': serializer.data
        }, status=status.HTTP_200_OK)
    except Exception as e:
        return Response(
            {'error': f'Failed to retrieve staff users: {str(e)}'}, 
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )