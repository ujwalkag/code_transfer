# Mobile Interface Debug & Fix Script
# Run this to diagnose and fix mobile interface issues

# apps/tables/views.py - ADD DEBUG LOGGING TO MOBILE API

@api_view(['GET'])
@permission_classes([IsAuthenticated])  # Temporarily remove role restrictions
def get_tables_layout(request):
    """Get all tables with current status for mobile waiter interface - WITH DEBUG"""
    
    # COMPREHENSIVE DEBUG LOGGING
    print(f"=== MOBILE TABLES API DEBUG ===")
    print(f"User: {request.user.email}")
    print(f"User ID: {request.user.id}")
    print(f"User Role: {getattr(request.user, 'role', 'NO ROLE')}")
    print(f"User Active: {request.user.is_active}")
    print(f"User Authenticated: {request.user.is_authenticated}")
    print(f"Can Create Orders: {getattr(request.user, 'can_create_orders', 'NO PERMISSION FIELD')}")
    print(f"Can Generate Bills: {getattr(request.user, 'can_generate_bills', 'NO PERMISSION FIELD')}")
    print(f"Can Access Kitchen: {getattr(request.user, 'can_access_kitchen', 'NO PERMISSION FIELD')}")
    print(f"Request Headers: {dict(request.headers)}")
    
    try:
        tables = RestaurantTable.objects.all().order_by('table_number')
        print(f"Found {tables.count()} tables in database")

        table_data = []
        for table in tables:
            # Handle different ways current_order might be accessed
            current_order = None
            try:
                # Method 1: Direct property
                if hasattr(table, 'current_order'):
                    current_order = table.current_order
                # Method 2: Related manager
                elif hasattr(table, 'orders'):
                    current_order = table.orders.filter(status__in=['pending', 'in_progress']).first()
            except Exception as e:
                print(f"Error getting current order for table {table.id}: {e}")
                current_order = None
            
            table_info = {
                'id': table.id,
                'table_number': table.table_number,
                'capacity': table.capacity,
                'location': getattr(table, 'location', 'Main Hall'),
                'is_occupied': table.is_occupied,
                'is_active': getattr(table, 'is_active', True),
                'current_order': {
                    'id': current_order.id,
                    'order_number': getattr(current_order, 'order_number', f'ORD-{current_order.id}'),
                    'customer_name': getattr(current_order, 'customer_name', 'Guest'),
                    'status': current_order.status,
                    'total_amount': float(current_order.total_amount)
                } if current_order else None
            }
            table_data.append(table_info)

        print(f"Returning {len(table_data)} tables to frontend")
        print(f"Sample table data: {table_data[0] if table_data else 'No tables'}")
        print(f"=== END DEBUG ===")
        
        return Response({
            'status': 'success',
            'user_info': {
                'email': request.user.email,
                'role': getattr(request.user, 'role', 'unknown'),
                'can_create_orders': getattr(request.user, 'can_create_orders', False),
            },
            'tables': table_data,
            'debug': True
        })
        
    except Exception as e:
        print(f"ERROR in get_tables_layout: {str(e)}")
        print(f"Exception type: {type(e)}")
        import traceback
        print(f"Traceback: {traceback.format_exc()}")
        
        return Response({
            'error': f'Internal server error: {str(e)}',
            'debug_info': {
                'user': request.user.email,
                'role': getattr(request.user, 'role', 'unknown'),
            }
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


@api_view(['POST'])
@permission_classes([IsAuthenticated])  # Temporarily remove role restrictions
def create_waiter_order(request):
    """Create order from mobile waiter interface - WITH DEBUG"""
    
    print(f"=== MOBILE ORDER CREATION DEBUG ===")
    print(f"User: {request.user.email}")
    print(f"Request data: {request.data}")
    
    data = request.data
    table_id = data.get('table_id') or data.get('table')
    items = data.get('items', [])

    if not table_id or not items:
        error_msg = f'Missing required fields: table_id={table_id}, items_count={len(items)}'
        print(f"ERROR: {error_msg}")
        return Response({'error': error_msg}, status=status.HTTP_400_BAD_REQUEST)

    try:
        from apps.menu.models import MenuItem
        
        # Get table
        table = get_object_or_404(RestaurantTable, id=table_id)
        print(f"Found table: {table.table_number}")
        
        # Create the order
        order = TableOrder.objects.create(
            table=table,
            waiter=request.user,
            customer_name=data.get('customer_name', 'Guest'),
            customer_phone=data.get('customer_phone', ''),
            customer_count=data.get('customer_count', 1),
            special_instructions=data.get('special_instructions', '')
        )
        print(f"Created order: {order.id}")

        # Add order items
        total_amount = 0
        created_items = []
        
        for item_data in items:
            try:
                menu_item_id = item_data.get('menu_item_id') or item_data.get('menu_item')
                menu_item = get_object_or_404(MenuItem, id=menu_item_id)
                
                order_item = OrderItem.objects.create(
                    table_order=order,
                    menu_item=menu_item,
                    quantity=item_data.get('quantity', 1),
                    price=menu_item.price,
                    special_instructions=item_data.get('special_instructions', '')
                )
                
                item_total = order_item.quantity * order_item.price
                total_amount += item_total
                created_items.append({
                    'name': menu_item.name_en if hasattr(menu_item, 'name_en') else str(menu_item),
                    'quantity': order_item.quantity,
                    'price': float(order_item.price),
                    'total': float(item_total)
                })
                
                print(f"Added item: {menu_item} x{order_item.quantity} = ₹{item_total}")
                
            except Exception as item_error:
                print(f"Error adding item {item_data}: {item_error}")
                continue

        # Update order total and table status
        order.total_amount = total_amount
        order.save()
        
        table.is_occupied = True
        table.save()
        
        print(f"Order completed: Total ₹{total_amount}, Items: {len(created_items)}")
        print(f"=== END DEBUG ===")

        return Response({
            'success': True,
            'order_id': order.id,
            'order_number': getattr(order, 'order_number', f'ORD-{order.id}'),
            'total_amount': float(order.total_amount),
            'items_added': len(created_items),
            'items': created_items,
            'message': 'Order created successfully',
            'debug': {
                'table_id': table_id,
                'user': request.user.email,
                'items_requested': len(items),
                'items_created': len(created_items)
            }
        })

    except Exception as e:
        print(f"ERROR in create_waiter_order: {str(e)}")
        import traceback
        print(f"Traceback: {traceback.format_exc()}")
        
        return Response({
            'error': f'Failed to create order: {str(e)}',
            'debug_info': {
                'table_id': table_id,
                'items_count': len(items),
                'user': request.user.email
            }
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


# TESTING SCRIPT for debugging mobile interface
"""
Run this in Django shell to test permissions:

from apps.users.models import CustomUser
from apps.tables.models import RestaurantTable

# Check user permissions
user = CustomUser.objects.get(email="your_test_user@hotel.com")
print(f"User: {user.email}")
print(f"Role: {user.role}")
print(f"Can create orders: {user.can_create_orders}")
print(f"Can generate bills: {user.can_generate_bills}")
print(f"Can access kitchen: {user.can_access_kitchen}")

# Check if tables exist
tables = RestaurantTable.objects.all()
print(f"Total tables: {tables.count()}")
for table in tables[:5]:  # Show first 5
    print(f"Table {table.table_number}: {table.is_occupied}")

# Test API call simulation
from django.test import RequestFactory
from django.contrib.auth import get_user_model
from apps.tables.views import get_tables_layout

factory = RequestFactory()
request = factory.get('/api/tables/mobile/tables_layout/')
request.user = user

response = get_tables_layout(request)
print(f"API Response Status: {response.status_code}")
print(f"API Response Data: {response.data}")
"""

# QUICK PERMISSION FIX - Run this in Django shell:
"""
from apps.users.models import CustomUser

# Give all staff users mobile access permissions
staff_users = CustomUser.objects.filter(role__in=['staff', 'waiter'])
for user in staff_users:
    user.can_create_orders = True
    if user.role == 'staff':
        user.can_generate_bills = True
        user.can_access_kitchen = True
    user.save()
    print(f"Updated permissions for {user.email}")

print("All staff now have mobile access permissions!")
"""