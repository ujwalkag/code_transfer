// pages/admin/dashboard.js - ADD THESE NAVIGATION LINKS
// Replace your existing LinkCard section with this complete version:

{/* Main Navigation Cards */}
<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
  <LinkCard href="/admin/manage-menu" label="🍽️ Menu Management / मेन्यू प्रबंधन" />
  <LinkCard href="/admin/manage-rooms" label="🏨 Room Management / कमरा प्रबंधन" />
  <LinkCard href="/admin/manage-staff" label="👤 Basic Staff / बेसिक स्टाफ" />
  <LinkCard href="/admin/staff-management" label="👥 Staff Management / कर्मचारी प्रबंधन" />
  <LinkCard href="/admin/enhanced-billing" label="💳 Enhanced Billing / एक-क्लिक बिलिंग" />
  <LinkCard href="/waiter/mobile-orders" label="📱 Mobile Orders / मोबाइल ऑर्डर" />
  <LinkCard href="/admin/billing" label="💰 Standard Billing / मानक बिलिंग" />
  <LinkCard href="/admin/bill-history" label="📊 Bill History / बिल इतिहास" />
  <LinkCard href="/admin/inventory" label="📦 Inventory / इन्वेंटरी" />
  <LinkCard href="/kitchen" label="🍳 Kitchen Display / किचन डिस्प्ले" />
</div>

{/* Quick Action Cards - Replace existing section with this */}
<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
  <QuickActionCard 
    href="/admin/staff-management"
    icon="👥"
    title="Staff Management"
    subtitle="Attendance & Payroll"
    description="Track staff attendance, manage schedules, and process payroll"
  />
  <QuickActionCard 
    href="/admin/enhanced-billing" 
    icon="💳"
    title="Enhanced Billing"
    subtitle="One-Click Bills"
    description="Generate bills with automatic GST calculation from completed orders"
  />
  <QuickActionCard 
    href="/waiter/mobile-orders"
    icon="📱"
    title="Mobile Orders"
    subtitle="Waiter Interface"
    description="Mobile-friendly interface for waiters to take orders"
  />
  <QuickActionCard 
    href="/kitchen"
    icon="🍳"
    title="Kitchen Display"
    subtitle="Order Status"
    description="Real-time kitchen display for order management"
  />
</div>
