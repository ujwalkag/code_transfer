# URL Configuration Updates for Complete Hotel Management System

## 1. apps/staff/urls.py - ADD PAYROLL ENDPOINTS
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

# Create router and register viewsets
router = DefaultRouter()
router.register(r'profiles', views.StaffProfileViewSet, basename='staffprofile')
router.register(r'attendance', views.AttendanceViewSet, basename='attendance')

urlpatterns = [
    # Include router URLs
    path('', include(router.urls)),
    
    # NEW: Payroll endpoints
    path('payroll/generate/', views.generate_payroll, name='generate-payroll'),
    path('payroll/history/', views.get_payroll_history, name='payroll-history'),
    path('payroll/bulk-generate/', views.bulk_generate_payroll, name='bulk-generate-payroll'),
]

## 2. apps/users/urls.py - ADD STAFF USER CREATION
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register(r'staff', views.StaffUserViewSet, basename='staff-users')

urlpatterns = [
    path('', include(router.urls)),
    
    # NEW: Staff user creation endpoint
    path('staff/create/', views.create_staff_user, name='create-staff-user'),
]

## 3. config/urls.py - VERIFY ALL ROUTES ARE INCLUDED
from django.contrib import admin
from django.urls import path, include
from apps.users.views import CustomTokenObtainPairView
from rest_framework_simplejwt.views import TokenRefreshView

urlpatterns = [
    # Authentication
    path('api/auth/token/', CustomTokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/auth/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    
    # Admin
    path('admin/', admin.site.urls),
    
    # Core APIs
    path('api/core/', include('apps.core.urls')),
    path('api/menu/', include('apps.menu.urls')),
    path('api/rooms/', include('apps.rooms.urls')),
    path('api/users/', include('apps.users.urls')),
    path('api/bills/', include('apps.bills.urls')),
    path('api/inventory/', include('apps.inventory.urls')),
    path('api/notifications/', include('apps.notifications.urls')),
    
    # Staff Management (CRITICAL)
    path('api/staff/', include('apps.staff.urls')),
    
    # Table Management (CRITICAL)
    path('api/tables/', include('apps.tables.urls')),
    
    # Mobile Waiter Routes (CRITICAL)
    path('api/tables/mobile/', include('apps.tables.mobile_urls')),
    
    # Enhanced Billing Routes (if needed)
    # path('api/bills/enhanced/', include('apps.bills.enhanced_urls')),
]

## 4. VERIFY MOBILE URLs - apps/tables/mobile_urls.py
from django.urls import path
from .views import get_tables_layout, create_waiter_order

urlpatterns = [
    path('tables_layout/', get_tables_layout, name='mobile-tables-layout'),
    path('create_order/', create_waiter_order, name='mobile-create-order'),
]

## 5. COMPLETE API ENDPOINT LIST FOR TESTING

### Staff Management APIs:
- GET /api/staff/profiles/ - List all staff
- POST /api/staff/profiles/ - Create new staff profile
- GET /api/staff/profiles/{id}/ - Get specific staff
- PUT /api/staff/profiles/{id}/ - Update staff
- DELETE /api/staff/profiles/{id}/ - Delete staff

- GET /api/staff/attendance/ - List attendance records
- POST /api/staff/attendance/mark_attendance/ - Mark attendance
- POST /api/staff/payroll/generate/ - Generate payroll (NEW)
- GET /api/staff/payroll/history/ - Get payroll history (NEW)

### User Management APIs:
- GET /api/users/staff/ - List staff users
- POST /api/users/staff/create/ - Create staff user (NEW)
- DELETE /api/users/staff/{id}/ - Delete staff user

### Mobile Waiter APIs:
- GET /api/tables/mobile/tables_layout/ - Get table layout
- POST /api/tables/mobile/create_order/ - Create waiter order

### Table Management APIs:
- GET /api/tables/tables/ - List tables
- GET /api/tables/orders/ - List orders
- POST /api/tables/orders/ - Create order
- GET /api/tables/kitchen/ - Kitchen display

### Billing APIs:
- GET /api/bills/ - List bills
- POST /api/bills/ - Create bill
- GET /api/bills/orders_ready_for_billing/ - Enhanced billing

## 6. TESTING COMMANDS FOR ALL APIS

# Test staff creation flow
curl -X POST "https://hotelrshammad.co.in/api/users/staff/create/" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "newstaff@hotel.com",
    "password": "StaffPass123",
    "role": "staff"
  }'

# Test staff profile creation
curl -X POST "https://hotelrshammad.co.in/api/staff/profiles/" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "user": USER_ID_FROM_PREVIOUS_CALL,
    "full_name": "New Staff Member",
    "phone": "1234567890",
    "department": "service",
    "position": "Waiter",
    "base_salary": "25000",
    "hourly_rate": "150"
  }'

# Test staff deletion
curl -X DELETE "https://hotelrshammad.co.in/api/staff/profiles/STAFF_ID/" \
  -H "Authorization: Bearer YOUR_TOKEN"

# Test mobile orders
curl -X GET "https://hotelrshammad.co.in/api/tables/mobile/tables_layout/" \
  -H "Authorization: Bearer YOUR_TOKEN"

# Test payroll generation
curl -X POST "https://hotelrshammad.co.in/api/staff/payroll/generate/" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "staff_id": STAFF_ID,
    "month": 9,
    "year": 2025
  }'

## 7. DEPLOYMENT VERIFICATION SCRIPT

#!/bin/bash
echo "🔧 Verifying Hotel Management API Deployment..."

# Test authentication
echo "1. Testing authentication..."
TOKEN=$(curl -s -X POST "https://hotelrshammad.co.in/api/auth/token/" \
  -H "Content-Type: application/json" \
  -d '{"email": "admin@hotel.com", "password": "AdminPass123"}' \
  | jq -r '.access')

if [ "$TOKEN" = "null" ]; then
    echo "❌ Authentication failed"
    exit 1
else
    echo "✅ Authentication successful"
fi

# Test mobile tables API
echo "2. Testing mobile tables API..."
RESPONSE=$(curl -s -o /dev/null -w "%{http_code}" \
  -H "Authorization: Bearer $TOKEN" \
  "https://hotelrshammad.co.in/api/tables/mobile/tables_layout/")

if [ $RESPONSE -eq 200 ]; then
    echo "✅ Mobile tables API working"
else
    echo "❌ Mobile tables API failed (HTTP $RESPONSE)"
fi

# Test staff profiles API
echo "3. Testing staff profiles API..."
RESPONSE=$(curl -s -o /dev/null -w "%{http_code}" \
  -H "Authorization: Bearer $TOKEN" \
  "https://hotelrshammad.co.in/api/staff/profiles/")

if [ $RESPONSE -eq 200 ]; then
    echo "✅ Staff profiles API working"
else
    echo "❌ Staff profiles API failed (HTTP $RESPONSE)"
fi

# Test staff user creation API
echo "4. Testing staff user creation API..."
RESPONSE=$(curl -s -o /dev/null -w "%{http_code}" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"email": "test@test.com", "password": "test"}' \
  "https://hotelrshammad.co.in/api/users/staff/create/")

if [ $RESPONSE -eq 201 ] || [ $RESPONSE -eq 400 ]; then
    echo "✅ Staff user creation API working"
else
    echo "❌ Staff user creation API failed (HTTP $RESPONSE)"
fi

echo "🎉 API verification complete!"

## 8. FRONTEND ROUTE VERIFICATION

# Make sure these frontend routes exist and work:
- /waiter/mobile-orders - Mobile waiter interface
- /admin/staff-management - Staff management with add/delete
- /kitchen - Kitchen display
- /admin/enhanced-billing - Enhanced billing interface

## 9. COMPLETE FUNCTIONALITY CHECKLIST

After deployment, verify these features work:
□ Mobile Orders: Table selection, menu browsing, order creation
□ Staff Management: View staff list, add new staff, delete staff
□ Attendance: Mark present/absent, view monthly stats
□ Payroll: Generate payroll, view calculations
□ Kitchen Display: Real-time order updates
□ Enhanced Billing: One-click bill generation with GST

## 10. TROUBLESHOOTING COMMON ISSUES

### Issue: Mobile orders not loading tables
- Check: /api/tables/mobile/tables_layout/ returns 200
- Check: Frontend has correct Authorization header
- Check: Tables exist in database

### Issue: Staff add button not working
- Check: Updated StaffManagement.js is deployed
- Check: /api/users/staff/create/ endpoint exists
- Check: /api/staff/profiles/ accepts POST requests

### Issue: Staff delete not working
- Check: DELETE /api/staff/profiles/{id}/ endpoint works
- Check: Proper error handling for soft vs hard delete
- Check: User has admin permissions

### Issue: Payroll generation not working
- Check: /api/staff/payroll/generate/ endpoint exists
- Check: Staff has attendance records for the month
- Check: Base salary and hourly rate are set