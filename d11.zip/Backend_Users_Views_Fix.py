# apps/users/views.py - ADD STAFF USER CREATION ENDPOINT

from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from .models import CustomUser

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def create_staff_user(request):
    """Create new staff user account"""
    email = request.data.get('email')
    password = request.data.get('password')
    role = request.data.get('role', 'staff')
    
    if not email or not password:
        return Response({
            'error': 'Email and password are required'
        }, status=status.HTTP_400_BAD_REQUEST)
    
    try:
        # Check if user already exists
        if CustomUser.objects.filter(email=email).exists():
            return Response({
                'error': 'User with this email already exists'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        # Create user
        user = CustomUser.objects.create_user(
            email=email,
            password=password,
            role=role
        )
        
        return Response({
            'success': True,
            'user_id': user.id,
            'email': user.email,
            'role': user.role,
            'message': 'Staff user created successfully'
        }, status=status.HTTP_201_CREATED)
        
    except Exception as e:
        return Response({
            'error': f'Failed to create user: {str(e)}'
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

# ADD TO EXISTING StaffUserViewSet class
class StaffUserViewSet(viewsets.ModelViewSet):
    serializer_class = UserSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        return CustomUser.objects.filter(role='staff')
    
    def destroy(self, request, *args, **kwargs):
        """Enhanced delete with proper error handling"""
        try:
            instance = self.get_object()
            
            # Check if user has a staff profile
            if hasattr(instance, 'staff_profile'):
                # Check if staff has any related records
                staff_profile = instance.staff_profile
                if staff_profile.attendance_records.exists():
                    # Soft delete - mark as terminated instead
                    staff_profile.employment_status = 'terminated'
                    staff_profile.save()
                    return Response({
                        'success': True,
                        'message': 'Staff marked as terminated (has attendance history)'
                    })
            
            # Hard delete if no related records
            instance.delete()
            return Response({
                'success': True,
                'message': 'Staff deleted successfully'
            })
                
        except Exception as e:
            return Response({
                'error': f'Failed to delete staff: {str(e)}'
            }, status=status.HTTP_400_BAD_REQUEST)
    
    def create(self, request):
        """Create staff user with enhanced error handling"""
        email = request.data.get('email')
        password = request.data.get('password')
        
        if not email or not password:
            return Response({
                'error': 'Email and password are required'
            }, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            # Check if user already exists
            if CustomUser.objects.filter(email=email).exists():
                return Response({
                    'error': 'User with this email already exists'
                }, status=status.HTTP_400_BAD_REQUEST)
            
            user = CustomUser.objects.create_user(
                email=email,
                password=password,
                role='staff'
            )
            
            return Response({
                'success': True,
                'user_id': user.id,
                'email': user.email,
                'message': 'Staff user created successfully'
            }, status=status.HTTP_201_CREATED)
            
        except Exception as e:
            return Response({
                'error': f'Failed to create staff user: {str(e)}'
            }, status=status.HTTP_400_BAD_REQUEST)