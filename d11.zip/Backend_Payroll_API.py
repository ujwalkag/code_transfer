# apps/staff/views.py - ADD PAYROLL GENERATION API

from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from django.utils import timezone
from django.shortcuts import get_object_or_404
from decimal import Decimal
from .models import StaffProfile, AttendanceRecord

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def generate_payroll(request):
    """Generate monthly payroll for staff"""
    staff_id = request.data.get('staff_id')
    month = request.data.get('month', timezone.now().month)
    year = request.data.get('year', timezone.now().year)
    
    if not staff_id:
        return Response({
            'error': 'staff_id is required'
        }, status=status.HTTP_400_BAD_REQUEST)
    
    try:
        staff = get_object_or_404(StaffProfile, id=staff_id)
        
        # Get attendance records for the month
        attendance_records = AttendanceRecord.objects.filter(
            staff=staff,
            date__month=month,
            date__year=year
        )
        
        # Calculate payroll metrics
        total_days_present = attendance_records.filter(status='present').count()
        total_days_absent = attendance_records.filter(status='absent').count()
        total_days_half = attendance_records.filter(status='half_day').count()
        total_days_late = attendance_records.filter(status='late').count()
        
        # Calculate hours
        total_hours = sum(float(record.total_hours or 0) for record in attendance_records)
        overtime_hours = sum(float(record.overtime_hours or 0) for record in attendance_records)
        regular_hours = total_hours - overtime_hours
        
        # Calculate amounts
        base_salary = float(staff.base_salary or 0)
        hourly_rate = float(staff.hourly_rate or 0)
        
        # Standard calculations (you can modify this logic)
        # Assume 26 working days per month, 8 hours per day
        expected_days = 26
        expected_hours = expected_days * 8
        
        # Calculate daily rate
        daily_rate = base_salary / expected_days if expected_days > 0 else 0
        
        # Calculate deductions for absent days
        absence_deduction = total_days_absent * daily_rate
        half_day_deduction = total_days_half * (daily_rate / 2)
        
        # Calculate overtime amount (1.5x rate for overtime hours)
        overtime_amount = overtime_hours * hourly_rate * 1.5 if hourly_rate > 0 else 0
        
        # Calculate gross salary
        gross_salary = base_salary - absence_deduction - half_day_deduction + overtime_amount
        
        # Calculate deductions (you can add more deduction types)
        provident_fund = gross_salary * 0.12  # 12% PF
        professional_tax = 200 if gross_salary > 21000 else 150  # Example PT
        
        # Calculate net salary
        total_deductions = provident_fund + professional_tax
        net_salary = gross_salary - total_deductions
        
        # Create payroll data
        payroll_data = {
            'staff_id': staff_id,
            'staff_name': staff.full_name,
            'employee_id': staff.employee_id,
            'month': month,
            'year': year,
            'period': f"{timezone.datetime(year, month, 1).strftime('%B %Y')}",
            
            # Attendance metrics
            'total_days_present': total_days_present,
            'total_days_absent': total_days_absent,
            'total_days_half': total_days_half,
            'total_days_late': total_days_late,
            'total_hours': round(total_hours, 2),
            'regular_hours': round(regular_hours, 2),
            'overtime_hours': round(overtime_hours, 2),
            
            # Salary calculations
            'base_salary': round(base_salary, 2),
            'daily_rate': round(daily_rate, 2),
            'hourly_rate': round(hourly_rate, 2),
            
            # Deductions
            'absence_deduction': round(absence_deduction, 2),
            'half_day_deduction': round(half_day_deduction, 2),
            
            # Additions
            'overtime_amount': round(overtime_amount, 2),
            
            # Final amounts
            'gross_salary': round(gross_salary, 2),
            'provident_fund': round(provident_fund, 2),
            'professional_tax': round(professional_tax, 2),
            'total_deductions': round(total_deductions, 2),
            'net_salary': round(net_salary, 2),
            
            'generated_at': timezone.now().isoformat(),
            'generated_by': request.user.email
        }
        
        # Optional: Save payroll record to database (create PayrollRecord model)
        # PayrollRecord.objects.create(**payroll_data)
        
        return Response({
            'success': True,
            'payroll': payroll_data,
            'message': f'Payroll generated successfully for {staff.full_name}'
        })
        
    except StaffProfile.DoesNotExist:
        return Response({
            'error': 'Staff member not found'
        }, status=status.HTTP_404_NOT_FOUND)
        
    except Exception as e:
        return Response({
            'error': f'Failed to generate payroll: {str(e)}'
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_payroll_history(request):
    """Get payroll history for all staff or specific staff"""
    staff_id = request.query_params.get('staff_id')
    month = request.query_params.get('month')
    year = request.query_params.get('year')
    
    # This is a placeholder - you would implement this with a PayrollRecord model
    return Response({
        'message': 'Payroll history endpoint - implement with PayrollRecord model',
        'filters': {
            'staff_id': staff_id,
            'month': month,
            'year': year
        }
    })

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def bulk_generate_payroll(request):
    """Generate payroll for multiple staff members"""
    staff_ids = request.data.get('staff_ids', [])
    month = request.data.get('month', timezone.now().month)
    year = request.data.get('year', timezone.now().year)
    
    if not staff_ids:
        # Generate for all active staff if no specific IDs provided
        staff_ids = list(StaffProfile.objects.filter(
            employment_status='active'
        ).values_list('id', flat=True))
    
    results = []
    errors = []
    
    for staff_id in staff_ids:
        try:
            # Use the same logic as generate_payroll but in bulk
            staff = StaffProfile.objects.get(id=staff_id)
            
            # Call generate_payroll logic here (you can refactor it into a helper function)
            # For now, just indicate success
            results.append({
                'staff_id': staff_id,
                'staff_name': staff.full_name,
                'status': 'success'
            })
            
        except StaffProfile.DoesNotExist:
            errors.append({
                'staff_id': staff_id,
                'error': 'Staff not found'
            })
        except Exception as e:
            errors.append({
                'staff_id': staff_id,
                'error': str(e)
            })
    
    return Response({
        'success': True,
        'total_processed': len(staff_ids),
        'successful': len(results),
        'failed': len(errors),
        'results': results,
        'errors': errors if errors else None,
        'message': f'Bulk payroll generation completed for {month}/{year}'
    })

# ADD TO StaffProfileViewSet class to enhance deletion
class StaffProfileViewSet(viewsets.ModelViewSet):
    queryset = StaffProfile.objects.all()
    serializer_class = StaffProfileSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        queryset = super().get_queryset()
        department = self.request.query_params.get('department', None)
        status = self.request.query_params.get('status', None)

        if department:
            queryset = queryset.filter(department=department)
        if status:
            queryset = queryset.filter(employment_status=status)

        return queryset.order_by('-created_at')

    def destroy(self, request, *args, **kwargs):
        """Enhanced delete with proper error handling and soft delete option"""
        try:
            instance = self.get_object()
            staff_name = instance.full_name
            
            # Check if staff has any related attendance records
            has_attendance = instance.attendance_records.exists()
            has_advance_payments = hasattr(instance, 'advance_payments') and instance.advance_payments.exists()
            
            if has_attendance or has_advance_payments:
                # Soft delete - mark as terminated instead of hard delete
                instance.employment_status = 'terminated'
                instance.save()
                
                # Also deactivate the user account
                if instance.user:
                    instance.user.is_active = False
                    instance.user.save()
                
                return Response({
                    'success': True,
                    'type': 'soft_delete',
                    'message': f'{staff_name} has been marked as terminated (has historical data)',
                    'attendance_records': instance.attendance_records.count(),
                    'advance_payments': instance.advance_payments.count() if has_advance_payments else 0
                })
            else:
                # Hard delete if no related records
                user_to_delete = instance.user
                instance.delete()
                
                # Delete associated user account
                if user_to_delete:
                    user_to_delete.delete()
                
                return Response({
                    'success': True,
                    'type': 'hard_delete',
                    'message': f'{staff_name} has been permanently deleted'
                })
                
        except Exception as e:
            return Response({
                'success': False,
                'error': f'Failed to delete staff: {str(e)}'
            }, status=status.HTTP_400_BAD_REQUEST)

    def create(self, request, *args, **kwargs):
        """Enhanced create with better error handling"""
        try:
            # Validate required fields
            required_fields = ['full_name', 'user']
            for field in required_fields:
                if not request.data.get(field):
                    return Response({
                        'error': f'{field} is required'
                    }, status=status.HTTP_400_BAD_REQUEST)
            
            # Create staff profile
            serializer = self.get_serializer(data=request.data)
            if serializer.is_valid():
                staff = serializer.save()
                return Response({
                    'success': True,
                    'staff_id': staff.id,
                    'employee_id': staff.employee_id,
                    'full_name': staff.full_name,
                    'message': 'Staff profile created successfully'
                }, status=status.HTTP_201_CREATED)
            else:
                return Response({
                    'error': 'Validation failed',
                    'details': serializer.errors
                }, status=status.HTTP_400_BAD_REQUEST)
                
        except Exception as e:
            return Response({
                'error': f'Failed to create staff: {str(e)}'
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)