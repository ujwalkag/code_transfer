# Hotel Management System - Part 3: Billing & Kitchen Apps

## BILLING APP (Enhanced Billing with GST)

### apps/billing/models.py
```python
from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from apps.orders.models import Order
from apps.tables.models import Table
from decimal import Decimal
import uuid

class Bill(models.Model):
    PAYMENT_STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('partial', 'Partially Paid'),
        ('paid', 'Fully Paid'),
        ('cancelled', 'Cancelled'),
        ('refunded', 'Refunded'),
    ]

    PAYMENT_METHOD_CHOICES = [
        ('cash', 'Cash'),
        ('card', 'Credit/Debit Card'),
        ('upi', 'UPI'),
        ('digital_wallet', 'Digital Wallet'),
        ('bank_transfer', 'Bank Transfer'),
        ('split', 'Split Payment'),
    ]

    bill_number = models.CharField(max_length=20, unique=True)
    table = models.ForeignKey(Table, on_delete=models.CASCADE, related_name='bills')
    orders = models.ManyToManyField(Order, related_name='bills')
    
    # Customer Information
    customer_name = models.CharField(max_length=100, blank=True)
    customer_phone = models.CharField(max_length=15, blank=True)
    customer_email = models.EmailField(blank=True)
    
    # Bill Calculations
    items_subtotal = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    discount_percentage = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    discount_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    
    # GST Implementation
    cgst_rate = models.DecimalField(max_digits=5, decimal_places=2, default=9.0)  # Central GST
    sgst_rate = models.DecimalField(max_digits=5, decimal_places=2, default=9.0)  # State GST
    igst_rate = models.DecimalField(max_digits=5, decimal_places=2, default=0.0)   # Integrated GST
    cgst_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    sgst_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    igst_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    total_tax_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    
    service_charge_percentage = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    service_charge_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    
    # Final Amounts
    gross_total = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    net_total = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    
    # Payment Information
    payment_status = models.CharField(max_length=20, choices=PAYMENT_STATUS_CHOICES, default='pending')
    payment_method = models.CharField(max_length=20, choices=PAYMENT_METHOD_CHOICES, blank=True)
    amount_paid = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    change_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    
    # Additional Information
    notes = models.TextField(blank=True)
    special_instructions = models.TextField(blank=True)
    is_complimentary = models.BooleanField(default=False)
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    paid_at = models.DateTimeField(null=True, blank=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'bills'
        verbose_name = 'Bill'
        verbose_name_plural = 'Bills'
        ordering = ['-created_at']

    def __str__(self):
        return f"Bill {self.bill_number} - Table {self.table.table_number}"

    def save(self, *args, **kwargs):
        if not self.bill_number:
            import datetime
            date_str = datetime.datetime.now().strftime('%Y%m%d')
            bill_count = Bill.objects.filter(created_at__date=datetime.date.today()).count() + 1
            self.bill_number = f"BILL{date_str}{bill_count:04d}"
        super().save(*args, **kwargs)

    def calculate_totals(self):
        """Calculate all bill totals including GST"""
        # Calculate items subtotal from all orders
        orders_total = Decimal('0.00')
        for order in self.orders.all():
            orders_total += order.total_amount
        
        # Add custom items
        custom_items_total = sum(item.subtotal for item in self.custom_items.all())
        self.items_subtotal = orders_total + custom_items_total
        
        # Calculate discount
        if self.discount_percentage > 0:
            self.discount_amount = (self.items_subtotal * self.discount_percentage) / Decimal('100.00')
        
        # Calculate gross total after discount
        self.gross_total = self.items_subtotal - self.discount_amount
        
        # Calculate service charge
        if self.service_charge_percentage > 0:
            self.service_charge_amount = (self.gross_total * self.service_charge_percentage) / Decimal('100.00')
        
        # Add service charge to gross total
        taxable_amount = self.gross_total + self.service_charge_amount
        
        # Calculate GST
        if self.igst_rate > 0:
            # Inter-state transaction
            self.igst_amount = (taxable_amount * self.igst_rate) / Decimal('100.00')
            self.cgst_amount = Decimal('0.00')
            self.sgst_amount = Decimal('0.00')
        else:
            # Intra-state transaction
            self.cgst_amount = (taxable_amount * self.cgst_rate) / Decimal('100.00')
            self.sgst_amount = (taxable_amount * self.sgst_rate) / Decimal('100.00')
            self.igst_amount = Decimal('0.00')
        
        self.total_tax_amount = self.cgst_amount + self.sgst_amount + self.igst_amount
        
        # Calculate final net total
        self.net_total = taxable_amount + self.total_tax_amount
        
        self.save()
        return self.net_total

    def process_payment(self, amount_received, payment_method):
        """Process payment for the bill"""
        self.amount_paid += Decimal(str(amount_received))
        self.payment_method = payment_method
        
        if self.amount_paid >= self.net_total:
            self.payment_status = 'paid'
            self.change_amount = self.amount_paid - self.net_total
            self.paid_at = models.timezone.now()
            
            # Mark table as available after payment
            self.table.mark_available()
            
            # Update all orders status to billed
            self.orders.update(status='billed')
            
        elif self.amount_paid > 0:
            self.payment_status = 'partial'
        
        self.save()

class BillItem(models.Model):
    """Custom items that admin can add to bills"""
    bill = models.ForeignKey(Bill, on_delete=models.CASCADE, related_name='custom_items')
    item_name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    quantity = models.IntegerField(default=1, validators=[MinValueValidator(1)])
    unit_price = models.DecimalField(max_digits=8, decimal_places=2, validators=[MinValueValidator(0)])
    subtotal = models.DecimalField(max_digits=10, decimal_places=2)
    is_taxable = models.BooleanField(default=True)
    category = models.CharField(max_length=50, blank=True)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'bill_items'
        verbose_name = 'Bill Item'
        verbose_name_plural = 'Bill Items'

    def save(self, *args, **kwargs):
        self.subtotal = self.unit_price * self.quantity
        super().save(*args, **kwargs)
        # Recalculate bill totals
        self.bill.calculate_totals()

    def __str__(self):
        return f"{self.item_name} x {self.quantity} - {self.bill.bill_number}"

class Payment(models.Model):
    """Track individual payments for split payments"""
    PAYMENT_TYPE_CHOICES = [
        ('full', 'Full Payment'),
        ('partial', 'Partial Payment'),
        ('advance', 'Advance Payment'),
        ('refund', 'Refund'),
    ]

    bill = models.ForeignKey(Bill, on_delete=models.CASCADE, related_name='payments')
    payment_type = models.CharField(max_length=20, choices=PAYMENT_TYPE_CHOICES, default='full')
    amount = models.DecimalField(max_digits=12, decimal_places=2, validators=[MinValueValidator(0)])
    payment_method = models.CharField(max_length=20, choices=Bill.PAYMENT_METHOD_CHOICES)
    reference_number = models.CharField(max_length=100, blank=True)  # Transaction ID, check number, etc.
    received_by = models.CharField(max_length=100, blank=True)
    notes = models.TextField(blank=True)
    is_verified = models.BooleanField(default=False)
    processed_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'bill_payments'
        verbose_name = 'Payment'
        verbose_name_plural = 'Payments'
        ordering = ['-processed_at']

    def __str__(self):
        return f"Payment {self.amount} - {self.bill.bill_number}"

class BillTemplate(models.Model):
    """Templates for different types of bills"""
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    
    # Default settings
    default_cgst_rate = models.DecimalField(max_digits=5, decimal_places=2, default=9.0)
    default_sgst_rate = models.DecimalField(max_digits=5, decimal_places=2, default=9.0)
    default_service_charge = models.DecimalField(max_digits=5, decimal_places=2, default=0.0)
    
    # Template settings
    show_customer_details = models.BooleanField(default=True)
    show_gst_breakdown = models.BooleanField(default=True)
    show_service_charge = models.BooleanField(default=False)
    show_item_wise_tax = models.BooleanField(default=False)
    
    # Company/Restaurant details
    company_name = models.CharField(max_length=200)
    company_address = models.TextField()
    gstin_number = models.CharField(max_length=15, blank=True)
    phone_number = models.CharField(max_length=15, blank=True)
    email = models.EmailField(blank=True)
    
    is_active = models.BooleanField(default=True)
    is_default = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'bill_templates'
        verbose_name = 'Bill Template'
        verbose_name_plural = 'Bill Templates'

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        if self.is_default:
            # Ensure only one default template
            BillTemplate.objects.filter(is_default=True).update(is_default=False)
        super().save(*args, **kwargs)

class BillHistory(models.Model):
    """Track bill modifications for audit trail"""
    ACTION_CHOICES = [
        ('created', 'Bill Created'),
        ('item_added', 'Item Added'),
        ('item_removed', 'Item Removed'),
        ('discount_applied', 'Discount Applied'),
        ('payment_received', 'Payment Received'),
        ('cancelled', 'Bill Cancelled'),
        ('refunded', 'Bill Refunded'),
    ]

    bill = models.ForeignKey(Bill, on_delete=models.CASCADE, related_name='history')
    action = models.CharField(max_length=20, choices=ACTION_CHOICES)
    description = models.TextField()
    modified_by = models.CharField(max_length=100)
    previous_amount = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    new_amount = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'bill_history'
        verbose_name = 'Bill History'
        verbose_name_plural = 'Bill History'
        ordering = ['-timestamp']

    def __str__(self):
        return f"{self.bill.bill_number} - {self.action}"
```

### apps/billing/serializers.py
```python
from rest_framework import serializers
from .models import Bill, BillItem, Payment, BillTemplate, BillHistory

class BillItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = BillItem
        fields = '__all__'
        read_only_fields = ['subtotal', 'created_at', 'updated_at']

class PaymentSerializer(serializers.ModelSerializer):
    payment_method_display = serializers.CharField(source='get_payment_method_display', read_only=True)
    
    class Meta:
        model = Payment
        fields = '__all__'
        read_only_fields = ['processed_at']

class BillSerializer(serializers.ModelSerializer):
    table_number = serializers.CharField(source='table.table_number', read_only=True)
    custom_items = BillItemSerializer(many=True, read_only=True)
    payments = PaymentSerializer(many=True, read_only=True)
    payment_status_display = serializers.CharField(source='get_payment_status_display', read_only=True)
    orders_list = serializers.SerializerMethodField()
    balance_amount = serializers.SerializerMethodField()
    
    class Meta:
        model = Bill
        fields = '__all__'
        read_only_fields = [
            'bill_number', 'items_subtotal', 'discount_amount', 
            'cgst_amount', 'sgst_amount', 'igst_amount', 'total_tax_amount',
            'service_charge_amount', 'gross_total', 'net_total',
            'created_at', 'updated_at', 'paid_at'
        ]

    def get_orders_list(self, obj):
        return [order.order_number for order in obj.orders.all()]

    def get_balance_amount(self, obj):
        return obj.net_total - obj.amount_paid

class BillTemplateSerializer(serializers.ModelSerializer):
    class Meta:
        model = BillTemplate
        fields = '__all__'
        read_only_fields = ['created_at']

class BillHistorySerializer(serializers.ModelSerializer):
    action_display = serializers.CharField(source='get_action_display', read_only=True)
    
    class Meta:
        model = BillHistory
        fields = '__all__'
        read_only_fields = ['timestamp']
```

### apps/billing/views.py
```python
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from django.db.models import Q, Sum
from django.db import transaction
from datetime import datetime, date
from decimal import Decimal

from .models import Bill, BillItem, Payment, BillTemplate, BillHistory
from .serializers import (
    BillSerializer, BillItemSerializer, PaymentSerializer,
    BillTemplateSerializer, BillHistorySerializer
)
from apps.tables.models import Table
from apps.orders.models import Order

class BillViewSet(viewsets.ModelViewSet):
    queryset = Bill.objects.all()
    serializer_class = BillSerializer

    def get_queryset(self):
        queryset = Bill.objects.all()
        table_id = self.request.query_params.get('table_id')
        status_filter = self.request.query_params.get('status')
        date_filter = self.request.query_params.get('date')
        
        if table_id:
            queryset = queryset.filter(table_id=table_id)
        if status_filter:
            queryset = queryset.filter(payment_status=status_filter)
        if date_filter:
            queryset = queryset.filter(created_at__date=date_filter)
            
        return queryset.order_by('-created_at')

    @action(detail=False, methods=['post'])
    def create_from_table_orders(self, request):
        """Create bill from table orders - Enhanced Billing Feature"""
        table_id = request.data.get('table_id')
        
        if not table_id:
            return Response(
                {'error': 'table_id is required'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        table = get_object_or_404(Table, id=table_id)
        
        # Get all unbilled orders for the table
        orders = Order.objects.filter(
            table=table,
            status__in=['confirmed', 'preparing', 'ready', 'served']
        )
        
        if not orders.exists():
            return Response(
                {'error': 'No active orders found for this table'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Create bill
        bill = Bill.objects.create(
            table=table,
            customer_name=request.data.get('customer_name', ''),
            customer_phone=request.data.get('customer_phone', ''),
            customer_email=request.data.get('customer_email', ''),
            notes=request.data.get('notes', '')
        )
        
        # Add orders to bill
        bill.orders.set(orders)
        
        # Calculate totals
        bill.calculate_totals()
        
        # Log creation
        BillHistory.objects.create(
            bill=bill,
            action='created',
            description=f'Bill created for table {table.table_number} with {orders.count()} orders',
            modified_by=request.user.username if request.user.is_authenticated else 'System',
            new_amount=bill.net_total
        )
        
        return Response(BillSerializer(bill).data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=['post'])
    def add_custom_item(self, request, pk=None):
        """Add custom item to bill - Admin can add/edit items"""
        bill = self.get_object()
        
        if bill.payment_status == 'paid':
            return Response(
                {'error': 'Cannot modify paid bill'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        item_data = {
            'bill': bill.id,
            'item_name': request.data.get('item_name'),
            'description': request.data.get('description', ''),
            'quantity': request.data.get('quantity', 1),
            'unit_price': request.data.get('unit_price'),
            'is_taxable': request.data.get('is_taxable', True),
            'category': request.data.get('category', ''),
            'notes': request.data.get('notes', '')
        }
        
        serializer = BillItemSerializer(data=item_data)
        if serializer.is_valid():
            item = serializer.save()
            
            # Log addition
            BillHistory.objects.create(
                bill=bill,
                action='item_added',
                description=f'Added custom item: {item.item_name} x {item.quantity}',
                modified_by=request.user.username if request.user.is_authenticated else 'Admin',
                previous_amount=bill.net_total - item.subtotal,
                new_amount=bill.net_total
            )
            
            return Response(BillItemSerializer(item).data, status=status.HTTP_201_CREATED)
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=['patch'])
    def apply_discount(self, request, pk=None):
        """Apply discount to bill"""
        bill = self.get_object()
        
        if bill.payment_status == 'paid':
            return Response(
                {'error': 'Cannot modify paid bill'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        discount_percentage = request.data.get('discount_percentage', 0)
        discount_amount = request.data.get('discount_amount', 0)
        
        previous_total = bill.net_total
        
        if discount_percentage:
            bill.discount_percentage = Decimal(str(discount_percentage))
        elif discount_amount:
            bill.discount_amount = Decimal(str(discount_amount))
            if bill.items_subtotal > 0:
                bill.discount_percentage = (bill.discount_amount / bill.items_subtotal) * 100
        
        bill.calculate_totals()
        
        # Log discount
        BillHistory.objects.create(
            bill=bill,
            action='discount_applied',
            description=f'Applied discount: {bill.discount_percentage}% (₹{bill.discount_amount})',
            modified_by=request.user.username if request.user.is_authenticated else 'Admin',
            previous_amount=previous_total,
            new_amount=bill.net_total
        )
        
        return Response(BillSerializer(bill).data)

    @action(detail=True, methods=['post'])
    def process_payment(self, request, pk=None):
        """Process payment for bill"""
        bill = self.get_object()
        
        amount = Decimal(str(request.data.get('amount', 0)))
        payment_method = request.data.get('payment_method')
        
        if amount <= 0:
            return Response(
                {'error': 'Payment amount must be greater than 0'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        if not payment_method:
            return Response(
                {'error': 'Payment method is required'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        with transaction.atomic():
            # Create payment record
            payment = Payment.objects.create(
                bill=bill,
                amount=amount,
                payment_method=payment_method,
                reference_number=request.data.get('reference_number', ''),
                received_by=request.user.username if request.user.is_authenticated else 'Staff',
                notes=request.data.get('notes', '')
            )
            
            # Process payment on bill
            bill.process_payment(amount, payment_method)
            
            # Log payment
            BillHistory.objects.create(
                bill=bill,
                action='payment_received',
                description=f'Payment received: ₹{amount} via {payment_method}',
                modified_by=request.user.username if request.user.is_authenticated else 'Staff',
                new_amount=bill.amount_paid
            )
        
        return Response({
            'bill': BillSerializer(bill).data,
            'payment': PaymentSerializer(payment).data,
            'message': 'Payment processed successfully'
        })

    @action(detail=True, methods=['post'])
    def generate_gst_bill(self, request, pk=None):
        """Generate GST compliant bill"""
        bill = self.get_object()
        
        # Apply GST settings
        gst_enabled = request.data.get('apply_gst', True)
        interstate = request.data.get('interstate', False)
        
        if gst_enabled:
            if interstate:
                bill.igst_rate = Decimal('18.0')
                bill.cgst_rate = Decimal('0.0')
                bill.sgst_rate = Decimal('0.0')
            else:
                bill.cgst_rate = Decimal('9.0')
                bill.sgst_rate = Decimal('9.0')
                bill.igst_rate = Decimal('0.0')
        
        # Apply service charge if specified
        service_charge = request.data.get('service_charge_percentage', 0)
        if service_charge:
            bill.service_charge_percentage = Decimal(str(service_charge))
        
        bill.calculate_totals()
        
        return Response({
            'bill': BillSerializer(bill).data,
            'gst_breakdown': {
                'cgst': {'rate': bill.cgst_rate, 'amount': bill.cgst_amount},
                'sgst': {'rate': bill.sgst_rate, 'amount': bill.sgst_amount},
                'igst': {'rate': bill.igst_rate, 'amount': bill.igst_amount},
                'total_tax': bill.total_tax_amount
            }
        })

    @action(detail=False, methods=['get'])
    def enhanced_billing_dashboard(self, request):
        """Dashboard view for enhanced billing - shows all active table orders"""
        # Get all tables with active orders
        active_tables = Table.objects.filter(
            orders__status__in=['confirmed', 'preparing', 'ready', 'served']
        ).distinct().order_by('table_number')
        
        dashboard_data = []
        
        for table in active_tables:
            active_orders = table.orders.filter(
                status__in=['confirmed', 'preparing', 'ready', 'served']
            )
            
            total_amount = sum(order.total_amount for order in active_orders)
            
            dashboard_data.append({
                'table_id': table.id,
                'table_number': table.table_number,
                'table_status': table.status,
                'orders_count': active_orders.count(),
                'total_amount': total_amount,
                'orders': [
                    {
                        'order_number': order.order_number,
                        'status': order.status,
                        'total_amount': order.total_amount,
                        'items_count': order.items.count()
                    }
                    for order in active_orders
                ],
                'can_generate_bill': active_orders.filter(status='served').exists()
            })
        
        return Response({
            'active_tables': dashboard_data,
            'total_tables': len(dashboard_data),
            'total_revenue_pending': sum(table['total_amount'] for table in dashboard_data)
        })

    @action(detail=False, methods=['get'])
    def daily_sales_report(self, request):
        """Generate daily sales report"""
        report_date = request.query_params.get('date', date.today())
        
        bills = Bill.objects.filter(created_at__date=report_date)
        
        report = {
            'date': report_date,
            'total_bills': bills.count(),
            'paid_bills': bills.filter(payment_status='paid').count(),
            'pending_bills': bills.filter(payment_status='pending').count(),
            'total_revenue': bills.filter(payment_status='paid').aggregate(Sum('net_total'))['net_total__sum'] or 0,
            'total_tax_collected': bills.filter(payment_status='paid').aggregate(Sum('total_tax_amount'))['total_tax_amount__sum'] or 0,
            'payment_method_breakdown': {},
            'hourly_sales': []
        }
        
        # Payment method breakdown
        for method, _ in Bill.PAYMENT_METHOD_CHOICES:
            count = bills.filter(payment_method=method, payment_status='paid').count()
            amount = bills.filter(payment_method=method, payment_status='paid').aggregate(Sum('net_total'))['net_total__sum'] or 0
            if count > 0:
                report['payment_method_breakdown'][method] = {'count': count, 'amount': amount}
        
        return Response(report)

class BillItemViewSet(viewsets.ModelViewSet):
    queryset = BillItem.objects.all()
    serializer_class = BillItemSerializer

    @action(detail=True, methods=['patch'])
    def update_item(self, request, pk=None):
        """Update bill item - Admin functionality"""
        item = self.get_object()
        
        if item.bill.payment_status == 'paid':
            return Response(
                {'error': 'Cannot modify items in paid bill'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        previous_subtotal = item.subtotal
        
        serializer = BillItemSerializer(item, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            
            # Log modification
            BillHistory.objects.create(
                bill=item.bill,
                action='item_modified',
                description=f'Modified item: {item.item_name}',
                modified_by=request.user.username if request.user.is_authenticated else 'Admin',
                previous_amount=previous_subtotal,
                new_amount=item.subtotal
            )
            
            return Response(serializer.data)
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=['delete'])
    def delete_item(self, request, pk=None):
        """Delete bill item - Admin functionality"""
        item = self.get_object()
        
        if item.bill.payment_status == 'paid':
            return Response(
                {'error': 'Cannot delete items from paid bill'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Log deletion before removing
        BillHistory.objects.create(
            bill=item.bill,
            action='item_removed',
            description=f'Removed item: {item.item_name} x {item.quantity}',
            modified_by=request.user.username if request.user.is_authenticated else 'Admin',
            previous_amount=item.subtotal,
            new_amount=0
        )
        
        item.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

class PaymentViewSet(viewsets.ModelViewSet):
    queryset = Payment.objects.all()
    serializer_class = PaymentSerializer

class BillTemplateViewSet(viewsets.ModelViewSet):
    queryset = BillTemplate.objects.filter(is_active=True)
    serializer_class = BillTemplateSerializer
```

### apps/billing/urls.py
```python
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register(r'bills', views.BillViewSet, basename='bill')
router.register(r'bill-items', views.BillItemViewSet, basename='billitem')
router.register(r'payments', views.PaymentViewSet, basename='payment')
router.register(r'templates', views.BillTemplateViewSet, basename='billtemplate')

urlpatterns = [
    path('', include(router.urls)),
]
```

---

## KITCHEN APP (With Audio Module)

### apps/kitchen/models.py
```python
from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from apps.orders.models import Order, OrderItem
from django.utils import timezone

class KitchenStation(models.Model):
    """Different cooking stations in the kitchen"""
    STATION_TYPES = [
        ('hot_kitchen', 'Hot Kitchen'),
        ('cold_kitchen', 'Cold Kitchen'), 
        ('grill', 'Grill Station'),
        ('fryer', 'Fryer Station'),
        ('salad', 'Salad Station'),
        ('dessert', 'Dessert Station'),
        ('beverage', 'Beverage Station'),
    ]

    name = models.CharField(max_length=50)
    station_type = models.CharField(max_length=20, choices=STATION_TYPES)
    description = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)
    display_order = models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'kitchen_stations'
        verbose_name = 'Kitchen Station'
        verbose_name_plural = 'Kitchen Stations'
        ordering = ['display_order', 'name']

    def __str__(self):
        return f"{self.name} ({self.get_station_type_display()})"

class KitchenDisplay(models.Model):
    STATUS_CHOICES = [
        ('new', 'New Order'),
        ('acknowledged', 'Acknowledged'),
        ('preparing', 'Preparing'),
        ('ready', 'Ready to Serve'),
        ('served', 'Served'),
        ('cancelled', 'Cancelled'),
    ]

    PRIORITY_CHOICES = [
        (1, 'Low'),
        (2, 'Normal'), 
        (3, 'High'),
        (4, 'Urgent'),
        (5, 'Critical'),
    ]

    order = models.OneToOneField(Order, on_delete=models.CASCADE, related_name='kitchen_display')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='new')
    priority = models.IntegerField(choices=PRIORITY_CHOICES, default=2)
    estimated_time = models.IntegerField(help_text="Estimated preparation time in minutes", default=30)
    actual_preparation_time = models.IntegerField(null=True, blank=True, help_text="Actual time taken in minutes")
    
    # Kitchen staff assignment
    assigned_chef = models.CharField(max_length=100, blank=True)
    assigned_station = models.ForeignKey(KitchenStation, on_delete=models.SET_NULL, null=True, blank=True)
    
    # Timing information
    received_at = models.DateTimeField(auto_now_add=True)
    acknowledged_at = models.DateTimeField(null=True, blank=True)
    started_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    served_at = models.DateTimeField(null=True, blank=True)
    
    # Additional information
    kitchen_notes = models.TextField(blank=True)
    special_instructions = models.TextField(blank=True)
    delay_reason = models.CharField(max_length=200, blank=True)
    
    # Audio alert settings
    audio_played = models.BooleanField(default=False)
    audio_acknowledged = models.BooleanField(default=False)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'kitchen_display'
        verbose_name = 'Kitchen Display Order'
        verbose_name_plural = 'Kitchen Display Orders'
        ordering = ['priority', 'received_at']

    def __str__(self):
        return f"Kitchen Order {self.order.order_number} - {self.get_status_display()}"

    def acknowledge_order(self, chef_name):
        """Acknowledge the order and start preparation"""
        self.status = 'acknowledged'
        self.acknowledged_at = timezone.now()
        self.assigned_chef = chef_name
        self.audio_acknowledged = True
        self.save()

    def start_preparation(self):
        """Mark order as being prepared"""
        if self.status == 'acknowledged':
            self.status = 'preparing'
            self.started_at = timezone.now()
            self.save()

    def mark_ready(self):
        """Mark order as ready to serve"""
        if self.status == 'preparing':
            self.status = 'ready'
            self.completed_at = timezone.now()
            
            # Calculate actual preparation time
            if self.started_at:
                prep_time = (self.completed_at - self.started_at).total_seconds() / 60
                self.actual_preparation_time = int(prep_time)
            
            self.save()
            
            # Update main order status
            self.order.update_status('ready')
            
            # Trigger ready notification
            from .tasks import notify_service_staff_order_ready
            notify_service_staff_order_ready.delay(self.order.id)

    def mark_served(self):
        """Mark order as served"""
        if self.status == 'ready':
            self.status = 'served'
            self.served_at = timezone.now()
            self.save()
            
            # Update main order status
            self.order.update_status('served')

class KitchenItemStatus(models.Model):
    """Track individual item preparation status"""
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('preparing', 'Preparing'),
        ('ready', 'Ready'),
        ('served', 'Served'),
    ]

    kitchen_display = models.ForeignKey(KitchenDisplay, on_delete=models.CASCADE, related_name='item_status')
    order_item = models.OneToOneField(OrderItem, on_delete=models.CASCADE, related_name='kitchen_status')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    assigned_station = models.ForeignKey(KitchenStation, on_delete=models.SET_NULL, null=True, blank=True)
    preparation_notes = models.TextField(blank=True)
    estimated_time = models.IntegerField(default=15, help_text="Time in minutes")
    actual_time = models.IntegerField(null=True, blank=True, help_text="Actual time in minutes")
    started_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'kitchen_item_status'
        verbose_name = 'Kitchen Item Status'
        verbose_name_plural = 'Kitchen Item Status'

    def __str__(self):
        return f"{self.order_item.menu_item.name} - {self.get_status_display()}"

    def start_preparation(self):
        """Start preparing this item"""
        self.status = 'preparing'
        self.started_at = timezone.now()
        self.save()

    def mark_ready(self):
        """Mark this item as ready"""
        self.status = 'ready'
        self.completed_at = timezone.now()
        
        if self.started_at:
            prep_time = (self.completed_at - self.started_at).total_seconds() / 60
            self.actual_time = int(prep_time)
        
        self.save()
        
        # Check if all items in the order are ready
        kitchen_display = self.kitchen_display
        all_items_ready = all(
            item.status == 'ready' 
            for item in kitchen_display.item_status.all()
        )
        
        if all_items_ready and kitchen_display.status == 'preparing':
            kitchen_display.mark_ready()

class AudioAlert(models.Model):
    """Audio alert configurations for kitchen notifications"""
    ALERT_TYPE_CHOICES = [
        ('new_order', 'New Order Alert'),
        ('priority_order', 'Priority Order Alert'),
        ('order_ready', 'Order Ready Alert'),
        ('table_request', 'Table Service Request'),
        ('kitchen_timer', 'Kitchen Timer Alert'),
    ]

    alert_type = models.CharField(max_length=20, choices=ALERT_TYPE_CHOICES)
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    audio_file = models.FileField(upload_to='kitchen_audio/', null=True, blank=True)
    text_to_speech = models.TextField(blank=True, help_text="Text to be converted to speech")
    volume = models.IntegerField(default=80, validators=[MinValueValidator(0), MaxValueValidator(100)])
    repeat_count = models.IntegerField(default=1, validators=[MinValueValidator(1), MaxValueValidator(5)])
    repeat_interval = models.IntegerField(default=5, help_text="Seconds between repeats")
    is_active = models.BooleanField(default=True)
    priority = models.IntegerField(default=1, help_text="Higher number = higher priority")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'kitchen_audio_alerts'
        verbose_name = 'Audio Alert'
        verbose_name_plural = 'Audio Alerts'
        ordering = ['-priority', 'alert_type']

    def __str__(self):
        return f"{self.name} ({self.get_alert_type_display()})"

class KitchenTimer(models.Model):
    """Kitchen timers for cooking processes"""
    kitchen_display = models.ForeignKey(KitchenDisplay, on_delete=models.CASCADE, related_name='timers', null=True, blank=True)
    order_item = models.ForeignKey(OrderItem, on_delete=models.CASCADE, related_name='kitchen_timers', null=True, blank=True)
    timer_name = models.CharField(max_length=100)
    duration_minutes = models.IntegerField()
    started_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    is_active = models.BooleanField(default=False)
    is_completed = models.BooleanField(default=False)
    alert_sent = models.BooleanField(default=False)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'kitchen_timers'
        verbose_name = 'Kitchen Timer'
        verbose_name_plural = 'Kitchen Timers'

    def __str__(self):
        return f"{self.timer_name} - {self.duration_minutes}min"

    def start_timer(self):
        """Start the timer"""
        self.is_active = True
        self.started_at = timezone.now()
        self.save()

    def complete_timer(self):
        """Complete the timer"""
        self.is_active = False
        self.is_completed = True
        self.completed_at = timezone.now()
        self.save()

class KitchenMetrics(models.Model):
    """Daily kitchen performance metrics"""
    date = models.DateField(unique=True)
    total_orders = models.IntegerField(default=0)
    completed_orders = models.IntegerField(default=0)
    average_prep_time = models.FloatField(default=0)
    delayed_orders = models.IntegerField(default=0)
    cancelled_orders = models.IntegerField(default=0)
    peak_hour = models.CharField(max_length=20, blank=True)
    total_items_prepared = models.IntegerField(default=0)
    efficiency_score = models.FloatField(default=0, help_text="Percentage score based on targets")
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'kitchen_metrics'
        verbose_name = 'Kitchen Metrics'
        verbose_name_plural = 'Kitchen Metrics'
        ordering = ['-date']

    def __str__(self):
        return f"Kitchen Metrics - {self.date}"

    def calculate_metrics(self):
        """Calculate daily metrics"""
        from django.db.models import Avg, Count
        
        kitchen_orders = KitchenDisplay.objects.filter(
            received_at__date=self.date
        )
        
        self.total_orders = kitchen_orders.count()
        self.completed_orders = kitchen_orders.filter(status='served').count()
        self.delayed_orders = kitchen_orders.filter(
            actual_preparation_time__gt=models.F('estimated_time')
        ).count()
        self.cancelled_orders = kitchen_orders.filter(status='cancelled').count()
        
        # Calculate average preparation time
        avg_time = kitchen_orders.filter(
            actual_preparation_time__isnull=False
        ).aggregate(Avg('actual_preparation_time'))['actual_preparation_time__avg']
        
        self.average_prep_time = avg_time or 0
        
        # Calculate efficiency score
        if self.total_orders > 0:
            completion_rate = (self.completed_orders / self.total_orders) * 100
            on_time_rate = ((self.total_orders - self.delayed_orders) / self.total_orders) * 100
            self.efficiency_score = (completion_rate + on_time_rate) / 2
        
        self.save()
```

### apps/kitchen/consumers.py (WebSocket for real-time updates)
```python
import json
from channels.generic.websocket import AsyncWebsocketConsumer
from channels.db import database_sync_to_async
from .models import KitchenDisplay, AudioAlert

class KitchenConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        # Join kitchen group
        await self.channel_layer.group_add(
            'kitchen_orders',
            self.channel_name
        )
        await self.accept()

    async def disconnect(self, close_code):
        # Leave kitchen group
        await self.channel_layer.group_discard(
            'kitchen_orders',
            self.channel_name
        )

    async def receive(self, text_data):
        data = json.loads(text_data)
        message_type = data.get('type')
        
        if message_type == 'acknowledge_order':
            order_id = data.get('order_id')
            chef_name = data.get('chef_name')
            await self.acknowledge_order(order_id, chef_name)
        
        elif message_type == 'update_status':
            order_id = data.get('order_id')
            new_status = data.get('status')
            await self.update_order_status(order_id, new_status)

    async def new_order(self, event):
        # Send new order notification to WebSocket
        await self.send(text_data=json.dumps({
            'type': 'new_order',
            'order': event['order'],
            'audio_alert': event.get('audio_alert', False)
        }))

    async def order_status_update(self, event):
        # Send order status update to WebSocket
        await self.send(text_data=json.dumps({
            'type': 'order_status_update',
            'order': event['order'],
            'status': event['new_status']
        }))

    @database_sync_to_async
    def acknowledge_order(self, order_id, chef_name):
        try:
            kitchen_display = KitchenDisplay.objects.get(order_id=order_id)
            kitchen_display.acknowledge_order(chef_name)
            return True
        except KitchenDisplay.DoesNotExist:
            return False

    @database_sync_to_async
    def update_order_status(self, order_id, new_status):
        try:
            kitchen_display = KitchenDisplay.objects.get(order_id=order_id)
            
            if new_status == 'preparing':
                kitchen_display.start_preparation()
            elif new_status == 'ready':
                kitchen_display.mark_ready()
            elif new_status == 'served':
                kitchen_display.mark_served()
            
            return True
        except KitchenDisplay.DoesNotExist:
            return False
```

### apps/kitchen/routing.py
```python
from django.urls import path
from . import consumers

websocket_urlpatterns = [
    path('ws/kitchen/', consumers.KitchenConsumer.as_asgi()),
]
```