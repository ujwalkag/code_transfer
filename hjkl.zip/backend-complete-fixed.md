# Hotel Management System - Complete Fixed Backend Code

## ERROR FIXED: StaffProfileViewSet Missing
**Problem**: `AttributeError: module 'apps.staff.views' has no attribute 'StaffProfileViewSet'`
**Solution**: Complete implementation of all missing ViewSets and proper Django structure

---

## COMPLETE BACKEND IMPLEMENTATION

### 1. PROJECT ROOT STRUCTURE
```
hotel-management-backend/
├── config/
│   ├── __init__.py
│   ├── settings.py
│   ├── urls.py
│   ├── wsgi.py
│   └── asgi.py
├── apps/
│   ├── __init__.py
│   ├── staff/
│   ├── tables/
│   ├── orders/
│   ├── billing/
│   ├── kitchen/
│   └── restaurant/  # Existing functionality
├── static/
├── media/
├── templates/
├── requirements.txt
└── manage.py
```

### 2. requirements.txt
```txt
Django==4.2.7
djangorestframework==3.14.0
django-cors-headers==4.3.1
Pillow==10.1.0
django-environ==0.11.2
psycopg2-binary==2.9.9
python-decouple==3.8
channels==4.0.0
channels-redis==4.1.0
celery==5.3.1
redis==4.6.0
```

### 3. config/settings.py (COMPLETE)
```python
import os
from pathlib import Path
from django.core.management.utils import get_random_secret_key

# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = os.environ.get('SECRET_KEY', get_random_secret_key())

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = os.environ.get('DEBUG', 'True').lower() == 'true'

ALLOWED_HOSTS = ['localhost', '127.0.0.1', '*']

# Application definition
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    
    # Third party apps
    'rest_framework',
    'corsheaders',
    'channels',
    
    # Local apps
    'apps.staff',
    'apps.tables', 
    'apps.orders',
    'apps.billing',
    'apps.kitchen',
    'apps.restaurant',  # Existing functionality - DO NOT BREAK
]

MIDDLEWARE = [
    'corsheaders.middleware.CorsMiddleware',
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'config.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates'],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'config.wsgi.application'
ASGI_APPLICATION = 'config.asgi.application'

# Database
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

# Password validation
AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

# Internationalization
LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'UTC'
USE_I18N = True
USE_TZ = True

# Static files (CSS, JavaScript, Images)
STATIC_URL = '/static/'
STATIC_ROOT = BASE_DIR / 'staticfiles'
STATICFILES_DIRS = [BASE_DIR / 'static']

MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# REST Framework configuration
REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': [
        'rest_framework.authentication.SessionAuthentication',
        'rest_framework.authentication.TokenAuthentication',
    ],
    'DEFAULT_PERMISSION_CLASSES': [
        'rest_framework.permissions.IsAuthenticated',
    ],
    'DEFAULT_PAGINATION_CLASS': 'rest_framework.pagination.PageNumberPagination',
    'PAGE_SIZE': 20,
    'DEFAULT_RENDERER_CLASSES': [
        'rest_framework.renderers.JSONRenderer',
        'rest_framework.renderers.BrowsableAPIRenderer',
    ]
}

# CORS settings
CORS_ALLOWED_ORIGINS = [
    "http://localhost:3000",
    "http://127.0.0.1:3000",
]

CORS_ALLOW_CREDENTIALS = True

# Channels configuration for WebSocket (Kitchen Audio)
CHANNEL_LAYERS = {
    'default': {
        'BACKEND': 'channels_redis.core.RedisChannelLayer',
        'CONFIG': {
            "hosts": [('127.0.0.1', 6379)],
        },
    },
}

# Celery Configuration (for background tasks)
CELERY_BROKER_URL = 'redis://localhost:6379'
CELERY_RESULT_BACKEND = 'redis://localhost:6379'
```

### 4. config/urls.py (COMPLETE)
```python
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    
    # API endpoints
    path('api/staff/', include('apps.staff.urls')),
    path('api/tables/', include('apps.tables.urls')),
    path('api/orders/', include('apps.orders.urls')),
    path('api/billing/', include('apps.billing.urls')),
    path('api/kitchen/', include('apps.kitchen.urls')),
    
    # Existing functionality - DO NOT BREAK
    path('api/restaurant/', include('apps.restaurant.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
```

### 5. apps/staff/models.py (COMPLETE - Two Separate Models)
```python
from django.db import models
from django.contrib.auth.models import User

class BaseStaff(models.Model):
    """Base staff model for authentication and access control ONLY"""
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='base_staff')
    staff_id = models.CharField(max_length=20, unique=True)
    department = models.CharField(max_length=50)
    position = models.CharField(max_length=50)
    phone = models.CharField(max_length=15)
    is_active = models.BooleanField(default=True)
    access_level = models.CharField(max_length=20, choices=[
        ('admin', 'Admin'),
        ('manager', 'Manager'),
        ('staff', 'Staff'),
        ('kitchen', 'Kitchen Staff'),
    ], default='staff')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'base_staff'
        verbose_name = 'Base Staff (Access Control)'
        verbose_name_plural = 'Base Staff (Access Control)'

    def __str__(self):
        return f"{self.user.get_full_name()} - {self.staff_id}"

class StaffProfile(models.Model):
    """Separate staff model for attendance and payroll - NOT linked to BaseStaff"""
    DEPARTMENT_CHOICES = [
        ('kitchen', 'Kitchen'),
        ('service', 'Service'), 
        ('management', 'Management'),
        ('housekeeping', 'Housekeeping'),
        ('reception', 'Reception'),
    ]
    
    EMPLOYMENT_TYPE_CHOICES = [
        ('full_time', 'Full Time'),
        ('part_time', 'Part Time'),
        ('contract', 'Contract'),
        ('casual', 'Casual'),
    ]

    name = models.CharField(max_length=100)
    employee_id = models.CharField(max_length=20, unique=True)
    department = models.CharField(max_length=20, choices=DEPARTMENT_CHOICES)
    position = models.CharField(max_length=50)
    employment_type = models.CharField(max_length=20, choices=EMPLOYMENT_TYPE_CHOICES)
    basic_salary = models.DecimalField(max_digits=10, decimal_places=2)
    hourly_rate = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    hire_date = models.DateField()
    phone = models.CharField(max_length=15)
    email = models.EmailField()
    address = models.TextField()
    emergency_contact = models.CharField(max_length=100, blank=True)
    emergency_phone = models.CharField(max_length=15, blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'staff_profiles'
        verbose_name = 'Staff Profile (HR Management)'
        verbose_name_plural = 'Staff Profiles (HR Management)'

    def __str__(self):
        return f"{self.name} - {self.employee_id}"

class Attendance(models.Model):
    STATUS_CHOICES = [
        ('present', 'Present'),
        ('absent', 'Absent'),
        ('half_day', 'Half Day'),
        ('late', 'Late'),
        ('holiday', 'Holiday'),
        ('sick_leave', 'Sick Leave'),
        ('vacation', 'Vacation'),
    ]

    staff = models.ForeignKey(StaffProfile, on_delete=models.CASCADE, related_name='attendances')
    date = models.DateField()
    check_in = models.TimeField(null=True, blank=True)
    check_out = models.TimeField(null=True, blank=True)
    break_hours = models.DecimalField(max_digits=4, decimal_places=2, default=0)
    total_hours = models.DecimalField(max_digits=4, decimal_places=2, default=0)
    overtime_hours = models.DecimalField(max_digits=4, decimal_places=2, default=0)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='present')
    notes = models.TextField(blank=True)
    approved_by = models.CharField(max_length=100, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'staff_attendance'
        unique_together = ['staff', 'date']
        verbose_name = 'Attendance Record'
        verbose_name_plural = 'Attendance Records'
        ordering = ['-date']

    def __str__(self):
        return f"{self.staff.name} - {self.date} - {self.status}"

    def calculate_hours(self):
        if self.check_in and self.check_out:
            from datetime import datetime, timedelta
            check_in_dt = datetime.combine(self.date, self.check_in)
            check_out_dt = datetime.combine(self.date, self.check_out)
            
            if check_out_dt < check_in_dt:
                check_out_dt += timedelta(days=1)
            
            total_time = check_out_dt - check_in_dt
            self.total_hours = max(0, (total_time.total_seconds() / 3600) - float(self.break_hours))
            
            # Calculate overtime (more than 8 hours)
            regular_hours = 8
            if self.total_hours > regular_hours:
                self.overtime_hours = self.total_hours - regular_hours
            else:
                self.overtime_hours = 0
                
            self.save()

class Payroll(models.Model):
    staff = models.ForeignKey(StaffProfile, on_delete=models.CASCADE, related_name='payrolls')
    month = models.IntegerField()
    year = models.IntegerField()
    days_worked = models.IntegerField(default=0)
    total_hours = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    overtime_hours = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    basic_amount = models.DecimalField(max_digits=10, decimal_places=2)
    overtime_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    bonus = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    allowances = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    deductions = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    tax_deducted = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    net_amount = models.DecimalField(max_digits=10, decimal_places=2)
    payment_date = models.DateField(null=True, blank=True)
    payment_method = models.CharField(max_length=20, choices=[
        ('bank_transfer', 'Bank Transfer'),
        ('cash', 'Cash'),
        ('check', 'Check'),
    ], default='bank_transfer')
    is_paid = models.BooleanField(default=False)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'staff_payroll'
        unique_together = ['staff', 'month', 'year']
        verbose_name = 'Payroll Record'
        verbose_name_plural = 'Payroll Records'
        ordering = ['-year', '-month']

    def __str__(self):
        return f"{self.staff.name} - {self.month}/{self.year} - ${self.net_amount}"

    def calculate_payroll(self):
        """Calculate payroll automatically based on attendance"""
        from django.db.models import Sum
        
        # Get attendance records for the month
        attendances = Attendance.objects.filter(
            staff=self.staff,
            date__month=self.month,
            date__year=self.year,
            status__in=['present', 'half_day', 'late']
        )
        
        self.days_worked = attendances.count()
        self.total_hours = attendances.aggregate(Sum('total_hours'))['total_hours__sum'] or 0
        self.overtime_hours = attendances.aggregate(Sum('overtime_hours'))['overtime_hours__sum'] or 0
        
        # Calculate amounts
        if self.staff.employment_type in ['full_time', 'part_time']:
            # Monthly salary
            self.basic_amount = self.staff.basic_salary
        else:
            # Hourly rate
            hourly_rate = self.staff.hourly_rate or 0
            self.basic_amount = float(self.total_hours) * float(hourly_rate)
        
        # Overtime calculation (1.5x rate)
        if self.overtime_hours > 0 and self.staff.hourly_rate:
            overtime_rate = float(self.staff.hourly_rate) * 1.5
            self.overtime_amount = float(self.overtime_hours) * overtime_rate
        
        # Calculate net amount
        gross_amount = self.basic_amount + self.overtime_amount + self.bonus + self.allowances
        self.net_amount = gross_amount - self.deductions - self.tax_deducted
        
        self.save()
```

### 6. apps/staff/serializers.py (COMPLETE)
```python
from rest_framework import serializers
from django.contrib.auth.models import User
from .models import BaseStaff, StaffProfile, Attendance, Payroll

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'first_name', 'last_name', 'email', 'is_active']
        read_only_fields = ['id']

class BaseStaffSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    user_id = serializers.IntegerField(write_only=True)
    full_name = serializers.CharField(source='user.get_full_name', read_only=True)
    
    class Meta:
        model = BaseStaff
        fields = '__all__'
        read_only_fields = ['created_at', 'updated_at']

class StaffProfileSerializer(serializers.ModelSerializer):
    department_display = serializers.CharField(source='get_department_display', read_only=True)
    employment_type_display = serializers.CharField(source='get_employment_type_display', read_only=True)
    
    class Meta:
        model = StaffProfile
        fields = '__all__'
        read_only_fields = ['created_at', 'updated_at']

    def validate_email(self, value):
        if StaffProfile.objects.filter(email=value).exists():
            if self.instance and self.instance.email != value:
                raise serializers.ValidationError("Email already exists.")
        return value

class AttendanceSerializer(serializers.ModelSerializer):
    staff_name = serializers.CharField(source='staff.name', read_only=True)
    staff_id = serializers.CharField(source='staff.employee_id', read_only=True)
    status_display = serializers.CharField(source='get_status_display', read_only=True)
    
    class Meta:
        model = Attendance
        fields = '__all__'
        read_only_fields = ['total_hours', 'overtime_hours', 'created_at', 'updated_at']

    def create(self, validated_data):
        attendance = super().create(validated_data)
        attendance.calculate_hours()
        return attendance

    def update(self, instance, validated_data):
        attendance = super().update(instance, validated_data)
        attendance.calculate_hours()
        return attendance

class PayrollSerializer(serializers.ModelSerializer):
    staff_name = serializers.CharField(source='staff.name', read_only=True)
    staff_id = serializers.CharField(source='staff.employee_id', read_only=True)
    payment_method_display = serializers.CharField(source='get_payment_method_display', read_only=True)
    gross_amount = serializers.SerializerMethodField()
    
    class Meta:
        model = Payroll
        fields = '__all__'
        read_only_fields = [
            'days_worked', 'total_hours', 'overtime_hours', 
            'basic_amount', 'overtime_amount', 'net_amount',
            'created_at', 'updated_at'
        ]

    def get_gross_amount(self, obj):
        return obj.basic_amount + obj.overtime_amount + obj.bonus + obj.allowances

    def create(self, validated_data):
        payroll = super().create(validated_data)
        payroll.calculate_payroll()
        return payroll
```

### 7. apps/staff/views.py (COMPLETE - FIXED THE MISSING VIEWSET)
```python
from rest_framework import viewsets, status, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.shortcuts import get_object_or_404
from django.db.models import Q
from django_filters.rest_framework import DjangoFilterBackend
from datetime import datetime, timedelta
from .models import BaseStaff, StaffProfile, Attendance, Payroll
from .serializers import (
    BaseStaffSerializer, StaffProfileSerializer,
    AttendanceSerializer, PayrollSerializer
)

class BaseStaffViewSet(viewsets.ModelViewSet):
    """ViewSet for Base Staff (Access Control Only)"""
    queryset = BaseStaff.objects.all()
    serializer_class = BaseStaffSerializer
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['department', 'position', 'access_level', 'is_active']
    search_fields = ['staff_id', 'user__first_name', 'user__last_name', 'user__email']
    ordering_fields = ['created_at', 'staff_id']
    ordering = ['-created_at']

class StaffProfileViewSet(viewsets.ModelViewSet):
    """FIXED: This ViewSet was missing and causing the error"""
    queryset = StaffProfile.objects.all()
    serializer_class = StaffProfileSerializer
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['department', 'employment_type', 'is_active']
    search_fields = ['name', 'employee_id', 'email', 'phone']
    ordering_fields = ['created_at', 'hire_date', 'name']
    ordering = ['name']

    @action(detail=True, methods=['get'])
    def attendance_summary(self, request, pk=None):
        """Get attendance summary for a staff member"""
        staff = self.get_object()
        month = request.query_params.get('month', datetime.now().month)
        year = request.query_params.get('year', datetime.now().year)
        
        attendances = Attendance.objects.filter(
            staff=staff,
            date__month=month,
            date__year=year
        )
        
        summary = {
            'total_days': attendances.count(),
            'present_days': attendances.filter(status='present').count(),
            'absent_days': attendances.filter(status='absent').count(),
            'late_days': attendances.filter(status='late').count(),
            'total_hours': sum([att.total_hours for att in attendances]),
            'overtime_hours': sum([att.overtime_hours for att in attendances]),
        }
        
        return Response(summary)

    @action(detail=True, methods=['get'])
    def payroll_history(self, request, pk=None):
        """Get payroll history for a staff member"""
        staff = self.get_object()
        payrolls = Payroll.objects.filter(staff=staff).order_by('-year', '-month')
        serializer = PayrollSerializer(payrolls, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def department_stats(self, request):
        """Get statistics by department"""
        from django.db.models import Count
        stats = StaffProfile.objects.values('department').annotate(
            total=Count('id'),
            active=Count('id', filter=Q(is_active=True))
        ).order_by('department')
        
        return Response(list(stats))

class AttendanceViewSet(viewsets.ModelViewSet):
    """ViewSet for Attendance Management"""
    queryset = Attendance.objects.all()
    serializer_class = AttendanceSerializer
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['staff', 'status', 'date']
    search_fields = ['staff__name', 'staff__employee_id']
    ordering_fields = ['date', 'check_in', 'check_out']
    ordering = ['-date']

    def get_queryset(self):
        queryset = Attendance.objects.all()
        
        # Filter by date range
        start_date = self.request.query_params.get('start_date')
        end_date = self.request.query_params.get('end_date')
        
        if start_date:
            queryset = queryset.filter(date__gte=start_date)
        if end_date:
            queryset = queryset.filter(date__lte=end_date)
            
        return queryset

    @action(detail=False, methods=['post'])
    def mark_attendance(self, request):
        """Quick attendance marking"""
        staff_id = request.data.get('staff_id')
        action_type = request.data.get('action')  # 'check_in' or 'check_out'
        
        if not staff_id or not action_type:
            return Response(
                {'error': 'staff_id and action are required'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            staff = StaffProfile.objects.get(employee_id=staff_id)
        except StaffProfile.DoesNotExist:
            return Response(
                {'error': 'Staff not found'}, 
                status=status.HTTP_404_NOT_FOUND
            )
        
        today = datetime.now().date()
        current_time = datetime.now().time()
        
        attendance, created = Attendance.objects.get_or_create(
            staff=staff,
            date=today,
            defaults={'status': 'present'}
        )
        
        if action_type == 'check_in':
            attendance.check_in = current_time
            attendance.status = 'present'
        elif action_type == 'check_out':
            attendance.check_out = current_time
        
        attendance.save()
        attendance.calculate_hours()
        
        serializer = AttendanceSerializer(attendance)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def daily_report(self, request):
        """Get daily attendance report"""
        date = request.query_params.get('date', datetime.now().date())
        attendances = Attendance.objects.filter(date=date)
        
        report = {
            'date': date,
            'total_staff': attendances.count(),
            'present': attendances.filter(status='present').count(),
            'absent': attendances.filter(status='absent').count(),
            'late': attendances.filter(status='late').count(),
            'on_leave': attendances.filter(status__in=['sick_leave', 'vacation']).count(),
        }
        
        return Response(report)

class PayrollViewSet(viewsets.ModelViewSet):
    """ViewSet for Payroll Management"""
    queryset = Payroll.objects.all()
    serializer_class = PayrollSerializer
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['staff', 'month', 'year', 'is_paid']
    search_fields = ['staff__name', 'staff__employee_id']
    ordering_fields = ['year', 'month', 'net_amount']
    ordering = ['-year', '-month']

    @action(detail=False, methods=['post'])
    def generate_payroll(self, request):
        """Generate payroll for all staff for a given month/year"""
        month = request.data.get('month', datetime.now().month)
        year = request.data.get('year', datetime.now().year)
        
        staff_profiles = StaffProfile.objects.filter(is_active=True)
        generated_payrolls = []
        
        for staff in staff_profiles:
            payroll, created = Payroll.objects.get_or_create(
                staff=staff,
                month=month,
                year=year,
                defaults={
                    'basic_amount': staff.basic_salary,
                    'net_amount': staff.basic_salary
                }
            )
            
            if created or not payroll.is_paid:
                payroll.calculate_payroll()
                generated_payrolls.append(payroll)
        
        serializer = PayrollSerializer(generated_payrolls, many=True)
        return Response({
            'message': f'Generated payroll for {len(generated_payrolls)} staff members',
            'payrolls': serializer.data
        })

    @action(detail=True, methods=['post'])
    def mark_paid(self, request, pk=None):
        """Mark a payroll as paid"""
        payroll = self.get_object()
        payroll.is_paid = True
        payroll.payment_date = datetime.now().date()
        payroll.save()
        
        serializer = PayrollSerializer(payroll)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def monthly_summary(self, request):
        """Get monthly payroll summary"""
        month = request.query_params.get('month', datetime.now().month)
        year = request.query_params.get('year', datetime.now().year)
        
        payrolls = Payroll.objects.filter(month=month, year=year)
        
        summary = {
            'month': month,
            'year': year,
            'total_staff': payrolls.count(),
            'total_amount': sum([p.net_amount for p in payrolls]),
            'paid_staff': payrolls.filter(is_paid=True).count(),
            'pending_staff': payrolls.filter(is_paid=False).count(),
            'paid_amount': sum([p.net_amount for p in payrolls.filter(is_paid=True)]),
            'pending_amount': sum([p.net_amount for p in payrolls.filter(is_paid=False)]),
        }
        
        return Response(summary)
```

### 8. apps/staff/urls.py (FIXED)
```python
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register(r'base-staff', views.BaseStaffViewSet, basename='base-staff')
router.register(r'profiles', views.StaffProfileViewSet, basename='staff-profile')  # FIXED - Now exists
router.register(r'attendance', views.AttendanceViewSet, basename='attendance')
router.register(r'payroll', views.PayrollViewSet, basename='payroll')

urlpatterns = [
    path('', include(router.urls)),
]
```

### 9. apps/staff/admin.py (COMPLETE)
```python
from django.contrib import admin
from .models import BaseStaff, StaffProfile, Attendance, Payroll

@admin.register(BaseStaff)
class BaseStaffAdmin(admin.ModelAdmin):
    list_display = ['staff_id', 'user', 'department', 'position', 'access_level', 'is_active']
    list_filter = ['department', 'position', 'access_level', 'is_active']
    search_fields = ['staff_id', 'user__first_name', 'user__last_name', 'user__email']
    readonly_fields = ['created_at', 'updated_at']

@admin.register(StaffProfile)
class StaffProfileAdmin(admin.ModelAdmin):
    list_display = ['employee_id', 'name', 'department', 'position', 'employment_type', 'is_active']
    list_filter = ['department', 'employment_type', 'is_active']
    search_fields = ['employee_id', 'name', 'email', 'phone']
    readonly_fields = ['created_at', 'updated_at']
    fieldsets = (
        ('Basic Information', {
            'fields': ('name', 'employee_id', 'department', 'position', 'employment_type')
        }),
        ('Contact Information', {
            'fields': ('email', 'phone', 'address', 'emergency_contact', 'emergency_phone')
        }),
        ('Employment Details', {
            'fields': ('basic_salary', 'hourly_rate', 'hire_date', 'is_active')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        })
    )

@admin.register(Attendance)
class AttendanceAdmin(admin.ModelAdmin):
    list_display = ['staff', 'date', 'check_in', 'check_out', 'status', 'total_hours', 'overtime_hours']
    list_filter = ['status', 'date', 'staff__department']
    search_fields = ['staff__name', 'staff__employee_id']
    date_hierarchy = 'date'
    readonly_fields = ['total_hours', 'overtime_hours', 'created_at', 'updated_at']
    actions = ['calculate_hours_for_selected']

    def calculate_hours_for_selected(self, request, queryset):
        for attendance in queryset:
            attendance.calculate_hours()
        self.message_user(request, f"Calculated hours for {queryset.count()} attendance records.")
    calculate_hours_for_selected.short_description = "Calculate hours for selected attendance"

@admin.register(Payroll)
class PayrollAdmin(admin.ModelAdmin):
    list_display = ['staff', 'month', 'year', 'net_amount', 'is_paid', 'payment_date']
    list_filter = ['month', 'year', 'is_paid', 'staff__department']
    search_fields = ['staff__name', 'staff__employee_id']
    readonly_fields = [
        'days_worked', 'total_hours', 'overtime_hours', 
        'basic_amount', 'overtime_amount', 'net_amount',
        'created_at', 'updated_at'
    ]
    actions = ['mark_as_paid', 'recalculate_payroll']

    def mark_as_paid(self, request, queryset):
        from datetime import datetime
        updated = queryset.update(is_paid=True, payment_date=datetime.now().date())
        self.message_user(request, f"Marked {updated} payroll records as paid.")
    mark_as_paid.short_description = "Mark selected payrolls as paid"

    def recalculate_payroll(self, request, queryset):
        for payroll in queryset:
            payroll.calculate_payroll()
        self.message_user(request, f"Recalculated {queryset.count()} payroll records.")
    recalculate_payroll.short_description = "Recalculate selected payrolls"

    fieldsets = (
        ('Basic Information', {
            'fields': ('staff', 'month', 'year')
        }),
        ('Attendance Summary', {
            'fields': ('days_worked', 'total_hours', 'overtime_hours'),
            'classes': ('collapse',)
        }),
        ('Payment Calculation', {
            'fields': ('basic_amount', 'overtime_amount', 'bonus', 'allowances', 'deductions', 'tax_deducted', 'net_amount')
        }),
        ('Payment Information', {
            'fields': ('payment_method', 'is_paid', 'payment_date', 'notes')
        }),
    )
```

### 10. apps/staff/apps.py (REQUIRED)
```python
from django.apps import AppConfig

class StaffConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.staff'
    verbose_name = 'Staff Management'
```

---

## MIGRATION COMMANDS (FIXED)
```bash
# Create all app directories first
mkdir -p apps/staff apps/tables apps/orders apps/billing apps/kitchen

# Create __init__.py files
touch apps/__init__.py
touch apps/staff/__init__.py
touch apps/tables/__init__.py
touch apps/orders/__init__.py
touch apps/billing/__init__.py
touch apps/kitchen/__init__.py

# Create migrations for each app
python manage.py makemigrations staff
python manage.py makemigrations tables
python manage.py makemigrations orders
python manage.py makemigrations billing
python manage.py makemigrations kitchen

# Apply migrations
python manage.py migrate

# Create superuser
python manage.py createsuperuser

# Test the system
python manage.py check

# Run the server
python manage.py runserver
```

## ERROR RESOLUTION SUMMARY
✅ **Fixed**: Missing `StaffProfileViewSet` in `apps.staff.views.py`  
✅ **Added**: Complete ViewSet with all CRUD operations  
✅ **Added**: Proper serializers with validation  
✅ **Added**: Admin interface with custom actions  
✅ **Added**: Comprehensive model relationships  
✅ **Added**: API endpoints for attendance and payroll  
✅ **Maintained**: Existing restaurant functionality  

The main error has been resolved by implementing the complete `StaffProfileViewSet` class that was referenced in the URLs but missing from the views file.