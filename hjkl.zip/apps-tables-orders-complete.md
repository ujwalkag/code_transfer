# Hotel Management System - Complete Implementation Part 2

## TABLES APP (Dynamic Table Management)

### apps/tables/models.py
```python
from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
import uuid

class Table(models.Model):
    STATUS_CHOICES = [
        ('available', 'Available'),
        ('occupied', 'Occupied'), 
        ('reserved', 'Reserved'),
        ('maintenance', 'Maintenance'),
        ('cleaning', 'Cleaning'),
    ]

    LOCATION_CHOICES = [
        ('indoor', 'Indoor'),
        ('outdoor', 'Outdoor'),
        ('private_room', 'Private Room'),
        ('bar_area', 'Bar Area'),
        ('terrace', 'Terrace'),
    ]

    table_number = models.CharField(max_length=10, unique=True)
    capacity = models.IntegerField(validators=[MinValueValidator(1), MaxValueValidator(20)])
    location = models.CharField(max_length=20, choices=LOCATION_CHOICES, default='indoor')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='available')
    qr_code = models.CharField(max_length=100, unique=True, null=True, blank=True)
    position_x = models.IntegerField(default=0)  # For floor plan positioning
    position_y = models.IntegerField(default=0)  # For floor plan positioning
    is_active = models.BooleanField(default=True)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'tables'
        verbose_name = 'Table'
        verbose_name_plural = 'Tables'
        ordering = ['table_number']

    def __str__(self):
        return f"Table {self.table_number} ({self.get_status_display()})"

    def save(self, *args, **kwargs):
        if not self.qr_code:
            self.qr_code = f"TBL_{self.table_number}_{uuid.uuid4().hex[:8]}"
        super().save(*args, **kwargs)

    def can_accommodate(self, party_size):
        """Check if table can accommodate the party size"""
        return self.capacity >= party_size and self.status == 'available'

    def mark_occupied(self):
        """Mark table as occupied"""
        self.status = 'occupied'
        self.save()

    def mark_available(self):
        """Mark table as available (after billing)"""
        self.status = 'available'
        self.save()

class TableReservation(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('confirmed', 'Confirmed'),
        ('seated', 'Seated'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled'),
        ('no_show', 'No Show'),
    ]

    table = models.ForeignKey(Table, on_delete=models.CASCADE, related_name='reservations')
    customer_name = models.CharField(max_length=100)
    customer_phone = models.CharField(max_length=15)
    customer_email = models.EmailField(blank=True)
    party_size = models.IntegerField(validators=[MinValueValidator(1)])
    reservation_date = models.DateField()
    reservation_time = models.TimeField()
    duration_hours = models.IntegerField(default=2, validators=[MinValueValidator(1), MaxValueValidator(8)])
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    special_requests = models.TextField(blank=True)
    deposit_amount = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    is_paid = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'table_reservations'
        verbose_name = 'Table Reservation'
        verbose_name_plural = 'Table Reservations'
        ordering = ['-reservation_date', '-reservation_time']

    def __str__(self):
        return f"Reservation {self.table.table_number} - {self.customer_name} ({self.reservation_date})"
```

### apps/tables/serializers.py
```python
from rest_framework import serializers
from .models import Table, TableReservation

class TableSerializer(serializers.ModelSerializer):
    status_display = serializers.CharField(source='get_status_display', read_only=True)
    location_display = serializers.CharField(source='get_location_display', read_only=True)
    current_orders_count = serializers.SerializerMethodField()
    
    class Meta:
        model = Table
        fields = '__all__'
        read_only_fields = ['qr_code', 'created_at', 'updated_at']

    def get_current_orders_count(self, obj):
        # Count active orders for this table
        return obj.orders.filter(status__in=['pending', 'confirmed', 'preparing', 'ready']).count()

class TableReservationSerializer(serializers.ModelSerializer):
    table_number = serializers.CharField(source='table.table_number', read_only=True)
    status_display = serializers.CharField(source='get_status_display', read_only=True)
    
    class Meta:
        model = TableReservation
        fields = '__all__'
        read_only_fields = ['created_at', 'updated_at']

    def validate(self, data):
        if data['party_size'] > data['table'].capacity:
            raise serializers.ValidationError("Party size exceeds table capacity.")
        return data
```

### apps/tables/views.py
```python
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from django.db.models import Q
from datetime import datetime, date
from .models import Table, TableReservation
from .serializers import TableSerializer, TableReservationSerializer

class TableViewSet(viewsets.ModelViewSet):
    queryset = Table.objects.all()
    serializer_class = TableSerializer

    @action(detail=False, methods=['get'])
    def available_tables(self, request):
        """Get all available tables"""
        party_size = request.query_params.get('party_size')
        location = request.query_params.get('location')
        
        tables = Table.objects.filter(status='available', is_active=True)
        
        if party_size:
            tables = tables.filter(capacity__gte=int(party_size))
        
        if location:
            tables = tables.filter(location=location)
            
        serializer = TableSerializer(tables, many=True)
        return Response(serializer.data)

    @action(detail=True, methods=['post'])
    def occupy_table(self, request, pk=None):
        """Mark table as occupied for mobile orders"""
        table = self.get_object()
        
        if table.status != 'available':
            return Response(
                {'error': 'Table is not available'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        table.mark_occupied()
        serializer = TableSerializer(table)
        return Response(serializer.data)

    @action(detail=True, methods=['post']) 
    def release_table(self, request, pk=None):
        """Mark table as available after billing"""
        table = self.get_object()
        table.mark_available()
        serializer = TableSerializer(table)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def floor_plan(self, request):
        """Get table positions for floor plan"""
        tables = Table.objects.filter(is_active=True)
        floor_plan = []
        
        for table in tables:
            floor_plan.append({
                'id': table.id,
                'table_number': table.table_number,
                'x': table.position_x,
                'y': table.position_y,
                'status': table.status,
                'capacity': table.capacity,
                'location': table.location
            })
            
        return Response(floor_plan)

class TableReservationViewSet(viewsets.ModelViewSet):
    queryset = TableReservation.objects.all()
    serializer_class = TableReservationSerializer

    @action(detail=False, methods=['get'])
    def today_reservations(self, request):
        """Get today's reservations"""
        today = date.today()
        reservations = TableReservation.objects.filter(
            reservation_date=today
        ).order_by('reservation_time')
        
        serializer = TableReservationSerializer(reservations, many=True)
        return Response(serializer.data)

    @action(detail=True, methods=['post'])
    def confirm_reservation(self, request, pk=None):
        """Confirm a reservation"""
        reservation = self.get_object()
        reservation.status = 'confirmed'
        reservation.save()
        
        serializer = TableReservationSerializer(reservation)
        return Response(serializer.data)

    @action(detail=True, methods=['post'])
    def seat_guests(self, request, pk=None):
        """Mark guests as seated"""
        reservation = self.get_object()
        reservation.status = 'seated'
        reservation.save()
        
        # Mark table as occupied
        reservation.table.mark_occupied()
        
        serializer = TableReservationSerializer(reservation)
        return Response(serializer.data)
```

### apps/tables/urls.py
```python
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register(r'tables', views.TableViewSet, basename='table')
router.register(r'reservations', views.TableReservationViewSet, basename='reservation')

urlpatterns = [
    path('', include(router.urls)),
]
```

---

## ORDERS APP (Mobile Orders with Dynamic Updates)

### apps/orders/models.py
```python
from django.db import models
from django.core.validators import MinValueValidator
from apps.tables.models import Table
import uuid

class MenuCategory(models.Model):
    name = models.CharField(max_length=50)
    description = models.TextField(blank=True)
    display_order = models.IntegerField(default=0)
    is_active = models.BooleanField(default=True)
    image = models.ImageField(upload_to='categories/', null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'menu_categories'
        verbose_name = 'Menu Category'
        verbose_name_plural = 'Menu Categories'
        ordering = ['display_order', 'name']

    def __str__(self):
        return self.name

class MenuItem(models.Model):
    category = models.ForeignKey(MenuCategory, on_delete=models.CASCADE, related_name='items')
    name = models.CharField(max_length=100)
    description = models.TextField()
    price = models.DecimalField(max_digits=8, decimal_places=2, validators=[MinValueValidator(0)])
    cost_price = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    image = models.ImageField(upload_to='menu_items/', null=True, blank=True)
    is_available = models.BooleanField(default=True)
    is_featured = models.BooleanField(default=False)
    preparation_time = models.IntegerField(help_text="Time in minutes", default=15)
    ingredients = models.TextField(blank=True)
    allergens = models.CharField(max_length=200, blank=True)
    calories = models.IntegerField(null=True, blank=True)
    is_vegetarian = models.BooleanField(default=False)
    is_vegan = models.BooleanField(default=False)
    is_spicy = models.BooleanField(default=False)
    spice_level = models.IntegerField(choices=[(1,'Mild'),(2,'Medium'),(3,'Hot'),(4,'Very Hot')], null=True, blank=True)
    display_order = models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'menu_items'
        verbose_name = 'Menu Item'
        verbose_name_plural = 'Menu Items'
        ordering = ['category__display_order', 'display_order', 'name']

    def __str__(self):
        return f"{self.name} - ${self.price}"

    @property
    def profit_margin(self):
        if self.cost_price:
            return ((self.price - self.cost_price) / self.price) * 100
        return 0

class Order(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('confirmed', 'Confirmed'),
        ('preparing', 'Preparing'),
        ('ready', 'Ready'),
        ('served', 'Served'),
        ('billed', 'Billed'),
        ('cancelled', 'Cancelled'),
    ]

    ORDER_TYPE_CHOICES = [
        ('dine_in', 'Dine In'),
        ('takeaway', 'Takeaway'),
        ('delivery', 'Delivery'),
    ]

    order_number = models.CharField(max_length=20, unique=True)
    table = models.ForeignKey(Table, on_delete=models.CASCADE, related_name='orders')
    order_type = models.CharField(max_length=20, choices=ORDER_TYPE_CHOICES, default='dine_in')
    customer_name = models.CharField(max_length=100, blank=True)
    customer_phone = models.CharField(max_length=15, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    priority = models.IntegerField(default=1, validators=[MinValueValidator(1), models.validators.MaxValueValidator(5)])
    subtotal = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    tax_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    discount_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    special_instructions = models.TextField(blank=True)
    estimated_time = models.IntegerField(default=30, help_text="Estimated preparation time in minutes")
    ordered_at = models.DateTimeField(auto_now_add=True)
    confirmed_at = models.DateTimeField(null=True, blank=True)
    served_at = models.DateTimeField(null=True, blank=True)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'orders'
        verbose_name = 'Order'
        verbose_name_plural = 'Orders'
        ordering = ['-created_at']

    def __str__(self):
        return f"Order {self.order_number} - Table {self.table.table_number}"

    def save(self, *args, **kwargs):
        if not self.order_number:
            import datetime
            date_str = datetime.datetime.now().strftime('%Y%m%d')
            order_count = Order.objects.filter(created_at__date=datetime.date.today()).count() + 1
            self.order_number = f"ORD{date_str}{order_count:04d}"
        super().save(*args, **kwargs)

    def calculate_total(self):
        """Calculate order total from items"""
        items_total = sum(item.subtotal for item in self.items.all())
        self.subtotal = items_total
        self.total_amount = self.subtotal + self.tax_amount - self.discount_amount
        self.save()
        return self.total_amount

    def update_status(self, new_status):
        """Update order status with timestamp"""
        self.status = new_status
        if new_status == 'confirmed':
            from django.utils import timezone
            self.confirmed_at = timezone.now()
        elif new_status == 'served':
            from django.utils import timezone
            self.served_at = timezone.now()
        self.save()

class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='items')
    menu_item = models.ForeignKey(MenuItem, on_delete=models.CASCADE)
    quantity = models.IntegerField(default=1, validators=[MinValueValidator(1)])
    unit_price = models.DecimalField(max_digits=8, decimal_places=2)
    subtotal = models.DecimalField(max_digits=10, decimal_places=2)
    special_instructions = models.TextField(blank=True)
    customizations = models.JSONField(default=dict, blank=True)  # Store customizations as JSON
    is_complimentary = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'order_items'
        verbose_name = 'Order Item'
        verbose_name_plural = 'Order Items'

    def save(self, *args, **kwargs):
        if not self.is_complimentary:
            self.subtotal = self.quantity * self.unit_price
        else:
            self.subtotal = 0
        super().save(*args, **kwargs)
        # Update order total
        self.order.calculate_total()

    def __str__(self):
        return f"{self.menu_item.name} x {self.quantity} (Order: {self.order.order_number})"

class OrderModification(models.Model):
    """Track order modifications for audit trail"""
    ACTION_CHOICES = [
        ('item_added', 'Item Added'),
        ('item_removed', 'Item Removed'),
        ('quantity_changed', 'Quantity Changed'),
        ('item_customized', 'Item Customized'),
        ('order_cancelled', 'Order Cancelled'),
    ]

    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name='modifications')
    action = models.CharField(max_length=20, choices=ACTION_CHOICES)
    description = models.TextField()
    modified_by = models.CharField(max_length=100, default='System')
    previous_value = models.TextField(blank=True)
    new_value = models.TextField(blank=True)
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'order_modifications'
        verbose_name = 'Order Modification'
        verbose_name_plural = 'Order Modifications'
        ordering = ['-timestamp']

    def __str__(self):
        return f"{self.order.order_number} - {self.action}"
```

### apps/orders/serializers.py
```python
from rest_framework import serializers
from .models import MenuCategory, MenuItem, Order, OrderItem, OrderModification

class MenuCategorySerializer(serializers.ModelSerializer):
    items_count = serializers.SerializerMethodField()
    
    class Meta:
        model = MenuCategory
        fields = '__all__'

    def get_items_count(self, obj):
        return obj.items.filter(is_available=True).count()

class MenuItemSerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(source='category.name', read_only=True)
    profit_margin = serializers.ReadOnlyField()
    
    class Meta:
        model = MenuItem
        fields = '__all__'

class OrderItemSerializer(serializers.ModelSerializer):
    menu_item_name = serializers.CharField(source='menu_item.name', read_only=True)
    menu_item_image = serializers.ImageField(source='menu_item.image', read_only=True)
    
    class Meta:
        model = OrderItem
        fields = '__all__'
        read_only_fields = ['subtotal', 'created_at', 'updated_at']

class OrderSerializer(serializers.ModelSerializer):
    items = OrderItemSerializer(many=True, read_only=True)
    table_number = serializers.CharField(source='table.table_number', read_only=True)
    status_display = serializers.CharField(source='get_status_display', read_only=True)
    order_type_display = serializers.CharField(source='get_order_type_display', read_only=True)
    items_count = serializers.SerializerMethodField()
    
    class Meta:
        model = Order
        fields = '__all__'
        read_only_fields = ['order_number', 'subtotal', 'total_amount', 'created_at', 'updated_at']

    def get_items_count(self, obj):
        return obj.items.count()

class OrderModificationSerializer(serializers.ModelSerializer):
    class Meta:
        model = OrderModification
        fields = '__all__'
        read_only_fields = ['timestamp']
```

### apps/orders/views.py
```python
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from django.db.models import Q
from datetime import datetime, date
from .models import MenuCategory, MenuItem, Order, OrderItem, OrderModification
from .serializers import (
    MenuCategorySerializer, MenuItemSerializer, 
    OrderSerializer, OrderItemSerializer, OrderModificationSerializer
)

class MenuCategoryViewSet(viewsets.ModelViewSet):
    queryset = MenuCategory.objects.filter(is_active=True)
    serializer_class = MenuCategorySerializer

class MenuItemViewSet(viewsets.ModelViewSet):
    queryset = MenuItem.objects.filter(is_available=True)
    serializer_class = MenuItemSerializer

    def get_queryset(self):
        queryset = MenuItem.objects.filter(is_available=True)
        category = self.request.query_params.get('category')
        is_featured = self.request.query_params.get('featured')
        
        if category:
            queryset = queryset.filter(category_id=category)
        if is_featured:
            queryset = queryset.filter(is_featured=True)
            
        return queryset

    @action(detail=False, methods=['get'])
    def featured_items(self, request):
        """Get featured menu items"""
        items = MenuItem.objects.filter(is_featured=True, is_available=True)
        serializer = MenuItemSerializer(items, many=True)
        return Response(serializer.data)

class OrderViewSet(viewsets.ModelViewSet):
    queryset = Order.objects.all()
    serializer_class = OrderSerializer

    def get_queryset(self):
        queryset = Order.objects.all()
        table_id = self.request.query_params.get('table_id')
        status_filter = self.request.query_params.get('status')
        date_filter = self.request.query_params.get('date')
        
        if table_id:
            queryset = queryset.filter(table_id=table_id)
        if status_filter:
            queryset = queryset.filter(status=status_filter)
        if date_filter:
            queryset = queryset.filter(created_at__date=date_filter)
            
        return queryset.order_by('-created_at')

    @action(detail=False, methods=['post'])
    def create_mobile_order(self, request):
        """Create order from mobile interface"""
        table_id = request.data.get('table_id')
        items_data = request.data.get('items', [])
        
        if not table_id or not items_data:
            return Response(
                {'error': 'table_id and items are required'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Create order
        order_data = {
            'table': table_id,
            'customer_name': request.data.get('customer_name', ''),
            'special_instructions': request.data.get('special_instructions', ''),
            'order_type': request.data.get('order_type', 'dine_in')
        }
        
        order_serializer = OrderSerializer(data=order_data)
        if order_serializer.is_valid():
            order = order_serializer.save()
            
            # Create order items
            for item_data in items_data:
                menu_item = get_object_or_404(MenuItem, id=item_data['menu_item_id'])
                OrderItem.objects.create(
                    order=order,
                    menu_item=menu_item,
                    quantity=item_data['quantity'],
                    unit_price=menu_item.price,
                    special_instructions=item_data.get('special_instructions', ''),
                    customizations=item_data.get('customizations', {})
                )
            
            # Mark table as occupied
            order.table.mark_occupied()
            
            # Send to kitchen (trigger WebSocket notification)
            from .tasks import notify_kitchen_new_order
            notify_kitchen_new_order.delay(order.id)
            
            return Response(OrderSerializer(order).data, status=status.HTTP_201_CREATED)
        
        return Response(order_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=['post'])
    def add_item(self, request, pk=None):
        """Add item to existing order"""
        order = self.get_object()
        
        if order.status in ['served', 'billed', 'cancelled']:
            return Response(
                {'error': 'Cannot modify this order'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        menu_item_id = request.data.get('menu_item_id')
        quantity = request.data.get('quantity', 1)
        
        if not menu_item_id:
            return Response(
                {'error': 'menu_item_id is required'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        menu_item = get_object_or_404(MenuItem, id=menu_item_id)
        
        # Check if item already exists in order
        existing_item = order.items.filter(menu_item=menu_item).first()
        
        if existing_item:
            existing_item.quantity += quantity
            existing_item.save()
            action_description = f"Increased quantity of {menu_item.name} to {existing_item.quantity}"
        else:
            OrderItem.objects.create(
                order=order,
                menu_item=menu_item,
                quantity=quantity,
                unit_price=menu_item.price,
                special_instructions=request.data.get('special_instructions', ''),
                customizations=request.data.get('customizations', {})
            )
            action_description = f"Added {quantity}x {menu_item.name}"
        
        # Log modification
        OrderModification.objects.create(
            order=order,
            action='item_added',
            description=action_description,
            modified_by=request.user.username if request.user.is_authenticated else 'Mobile'
        )
        
        return Response(OrderSerializer(order).data)

    @action(detail=True, methods=['post'])
    def update_status(self, request, pk=None):
        """Update order status"""
        order = self.get_object()
        new_status = request.data.get('status')
        
        if new_status not in dict(Order.STATUS_CHOICES):
            return Response(
                {'error': 'Invalid status'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        old_status = order.status
        order.update_status(new_status)
        
        # Log modification
        OrderModification.objects.create(
            order=order,
            action='order_status_changed',
            description=f"Status changed from {old_status} to {new_status}",
            modified_by=request.user.username if request.user.is_authenticated else 'System',
            previous_value=old_status,
            new_value=new_status
        )
        
        return Response(OrderSerializer(order).data)

    @action(detail=False, methods=['get'])
    def active_orders(self, request):
        """Get all active orders for kitchen display"""
        orders = Order.objects.filter(
            status__in=['confirmed', 'preparing', 'ready']
        ).order_by('priority', 'created_at')
        
        serializer = OrderSerializer(orders, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def table_orders(self, request):
        """Get active orders by table for enhanced billing"""
        table_id = request.query_params.get('table_id')
        
        if not table_id:
            # Return all tables with active orders
            from apps.tables.models import Table
            tables_with_orders = Table.objects.filter(
                orders__status__in=['confirmed', 'preparing', 'ready', 'served']
            ).distinct()
            
            result = []
            for table in tables_with_orders:
                active_orders = table.orders.filter(
                    status__in=['confirmed', 'preparing', 'ready', 'served']
                )
                result.append({
                    'table_id': table.id,
                    'table_number': table.table_number,
                    'orders': OrderSerializer(active_orders, many=True).data
                })
            
            return Response(result)
        
        else:
            # Return orders for specific table
            orders = Order.objects.filter(
                table_id=table_id,
                status__in=['confirmed', 'preparing', 'ready', 'served']
            )
            serializer = OrderSerializer(orders, many=True)
            return Response(serializer.data)

class OrderItemViewSet(viewsets.ModelViewSet):
    queryset = OrderItem.objects.all()
    serializer_class = OrderItemSerializer

    @action(detail=True, methods=['patch'])
    def update_quantity(self, request, pk=None):
        """Update item quantity"""
        item = self.get_object()
        new_quantity = request.data.get('quantity')
        
        if not new_quantity or new_quantity < 1:
            return Response(
                {'error': 'Valid quantity is required'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        old_quantity = item.quantity
        item.quantity = new_quantity
        item.save()
        
        # Log modification
        OrderModification.objects.create(
            order=item.order,
            action='quantity_changed',
            description=f"Changed quantity of {item.menu_item.name} from {old_quantity} to {new_quantity}",
            modified_by=request.user.username if request.user.is_authenticated else 'Mobile',
            previous_value=str(old_quantity),
            new_value=str(new_quantity)
        )
        
        return Response(OrderItemSerializer(item).data)

    @action(detail=True, methods=['delete'])
    def remove_item(self, request, pk=None):
        """Remove item from order"""
        item = self.get_object()
        
        # Log modification before deletion
        OrderModification.objects.create(
            order=item.order,
            action='item_removed',
            description=f"Removed {item.quantity}x {item.menu_item.name}",
            modified_by=request.user.username if request.user.is_authenticated else 'Mobile'
        )
        
        item.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
```

### apps/orders/urls.py
```python
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register(r'categories', views.MenuCategoryViewSet, basename='category')
router.register(r'menu-items', views.MenuItemViewSet, basename='menuitem')
router.register(r'orders', views.OrderViewSet, basename='order')
router.register(r'order-items', views.OrderItemViewSet, basename='orderitem')

urlpatterns = [
    path('', include(router.urls)),
]
```

### apps/orders/tasks.py (Celery tasks for background processing)
```python
from celery import shared_task
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync

@shared_task
def notify_kitchen_new_order(order_id):
    """Send WebSocket notification to kitchen for new order"""
    from .models import Order
    from .serializers import OrderSerializer
    
    try:
        order = Order.objects.get(id=order_id)
        channel_layer = get_channel_layer()
        
        # Send to kitchen group
        async_to_sync(channel_layer.group_send)(
            'kitchen_orders',
            {
                'type': 'new_order',
                'order': OrderSerializer(order).data,
                'audio_alert': True
            }
        )
    except Order.DoesNotExist:
        pass

@shared_task 
def update_order_status_notification(order_id, status):
    """Send WebSocket notification for order status updates"""
    from .models import Order
    from .serializers import OrderSerializer
    
    try:
        order = Order.objects.get(id=order_id)
        channel_layer = get_channel_layer()
        
        # Send to general restaurant group
        async_to_sync(channel_layer.group_send)(
            'restaurant_updates',
            {
                'type': 'order_status_update',
                'order': OrderSerializer(order).data,
                'new_status': status
            }
        )
    except Order.DoesNotExist:
        pass
```