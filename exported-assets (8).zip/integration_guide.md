# Hotel Management System - Integration Guide

## Backend Setup


# BACKEND INTEGRATION STEPS

## 1. Install Additional Dependencies
Add to requirements.txt:
```
qrcode[pil]==7.4.2
python-barcode==0.14.0
reportlab==4.0.7
weasyprint==65.0
```

## 2. Database Migrations
Run these commands:
```bash
python manage.py makemigrations staff
python manage.py makemigrations tables
python manage.py makemigrations bills
python manage.py migrate
```

## 3. Update URL Patterns
Add to config/urls.py:
```python
path('api/staff/', include('apps.staff.urls')),
path('api/tables/mobile/', include('apps.tables.mobile_urls')),
```

## 4. Create New URL Files
Create apps/staff/urls.py:
```python
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import StaffProfileViewSet, AttendanceViewSet, PayrollViewSet

router = DefaultRouter()
router.register(r'profiles', StaffProfileViewSet)
router.register(r'attendance', AttendanceViewSet)
router.register(r'payroll', PayrollViewSet)

urlpatterns = [
    path('', include(router.urls)),
]
```

Create apps/tables/mobile_urls.py:
```python
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .mobile_views import MobileWaiterViewSet

router = DefaultRouter()
router.register(r'', MobileWaiterViewSet, basename='mobile-waiter')

urlpatterns = [
    path('', include(router.urls)),
]
```

## 5. Settings Updates
Add to INSTALLED_APPS in settings.py:
```python
INSTALLED_APPS = [
    # ... existing apps
    'apps.staff',
    # ... rest of apps
]
```


================================================================================

## Frontend Setup


# FRONTEND INTEGRATION STEPS

## 1. Install Additional Dependencies
Add to package.json:
```json
{
  "dependencies": {
    "react-qr-scanner": "^1.0.0-alpha.11",
    "html5-qrcode": "^2.3.8",
    "jspdf": "^2.5.1",
    "html2canvas": "^1.4.1"
  }
}
```

## 2. Create New Route Pages
Create pages/waiter/mobile-orders.js:
```javascript
import WaiterOrderTaking from '@/components/mobile/WaiterOrderTaking';
import withRoleGuard from '@/hoc/withRoleGuard';

export default withRoleGuard(WaiterOrderTaking, ['waiter', 'admin']);
```

Create pages/admin/enhanced-billing.js:
```javascript
import OneClickBilling from '@/components/billing/OneClickBilling';
import withRoleGuard from '@/hoc/withRoleGuard';

export default withRoleGuard(OneClickBilling, ['admin', 'biller']);
```

Create pages/admin/staff-management.js:
```javascript
import StaffManagement from '@/components/staff/StaffManagement';
import withRoleGuard from '@/hoc/withRoleGuard';

export default withRoleGuard(StaffManagement, ['admin']);
```

## 3. Update Navigation
Add to components/Sidebar.js or navigation component:
```javascript
const navigationItems = [
  // ... existing items
  {
    name: 'Mobile Orders',
    href: '/waiter/mobile-orders',
    icon: '📱',
    roles: ['waiter', 'admin']
  },
  {
    name: 'Enhanced Billing',
    href: '/admin/enhanced-billing',
    icon: '💳',
    roles: ['admin', 'biller']
  },
  {
    name: 'Staff Management',
    href: '/admin/staff-management',
    icon: '👥',
    roles: ['admin']
  }
];
```

## 4. Update User Model Context
Enhance AuthContext.js to handle new user permissions:
```javascript
const login = ({ token, role, email, permissions }) => {
  localStorage.setItem("token", token);
  localStorage.setItem("role", role);
  localStorage.setItem("email", email);
  localStorage.setItem("permissions", JSON.stringify(permissions));
  setAuth({ token, role, email, permissions });
};
```


================================================================================

## Testing Checklist


# TESTING CHECKLIST

## Backend API Testing
□ Test staff profile creation and management
□ Test attendance marking and retrieval
□ Test payroll generation and calculations
□ Test mobile waiter order creation
□ Test one-click bill generation with GST
□ Test bill splitting functionality
□ Verify JWT authentication on all endpoints
□ Test error handling and validation

## Frontend Component Testing
□ Test mobile waiter interface on phone/tablet
□ Test table selection and order placement
□ Test menu browsing and cart functionality
□ Test bill generation with GST breakdown
□ Test receipt printing functionality
□ Test staff attendance marking
□ Test payroll calculations display
□ Test responsive design on different screen sizes

## Integration Testing
□ Test real-time updates from waiter to kitchen
□ Test order status changes across all interfaces
□ Test table occupancy updates
□ Test user role-based access control
□ Test data synchronization between components

## Performance Testing
□ Test with multiple concurrent users
□ Test database query performance
□ Test real-time updates latency
□ Test mobile app performance on slower devices


================================================================================

