
# DEPLOYMENT GUIDE

## Production Deployment Steps

### 1. Backend Deployment
```bash
# 1. Pull latest code
git pull origin main

# 2. Install dependencies
pip install -r requirements.txt

# 3. Run migrations
python manage.py migrate

# 4. Collect static files
python manage.py collectstatic --noinput

# 5. Create superuser (if needed)
python manage.py createsuperuser

# 6. Restart services
sudo systemctl restart hotel-backend
sudo systemctl restart nginx
```

### 2. Frontend Deployment
```bash
# 1. Pull latest code
git pull origin main

# 2. Install dependencies
npm install

# 3. Build for production
npm run build

# 4. Deploy to server
npm run start
# or
pm2 restart hotel-frontend
```

### 3. Environment Variables
Ensure these are set in production:
```
DJANGO_DEBUG=False
DJANGO_SECRET_KEY=your-secure-secret-key
POSTGRES_DB=hotel_db
POSTGRES_USER=hotel_admin
POSTGRES_PASSWORD=your-secure-password
POSTGRES_HOST=localhost
POSTGRES_PORT=5432
```

### 4. SSL Certificate
```bash
# Install SSL certificate
sudo certbot --nginx -d yourdomain.com
```

### 5. Monitoring Setup
```bash
# Install monitoring tools
pip install sentry-sdk
npm install @sentry/nextjs
```
