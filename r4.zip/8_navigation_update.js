
# pages/admin/dashboard.js - ADD THESE NAVIGATION LINKS IN THE MAIN CARDS SECTION

// Replace the existing LinkCard section with this:
<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
  <LinkCard href="/admin/manage-menu" label="🍽️ Menu Management / मेन्यू प्रबंधन" />
  <LinkCard href="/admin/manage-rooms" label="🏨 Room Management / कमरा प्रबंधन" />
  <LinkCard href="/admin/manage-staff" label="👥 Basic Staff / बेसिक स्टाफ" />
  <LinkCard href="/admin/staff-management" label="👥 Staff Management / कर्मचारी प्रबंधन" />
  <LinkCard href="/admin/enhanced-billing" label="💳 Enhanced Billing / एक-क्लिक बिलिंग" />
  <LinkCard href="/waiter/mobile-orders" label="📱 Mobile Orders / मोबाइल ऑर्डर" />
  <LinkCard href="/admin/billing" label="💰 Standard Billing / मानक बिलिंग" />
  <LinkCard href="/admin/bill-history" label="📊 Bill History / बिल इतिहास" />
  <LinkCard href="/admin/inventory" label="📦 Inventory / इन्वेंटरी" />
  <LinkCard href="/kitchen" label="🍳 Kitchen Display / किचन डिस्प्ले" />
</div>
