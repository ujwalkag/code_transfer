
# apps/tables/serializers.py - ADD THESE SERIALIZERS TO THE END OF YOUR EXISTING FILE

class MobileTableSerializer(serializers.ModelSerializer):
    active_orders_count = serializers.ReadOnlyField()
    current_order = serializers.SerializerMethodField()

    class Meta:
        model = RestaurantTable
        fields = ['id', 'table_number', 'capacity', 'location', 'is_active', 
                 'is_occupied', 'active_orders_count', 'current_order']

    def get_current_order(self, obj):
        current = obj.current_order
        if current:
            return {
                'id': current.id,
                'order_number': current.order_number,
                'status': current.status,
                'customer_name': current.customer_name,
                'total_amount': str(current.total_amount)
            }
        return None

class MobileOrderSerializer(serializers.ModelSerializer):
    items = OrderItemSerializer(many=True, read_only=True)
    table_number = serializers.CharField(source='table.table_number', read_only=True)

    class Meta:
        model = TableOrder
        fields = ['id', 'order_number', 'table_number', 'customer_name', 
                 'customer_phone', 'customer_count', 'status', 'total_amount', 
                 'items', 'created_at']
