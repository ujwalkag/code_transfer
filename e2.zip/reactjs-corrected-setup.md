# REACT.JS FRONTEND - CORRECTED SETUP

## 🎯 YOUR TECHNOLOGY STACK

**Backend**: Django (Python) - REST API  
**Frontend**: React.js (JavaScript library)  
**Development**: Node.js (npm, build tools)  
**Architecture**: React SPA ↔ Django API

---

## 📱 REACT.JS PROJECT STRUCTURE

### package.json (Updated for React.js)

```json
{
  "name": "hotel-management-frontend",
  "version": "1.0.0",
  "private": true,
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-router-dom": "^6.8.0",
    "react-scripts": "5.0.1",
    "axios": "^1.3.0",
    "react-query": "^3.39.0",
    "@heroicons/react": "^2.0.16",
    "tailwindcss": "^3.2.0",
    "@headlessui/react": "^1.7.0"
  },
  "scripts": {
    "start": "react-scripts start",
    "build": "react-scripts build",
    "test": "react-scripts test",
    "eject": "react-scripts eject"
  },
  "eslintConfig": {
    "extends": [
      "react-app",
      "react-app/jest"
    ]
  },
  "browserslist": {
    "production": [
      ">0.2%",
      "not dead",
      "not op_mini all"
    ],
    "development": [
      "last 1 chrome version",
      "last 1 firefox version",
      "last 1 safari version"
    ]
  },
  "proxy": "http://localhost:8000"
}
```

### src/App.js (React.js Main Component)

```javascript
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from 'react-query';

// Import React components
import Navbar from './components/Layout/Navbar';
import Sidebar from './components/Layout/Sidebar';
import Dashboard from './pages/Dashboard';
import EnhancedBilling from './pages/Billing/EnhancedBilling';
import MobileOrdering from './pages/Mobile/MobileOrdering';
import KitchenDisplay from './pages/Kitchen/KitchenDisplay';
import StaffManagement from './pages/Staff/StaffManagement';

// Tailwind CSS imports
import './index.css';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: 1,
    },
  },
});

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <div className="min-h-screen bg-gray-50">
          <Routes>
            {/* Public Routes */}
            <Route path="/mobile/*" element={<MobileOrdering />} />
            <Route path="/kitchen" element={<KitchenDisplay />} />
            
            {/* Admin Routes */}
            <Route path="/admin/*" element={
              <div className="flex">
                <Sidebar />
                <div className="flex-1 flex flex-col">
                  <Navbar />
                  <main className="flex-1 p-6">
                    <Routes>
                      <Route index element={<Dashboard />} />
                      <Route path="billing" element={<EnhancedBilling />} />
                      <Route path="staff" element={<StaffManagement />} />
                    </Routes>
                  </main>
                </div>
              </div>
            } />
            
            {/* Default Redirect */}
            <Route path="/" element={<Navigate to="/admin" replace />} />
          </Routes>
        </div>
      </Router>
    </QueryClientProvider>
  );
}

export default App;
```

### src/index.js (React.js Entry Point)

```javascript
import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
```

### src/index.css (Tailwind CSS)

```css
@tailwind base;
@tailwind components;
@tailwind utilities;

body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

code {
  font-family: source-code-pro, Menlo, Monaco, Consolas, 'Courier New',
    monospace;
}

/* Kitchen Display Dark Theme */
.kitchen-dark {
  background-color: #1a1a1a;
  color: white;
}

/* Mobile Ordering Theme */
.mobile-interface {
  font-size: 16px;
  line-height: 1.6;
}

/* Enhanced Billing Theme */
.billing-interface {
  background: #f8fafc;
}
```

---

## 🛠️ ENHANCED BILLING COMPONENT (CORRECTED JSX)

### src/pages/Billing/EnhancedBilling.js

```javascript
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { PlusIcon, TrashIcon, PrinterIcon } from '@heroicons/react/24/outline';

const EnhancedBilling = () => {
  const [activeTables, setActiveTables] = useState([]);
  const [selectedTable, setSelectedTable] = useState(null);
  const [currentBill, setCurrentBill] = useState(null);
  const [customItem, setCustomItem] = useState({
    item_name: '',
    quantity: 1,
    price: ''
  });
  const [gstSettings, setGstSettings] = useState({
    apply_gst: true,
    interstate: false
  });
  const [loading, setLoading] = useState(false);

  // Fetch active tables with orders
  useEffect(() => {
    fetchActiveTables();
    const interval = setInterval(fetchActiveTables, 10000);
    return () => clearInterval(interval);
  }, []);

  const fetchActiveTables = async () => {
    try {
      const response = await axios.get('/api/tables/mobile/active-orders/');
      setActiveTables(response.data.active_tables || []);
    } catch (error) {
      console.error('Error fetching active tables:', error);
    }
  };

  const createBillForTable = async (tableId) => {
    setLoading(true);
    try {
      const response = await axios.post('/api/bills/enhanced/create-table-bill/', {
        table_id: tableId,
        customer_name: 'Enhanced Billing Customer'
      });
      
      setCurrentBill(response.data.bill);
      setSelectedTable(tableId);
      alert('Bill created successfully!');
    } catch (error) {
      console.error('Error creating bill:', error);
      alert('Error creating bill: ' + (error.response?.data?.error || 'Unknown error'));
    } finally {
      setLoading(false);
    }
  };

  const addCustomItem = async () => {
    if (!currentBill || !customItem.item_name || !customItem.price) {
      alert('Please fill all required fields');
      return;
    }

    setLoading(true);
    try {
      await axios.post('/api/bills/enhanced/add-item/', {
        bill_id: currentBill.id,
        item_name: customItem.item_name,
        quantity: parseInt(customItem.quantity),
        price: parseFloat(customItem.price)
      });
      
      setCustomItem({ item_name: '', quantity: 1, price: '' });
      fetchBillDetails(currentBill.id);
      alert('Item added successfully!');
    } catch (error) {
      console.error('Error adding item:', error);
      alert('Error adding item');
    } finally {
      setLoading(false);
    }
  };

  const fetchBillDetails = async (billId) => {
    try {
      const response = await axios.get(`/api/bills/${billId}/`);
      setCurrentBill(response.data);
    } catch (error) {
      console.error('Error fetching bill details:', error);
    }
  };

  const applyGST = async () => {
    if (!currentBill) return;

    setLoading(true);
    try {
      const response = await axios.post('/api/bills/enhanced/apply-gst/', {
        bill_id: currentBill.id,
        apply_gst: gstSettings.apply_gst,
        interstate: gstSettings.interstate
      });
      
      setCurrentBill(response.data.bill_details);
      alert('GST applied successfully!');
    } catch (error) {
      console.error('Error applying GST:', error);
    } finally {
      setLoading(false);
    }
  };

  const finalizeBill = async () => {
    if (!currentBill) return;

    if (!window.confirm('Finalize this bill and release the table?')) {
      return;
    }

    setLoading(true);
    try {
      await axios.post('/api/bills/enhanced/finalize-bill/', {
        bill_id: currentBill.id
      });
      
      alert('Bill finalized and table released!');
      setCurrentBill(null);
      setSelectedTable(null);
      fetchActiveTables();
    } catch (error) {
      console.error('Error finalizing bill:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto p-6">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">🧾 Enhanced Billing System</h1>
          <p className="text-gray-600 mt-2">Dynamic billing with GST calculation and admin controls</p>
        </div>
        <div className="text-right">
          <div className="text-2xl font-bold text-blue-600">{activeTables.length}</div>
          <div className="text-gray-500">Active Tables</div>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Active Tables Section */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold mb-4">📍 Active Tables</h2>
            
            <div className="space-y-4 max-h-96 overflow-y-auto">
              {activeTables.map(table => (
                <div
                  key={table.table_id}
                  className={`border rounded-lg p-4 cursor-pointer transition-colors ${
                    selectedTable === table.table_id 
                      ? 'border-blue-500 bg-blue-50' 
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => setSelectedTable(table.table_id)}
                >
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="font-medium">Table {table.table_number}</h3>
                      <p className="text-sm text-gray-500">
                        {table.orders_count} orders • ₹{table.total_amount}
                      </p>
                    </div>
                    {table.can_generate_bill && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          createBillForTable(table.table_id);
                        }}
                        className="bg-green-600 text-white px-3 py-1 rounded text-sm hover:bg-green-700"
                        disabled={loading}
                      >
                        Create Bill
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Bill Management Section */}
        <div className="lg:col-span-2">
          {currentBill ? (
            <div className="space-y-6">
              {/* Bill Header */}
              <div className="bg-white rounded-lg shadow-md p-6">
                <div className="flex justify-between items-center">
                  <div>
                    <h2 className="text-xl font-semibold">
                      Bill #{currentBill.receipt_number || currentBill.id}
                    </h2>
                    <p className="text-gray-600">{currentBill.customer_name}</p>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-green-600">
                      ₹{currentBill.total_amount}
                    </div>
                    <div className="text-sm text-gray-500">
                      Payment: {currentBill.payment_method}
                    </div>
                  </div>
                </div>
              </div>

              {/* Add Custom Item */}
              <div className="bg-white rounded-lg shadow-md p-6">
                <h3 className="text-lg font-medium mb-4">➕ Add Custom Item</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <input
                    type="text"
                    placeholder="Item Name"
                    value={customItem.item_name}
                    onChange={(e) => setCustomItem({ ...customItem, item_name: e.target.value })}
                    className="border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <input
                    type="number"
                    placeholder="Quantity"
                    value={customItem.quantity}
                    onChange={(e) => setCustomItem({ ...customItem, quantity: e.target.value })}
                    className="border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    min="1"
                  />
                  <input
                    type="number"
                    step="0.01"
                    placeholder="Unit Price"
                    value={customItem.price}
                    onChange={(e) => setCustomItem({ ...customItem, price: e.target.value })}
                    className="border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    min="0"
                  />
                  <button
                    onClick={addCustomItem}
                    disabled={loading}
                    className="flex items-center justify-center bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 disabled:opacity-50"
                  >
                    <PlusIcon className="h-4 w-4 mr-2" />
                    {loading ? 'Adding...' : 'Add Item'}
                  </button>
                </div>
              </div>

              {/* GST Settings */}
              <div className="bg-white rounded-lg shadow-md p-6">
                <h3 className="text-lg font-medium mb-4">💰 GST Settings</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={gstSettings.apply_gst}
                      onChange={(e) => setGstSettings({ ...gstSettings, apply_gst: e.target.checked })}
                      className="mr-2"
                    />
                    Apply GST (18%)
                  </label>
                  
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={gstSettings.interstate}
                      onChange={(e) => setGstSettings({ ...gstSettings, interstate: e.target.checked })}
                      disabled={!gstSettings.apply_gst}
                      className="mr-2"
                    />
                    Interstate Transaction
                  </label>
                  
                  <button
                    onClick={applyGST}
                    disabled={loading}
                    className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 disabled:opacity-50"
                  >
                    {loading ? 'Applying...' : 'Apply GST'}
                  </button>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="bg-white rounded-lg shadow-md p-6">
                <div className="flex space-x-4">
                  <button
                    onClick={() => window.print()}
                    className="flex items-center bg-gray-600 text-white px-6 py-2 rounded-md hover:bg-gray-700"
                  >
                    <PrinterIcon className="h-4 w-4 mr-2" />
                    Print Bill
                  </button>
                  
                  <button
                    onClick={finalizeBill}
                    disabled={loading}
                    className="bg-purple-600 text-white px-6 py-2 rounded-md hover:bg-purple-700 disabled:opacity-50"
                  >
                    {loading ? 'Finalizing...' : '✅ Finalize & Release Table'}
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow-md p-12 text-center">
              <div className="text-6xl mb-4">📋</div>
              <h3 className="text-xl font-medium text-gray-900 mb-2">Select a Table</h3>
              <p className="text-gray-500">Choose a table from the left panel to create or manage a bill</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default EnhancedBilling;
```

---

## 🍳 KITCHEN DISPLAY COMPONENT (CORRECTED JSX)

### src/pages/Kitchen/KitchenDisplay.js

```javascript
import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { CheckIcon, XMarkIcon, ClockIcon } from '@heroicons/react/24/outline';

const KitchenDisplay = () => {
  const [orders, setOrders] = useState([]);
  const [stats, setStats] = useState({});
  const [audioEnabled, setAudioEnabled] = useState(true);
  const [loading, setLoading] = useState(false);
  const audioRef = useRef(null);

  useEffect(() => {
    fetchActiveOrders();
    fetchKitchenStats();
    
    const ordersInterval = setInterval(fetchActiveOrders, 5000);
    const statsInterval = setInterval(fetchKitchenStats, 30000);
    
    return () => {
      clearInterval(ordersInterval);
      clearInterval(statsInterval);
    };
  }, []);

  const fetchActiveOrders = async () => {
    try {
      const response = await axios.get('/api/kitchen/orders/active_orders/');
      const newOrders = response.data;
      
      if (audioEnabled && orders.length > 0 && newOrders.length > orders.length) {
        playNewOrderAlert();
      }
      
      setOrders(newOrders);
    } catch (error) {
      console.error('Error fetching kitchen orders:', error);
    }
  };

  const fetchKitchenStats = async () => {
    try {
      const response = await axios.get('/api/kitchen/orders/kitchen_stats/');
      setStats(response.data);
    } catch (error) {
      console.error('Error fetching kitchen stats:', error);
    }
  };

  const playNewOrderAlert = () => {
    if (audioRef.current) {
      audioRef.current.play().catch(console.error);
    }
  };

  const updateOrderStatus = async (orderId, newStatus, chefName = '') => {
    setLoading(true);
    try {
      await axios.post(`/api/kitchen/orders/${orderId}/update_order_status/`, {
        status: newStatus,
        chef_name: chefName
      });
      
      await fetchActiveOrders();
    } catch (error) {
      console.error('Error updating order status:', error);
      alert('Error updating order status');
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      'received': 'bg-blue-100 text-blue-800',
      'preparing': 'bg-yellow-100 text-yellow-800',
      'ready': 'bg-green-100 text-green-800',
      'cancelled': 'bg-red-100 text-red-800'
    };
    return colors[status] || colors['received'];
  };

  const getPriorityColor = (priority) => {
    const colors = {
      1: 'border-l-green-500',
      2: 'border-l-blue-500',
      3: 'border-l-yellow-500',
      4: 'border-l-red-500'
    };
    return colors[priority] || colors[2];
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Audio element */}
      <audio ref={audioRef} preload="auto">
        <source src="/sounds/kitchen-alert.mp3" type="audio/mpeg" />
      </audio>

      {/* Header */}
      <div className="bg-gray-800 p-6 shadow-lg">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">🍳 Kitchen Display System</h1>
            <p className="text-gray-300 mt-2">Real-time order management with audio alerts</p>
          </div>
          
          <div className="flex items-center space-x-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-400">{orders.length}</div>
              <div className="text-sm text-gray-300">Active Orders</div>
            </div>
            
            <button
              onClick={() => setAudioEnabled(!audioEnabled)}
              className={`px-4 py-2 rounded-lg font-medium ${
                audioEnabled
                  ? 'bg-green-600 hover:bg-green-700'
                  : 'bg-gray-600 hover:bg-gray-700'
              }`}
            >
              {audioEnabled ? '🔊 Audio ON' : '🔇 Audio OFF'}
            </button>
            
            <div className="text-sm text-gray-300">
              {new Date().toLocaleTimeString()}
            </div>
          </div>
        </div>
      </div>

      {/* Kitchen Stats */}
      <div className="bg-gray-800 px-6 py-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-400">{stats.total_orders || 0}</div>
            <div className="text-sm text-gray-400">Total Today</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-400">{stats.completed || 0}</div>
            <div className="text-sm text-gray-400">Completed</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-yellow-400">{stats.preparing || 0}</div>
            <div className="text-sm text-gray-400">Preparing</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-400">{stats.average_prep_time || 0}m</div>
            <div className="text-sm text-gray-400">Avg Prep Time</div>
          </div>
        </div>
      </div>

      {/* Orders Grid */}
      <div className="p-6">
        {orders.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {orders.map(order => (
              <div
                key={order.id}
                className={`bg-white text-gray-900 rounded-lg shadow-lg p-4 border-l-4 ${getPriorityColor(order.priority)} ${
                  !order.audio_acknowledged ? 'animate-pulse ring-2 ring-red-500' : ''
                }`}
              >
                {/* Order Header */}
                <div className="flex justify-between items-center mb-3">
                  <div>
                    <h3 className="font-bold text-lg">#{order.bill_receipt}</h3>
                    <p className="text-gray-600">
                      {order.table_number !== 'Takeaway' ? `Table ${order.table_number}` : 'Takeaway'}
                    </p>
                  </div>
                  
                  <div className="text-right">
                    <span className={`inline-flex px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>
                      {order.status_display}
                    </span>
                    <div className="text-sm text-gray-500 mt-1 flex items-center">
                      <ClockIcon className="h-4 w-4 mr-1" />
                      {order.time_elapsed}m ago
                    </div>
                  </div>
                </div>

                {/* Order Items */}
                <div className="mb-4">
                  <h4 className="font-medium text-gray-900 mb-2">Items:</h4>
                  <div className="space-y-1 max-h-32 overflow-y-auto">
                    {order.items?.map((item, index) => (
                      <div key={index} className="bg-gray-50 p-2 rounded text-sm flex justify-between">
                        <span className="font-medium">{item.name}</span>
                        <span className="text-gray-600">×{item.quantity}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Special Instructions */}
                {order.special_instructions && (
                  <div className="mb-4 p-2 bg-yellow-50 border-l-4 border-yellow-400">
                    <p className="text-sm text-yellow-800">
                      <strong>Special: </strong>
                      {order.special_instructions}
                    </p>
                  </div>
                )}

                {/* Action Buttons */}
                <div className="flex flex-col space-y-2">
                  {order.status === 'received' && (
                    <button
                      onClick={() => updateOrderStatus(order.id, 'preparing', 'Chef')}
                      disabled={loading}
                      className="w-full bg-blue-600 text-white py-2 px-3 rounded text-sm font-medium hover:bg-blue-700 disabled:opacity-50"
                    >
                      👨‍🍳 Start Cooking
                    </button>
                  )}
                  
                  {order.status === 'preparing' && (
                    <button
                      onClick={() => updateOrderStatus(order.id, 'ready')}
                      disabled={loading}
                      className="w-full bg-green-600 text-white py-2 px-3 rounded text-sm font-medium hover:bg-green-700 disabled:opacity-50 flex items-center justify-center"
                    >
                      <CheckIcon className="h-4 w-4 mr-1" />
                      Ready to Serve
                    </button>
                  )}
                  
                  {order.status === 'ready' && (
                    <button
                      onClick={() => updateOrderStatus(order.id, 'served')}
                      disabled={loading}
                      className="w-full bg-purple-600 text-white py-2 px-3 rounded text-sm font-medium hover:bg-purple-700 disabled:opacity-50"
                    >
                      🍽️ Mark Served
                    </button>
                  )}

                  <button
                    onClick={() => {
                      if (window.confirm('Are you sure you want to cancel this order?')) {
                        updateOrderStatus(order.id, 'cancelled');
                      }
                    }}
                    disabled={loading}
                    className="w-full bg-gray-600 text-white py-1 px-3 rounded text-xs font-medium hover:bg-gray-700 disabled:opacity-50 flex items-center justify-center"
                  >
                    <XMarkIcon className="h-4 w-4 mr-1" />
                    Cancel
                  </button>
                </div>

                {/* Estimated Time */}
                <div className="mt-3 text-center text-xs text-gray-500 border-t pt-2">
                  Est. Time: {order.estimated_time}min
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">🍽️</div>
            <h3 className="text-xl font-medium mb-2">No Active Orders</h3>
            <p className="text-gray-400">Orders will appear here when placed</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default KitchenDisplay;
```

---

## 🚀 SETUP COMMANDS FOR REACT.JS

```bash
# 1. Check if you have Node.js installed
node --version
npm --version

# 2. If React app exists, install dependencies
cd hotel-management-frontend
npm install

# 3. If React app doesn't exist, create it
npx create-react-app hotel-management-frontend
cd hotel-management-frontend

# 4. Install additional dependencies
npm install axios react-query react-router-dom @heroicons/react @headlessui/react

# 5. Install Tailwind CSS
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init

# 6. Start React development server
npm start
```

## 📁 FOLDER STRUCTURE

```
hotel-management-frontend/
├── public/
│   ├── index.html
│   └── sounds/
│       └── kitchen-alert.mp3
├── src/
│   ├── components/
│   │   └── Layout/
│   ├── pages/
│   │   ├── Billing/
│   │   ├── Kitchen/
│   │   ├── Mobile/
│   │   └── Staff/
│   ├── App.js
│   ├── index.js
│   └── index.css
├── package.json
└── tailwind.config.js
```

**You're using React.js frontend with Django backend - this is the correct setup!**