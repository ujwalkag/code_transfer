// components/staff/StaffManagement.js - PRECISE UPDATE WITH ADD/DELETE FUNCTIONALITY
// Based on the EXACT current code structure, only adding missing features

import React, { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';

const StaffManagement = () => {
  const { user } = useAuth();
  const [staff, setStaff] = useState([]);
  const [attendanceRecords, setAttendanceRecords] = useState([]);
  const [selectedStaff, setSelectedStaff] = useState(null);
  const [activeTab, setActiveTab] = useState('overview');
  const [currentMonth, setCurrentMonth] = useState(new Date().getMonth() + 1);
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
  const [loading, setLoading] = useState(false);

  // NEW: Add Staff Modal State
  const [showAddStaffModal, setShowAddStaffModal] = useState(false);
  const [newStaffData, setNewStaffData] = useState({
    full_name: '',
    email: '',
    password: '',
    phone: '',
    department: 'service',
    position: '',
    base_salary: '',
    hourly_rate: ''
  });

  useEffect(() => {
    fetchStaff();
    fetchAttendance();
  }, [currentMonth, currentYear]);

  const fetchStaff = async () => {
    try {
      const response = await fetch('/api/staff/profiles/', {
        headers: { Authorization: `Bearer ${user.access}` }
      });
      const data = await response.json();
      setStaff(data.results || data);
    } catch (error) {
      console.error('Error fetching staff:', error);
    }
  };

  const fetchAttendance = async () => {
    try {
      const response = await fetch(`/api/staff/attendance/?month=${currentMonth}&year=${currentYear}`, {
        headers: { Authorization: `Bearer ${user.access}` }
      });
      const data = await response.json();
      setAttendanceRecords(data.results || data);
    } catch (error) {
      console.error('Error fetching attendance:', error);
    }
  };

  // NEW: Add Staff Function - Uses existing backend API structure
  const addNewStaff = async () => {
    if (!newStaffData.full_name || !newStaffData.email || !newStaffData.password) {
      alert('Please fill in all required fields (Name, Email, Password)');
      return;
    }

    setLoading(true);
    try {
      // First create the user using existing StaffUserViewSet
      const userResponse = await fetch('/api/users/staff/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${user.access}`
        },
        body: JSON.stringify({
          email: newStaffData.email,
          password: newStaffData.password,
          first_name: newStaffData.full_name.split(' ')[0],
          last_name: newStaffData.full_name.split(' ').slice(1).join(' ')
        })
      });

      if (userResponse.ok) {
        const userData = await userResponse.json();
        
        // Then create staff profile using existing API
        const staffResponse = await fetch('/api/staff/profiles/', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${user.access}`
          },
          body: JSON.stringify({
            user: userData.user.id, // Use the user ID from response
            full_name: newStaffData.full_name,
            phone: newStaffData.phone,
            department: newStaffData.department,
            position: newStaffData.position,
            base_salary: newStaffData.base_salary || 0,
            hourly_rate: newStaffData.hourly_rate || 0,
            employment_status: 'active'
          })
        });

        if (staffResponse.ok) {
          alert('Staff member added successfully!');
          fetchStaff(); // Refresh staff list
          setShowAddStaffModal(false);
          setNewStaffData({
            full_name: '', email: '', password: '', phone: '',
            department: 'service', position: '', base_salary: '', hourly_rate: ''
          });
        } else {
          const error = await staffResponse.json();
          alert('Failed to create staff profile: ' + JSON.stringify(error));
        }
      } else {
        const error = await userResponse.json();
        alert('Failed to create user account: ' + (error.error || JSON.stringify(error)));
      }
    } catch (error) {
      console.error('Error adding staff:', error);
      alert('Network error occurred');
    } finally {
      setLoading(false);
    }
  };

  // NEW: Delete Staff Function - Uses existing backend API
  const deleteStaff = async (staffId, staffName) => {
    if (!window.confirm(`Are you sure you want to delete ${staffName}? This action cannot be undone.`)) {
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`/api/staff/profiles/${staffId}/`, {
        method: 'DELETE',
        headers: {
          Authorization: `Bearer ${user.access}`
        }
      });

      if (response.ok) {
        alert('Staff member deleted successfully!');
        fetchStaff(); // Refresh staff list
      } else {
        const error = await response.json();
        alert('Failed to delete staff: ' + (error.error || 'Unknown error'));
      }
    } catch (error) {
      console.error('Error deleting staff:', error);
      alert('Network error occurred');
    } finally {
      setLoading(false);
    }
  };

  const markAttendance = async (staffId, status) => {
    setLoading(true);
    try {
      const response = await fetch('/api/staff/attendance/mark_attendance/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${user.access}`
        },
        body: JSON.stringify({
          staff_id: staffId,
          status: status,
          date: new Date().toISOString().split('T')[0]
        })
      });

      if (response.ok) {
        fetchAttendance();
        alert(`Attendance marked as ${status} successfully!`);
      } else {
        alert('Failed to mark attendance');
      }
    } catch (error) {
      console.error('Error marking attendance:', error);
      alert('Network error occurred');
    } finally {
      setLoading(false);
    }
  };

  // EXISTING: Keep the original generatePayroll function as is
  const generatePayroll = async (staffId) => {
    setLoading(true);
    try {
      const response = await fetch('/api/staff/payroll/generate/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${user.access}`
        },
        body: JSON.stringify({
          staff_id: staffId,
          month: currentMonth,
          year: currentYear
        })
      });

      const result = await response.json();
      if (result.success) {
        alert('Payroll generated successfully!');
        fetchStaff(); // Refresh to show updated payroll info
      } else {
        alert('Failed to generate payroll: ' + result.error);
      }
    } catch (error) {
      console.error('Error generating payroll:', error);
      alert('Network error occurred');
    } finally {
      setLoading(false);
    }
  };

  // EXISTING: Keep all existing utility functions exactly as they are
  const getAttendanceStatus = (staffId) => {
    const today = new Date().toISOString().split('T')[0];
    const todayAttendance = attendanceRecords.find(
      record => record.staff_id === staffId && record.date === today
    );
    return todayAttendance ? todayAttendance.status : 'not_marked';
  };

  const getMonthlyStats = (staffId) => {
    const staffAttendance = attendanceRecords.filter(record => record.staff_id === staffId);
    const present = staffAttendance.filter(record => record.status === 'present').length;
    const absent = staffAttendance.filter(record => record.status === 'absent').length;
    const totalHours = staffAttendance.reduce((sum, record) => sum + (record.total_hours || 0), 0);
    const overtimeHours = staffAttendance.reduce((sum, record) => sum + (record.overtime_hours || 0), 0);

    return { present, absent, totalHours, overtimeHours };
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* UPDATED: Header with Add Staff Button */}
      <div className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          {/* UPDATED: Add button to existing header */}
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">👥 Staff Management</h1>
              <p className="text-gray-600">Manage attendance, payroll, and staff information</p>
            </div>
            
            {/* NEW: Add Staff Button */}
            <button
              onClick={() => setShowAddStaffModal(true)}
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
            >
              <span>👤</span> Add New Staff
            </button>
          </div>
          
          {/* EXISTING: Keep month/year selectors exactly as they are */}
          <div className="flex gap-4 items-center">
            <select
              value={currentMonth}
              onChange={(e) => setCurrentMonth(Number(e.target.value))}
              className="border rounded px-3 py-2"
            >
              {Array.from({length: 12}, (_, i) => (
                <option key={i} value={i + 1}>
                  {new Date(2024, i).toLocaleString('default', { month: 'long' })}
                </option>
              ))}
            </select>
            <select
              value={currentYear}
              onChange={(e) => setCurrentYear(Number(e.target.value))}
              className="border rounded px-3 py-2"
            >
              {Array.from({length: 5}, (_, i) => (
                <option key={i} value={2022 + i}>
                  {2022 + i}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* EXISTING: Keep navigation tabs exactly as they are */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex gap-1 bg-gray-200 p-1 rounded-lg w-fit">
          {['overview', 'attendance', 'payroll', 'advances'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 rounded-md font-medium transition-colors ${
                activeTab === tab 
                  ? 'bg-white text-blue-600 shadow' 
                  : 'text-gray-700 hover:text-blue-600'
              }`}
            >
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* UPDATED: Overview Tab with delete buttons */}
      {activeTab === 'overview' && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {staff.map(member => {
              const attendanceStatus = getAttendanceStatus(member.id);
              const monthlyStats = getMonthlyStats(member.id);

              return (
                <div key={member.id} className="bg-white rounded-lg shadow p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="font-bold text-lg">{member.full_name}</h3>
                      <p className="text-gray-600">{member.position}</p>
                      <p className="text-sm text-gray-500">{member.employee_id}</p>
                    </div>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      attendanceStatus === 'present' ? 'bg-green-100 text-green-800' :
                      attendanceStatus === 'absent' ? 'bg-red-100 text-red-800' :
                      'bg-gray-100 text-gray-800'
                    }`}>
                      {attendanceStatus === 'not_marked' ? 'Not Marked' : attendanceStatus}
                    </span>
                  </div>

                  {/* EXISTING: Keep all data display exactly as is */}
                  <div className="space-y-2 text-sm text-gray-600 mb-4">
                    <div className="flex justify-between">
                      <span>Department:</span>
                      <span>{member.department}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Base Salary:</span>
                      <span>₹{member.base_salary}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Days Present:</span>
                      <span>{monthlyStats.present}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Total Hours:</span>
                      <span>{monthlyStats.totalHours.toFixed(1)}h</span>
                    </div>
                  </div>

                  {/* UPDATED: Add delete button to existing actions */}
                  <div className="flex gap-2 flex-wrap">
                    {attendanceStatus === 'not_marked' && (
                      <>
                        <button
                          onClick={() => markAttendance(member.id, 'present')}
                          disabled={loading}
                          className="px-3 py-1 bg-green-500 hover:bg-green-600 text-white text-sm rounded disabled:opacity-50"
                        >
                          Present
                        </button>
                        <button
                          onClick={() => markAttendance(member.id, 'absent')}
                          disabled={loading}
                          className="px-3 py-1 bg-red-500 hover:bg-red-600 text-white text-sm rounded disabled:opacity-50"
                        >
                          Absent
                        </button>
                      </>
                    )}

                    <button
                      onClick={() => generatePayroll(member.id)}
                      disabled={loading}
                      className="px-3 py-1 bg-green-500 hover:bg-green-600 text-white text-sm rounded disabled:opacity-50"
                    >
                      Generate Payroll
                    </button>

                    <button
                      onClick={() => setSelectedStaff(member)}
                      className="px-3 py-1 bg-blue-500 hover:bg-blue-600 text-white text-sm rounded"
                    >
                      Details
                    </button>

                    {/* NEW: Delete Button */}
                    <button
                      onClick={() => deleteStaff(member.id, member.full_name)}
                      disabled={loading}
                      className="px-3 py-1 bg-red-500 hover:bg-red-600 text-white text-sm rounded disabled:opacity-50"
                      title="Delete Staff"
                    >
                      🗑️
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* EXISTING: Keep Attendance Tab exactly as is */}
      {activeTab === 'attendance' && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-8">
          <div className="bg-white rounded-lg shadow overflow-x-auto">
            <table className="min-w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Staff</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Today Status</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">This Month</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Total Hours</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Overtime</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {staff.map(member => {
                  const attendanceStatus = getAttendanceStatus(member.id);
                  const monthlyStats = getMonthlyStats(member.id);

                  return (
                    <tr key={member.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">{member.full_name}</div>
                        <div className="text-sm text-gray-500">{member.employee_id}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          attendanceStatus === 'present' ? 'bg-green-100 text-green-800' :
                          attendanceStatus === 'absent' ? 'bg-red-100 text-red-800' :
                          'bg-gray-100 text-gray-800'
                        }`}>
                          {attendanceStatus === 'not_marked' ? 'Not Marked' : attendanceStatus}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        <div>Present: {monthlyStats.present}</div>
                        <div>Absent: {monthlyStats.absent}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {monthlyStats.totalHours.toFixed(1)}h
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {monthlyStats.overtimeHours.toFixed(1)}h
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        {attendanceStatus === 'not_marked' && (
                          <div className="flex gap-2">
                            <button
                              onClick={() => markAttendance(member.id, 'present')}
                              disabled={loading}
                              className="text-green-600 hover:text-green-900"
                            >
                              Present
                            </button>
                            <button
                              onClick={() => markAttendance(member.id, 'absent')}
                              disabled={loading}
                              className="text-red-600 hover:text-red-900"
                            >
                              Absent
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* EXISTING: Keep Payroll Tab exactly as is */}
      {activeTab === 'payroll' && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {staff.map(member => {
              const monthlyStats = getMonthlyStats(member.id);
              const baseSalary = parseFloat(member.base_salary);
              const overtimeAmount = monthlyStats.overtimeHours * parseFloat(member.hourly_rate || 0) * 1.5;
              const grossSalary = baseSalary + overtimeAmount;

              return (
                <div key={member.id} className="bg-white rounded-lg shadow p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="font-bold text-lg">{member.full_name}</h3>
                      <p className="text-gray-600">{member.employee_id} - {member.position}</p>
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex justify-between items-center p-3 bg-gray-50 rounded">
                      <span>Base Salary</span>
                      <span className="font-semibold">₹{baseSalary.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-blue-50 rounded">
                      <div>
                        <div>Overtime</div>
                        <div className="text-sm text-gray-600">{monthlyStats.overtimeHours.toFixed(1)}h</div>
                      </div>
                      <span className="font-semibold">₹{overtimeAmount.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-green-50 rounded border-2 border-green-200">
                      <span className="font-bold">Gross Salary</span>
                      <span className="font-bold text-lg">₹{grossSalary.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-gray-50 rounded">
                      <span>Days Present</span>
                      <span className="font-semibold">{monthlyStats.present}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* EXISTING: Keep Advances Tab exactly as is */}
      {activeTab === 'advances' && (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-8">
          <div className="bg-white rounded-lg shadow p-8 text-center">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">💰 Advance Payment Management</h2>
            <p className="text-gray-600">Feature coming soon...</p>
          </div>
        </div>
      )}

      {/* EXISTING: Keep Staff Detail Modal exactly as is */}
      {selectedStaff && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-2xl">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold">{selectedStaff.full_name} - Details</h2>
              <button
                onClick={() => setSelectedStaff(null)}
                className="text-gray-400 hover:text-gray-600"
              >
                ✕
              </button>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <div className="border-b pb-2">
                  <label className="text-sm text-gray-600">Employee ID</label>
                  <p className="font-semibold">{selectedStaff.employee_id}</p>
                </div>
                <div className="border-b pb-2">
                  <label className="text-sm text-gray-600">Department</label>
                  <p className="font-semibold">{selectedStaff.department}</p>
                </div>
                <div className="border-b pb-2">
                  <label className="text-sm text-gray-600">Position</label>
                  <p className="font-semibold">{selectedStaff.position}</p>
                </div>
              </div>
              <div className="space-y-4">
                <div className="border-b pb-2">
                  <label className="text-sm text-gray-600">Base Salary</label>
                  <p className="font-semibold">₹{selectedStaff.base_salary}</p>
                </div>
                <div className="border-b pb-2">
                  <label className="text-sm text-gray-600">Hourly Rate</label>
                  <p className="font-semibold">₹{selectedStaff.hourly_rate}</p>
                </div>
                <div className="border-b pb-2">
                  <label className="text-sm text-gray-600">Status</label>
                  <p className="font-semibold">{selectedStaff.employment_status}</p>
                </div>
              </div>
            </div>

            <div className="mt-6 p-4 bg-gray-50 rounded">
              <h3 className="font-bold mb-2">Monthly Performance</h3>
              <p className="text-gray-600 text-sm">
                Attendance chart and performance metrics would be displayed here
              </p>
            </div>
            
            <div className="mt-6 flex justify-end">
              <button
                onClick={() => setSelectedStaff(null)}
                className="px-4 py-2 bg-gray-300 hover:bg-gray-400 text-gray-700 rounded-lg"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* NEW: Add Staff Modal */}
      {showAddStaffModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md max-h-screen overflow-y-auto">
            <h2 className="text-xl font-bold mb-4">Add New Staff Member</h2>
            
            <div className="space-y-4">
              <input
                type="text"
                placeholder="Full Name *"
                value={newStaffData.full_name}
                onChange={(e) => setNewStaffData({...newStaffData, full_name: e.target.value})}
                className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
                required
              />
              
              <input
                type="email"
                placeholder="Email *"
                value={newStaffData.email}
                onChange={(e) => setNewStaffData({...newStaffData, email: e.target.value})}
                className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
                required
              />
              
              <input
                type="password"
                placeholder="Password *"
                value={newStaffData.password}
                onChange={(e) => setNewStaffData({...newStaffData, password: e.target.value})}
                className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
                required
              />
              
              <input
                type="tel"
                placeholder="Phone"
                value={newStaffData.phone}
                onChange={(e) => setNewStaffData({...newStaffData, phone: e.target.value})}
                className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
              />
              
              <select
                value={newStaffData.department}
                onChange={(e) => setNewStaffData({...newStaffData, department: e.target.value})}
                className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
              >
                <option value="service">Service</option>
                <option value="kitchen">Kitchen</option>
                <option value="housekeeping">Housekeeping</option>
                <option value="management">Management</option>
                <option value="billing">Billing</option>
              </select>
              
              <input
                type="text"
                placeholder="Position"
                value={newStaffData.position}
                onChange={(e) => setNewStaffData({...newStaffData, position: e.target.value})}
                className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
              />
              
              <input
                type="number"
                placeholder="Base Salary"
                value={newStaffData.base_salary}
                onChange={(e) => setNewStaffData({...newStaffData, base_salary: e.target.value})}
                className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
              />
              
              <input
                type="number"
                placeholder="Hourly Rate"
                value={newStaffData.hourly_rate}
                onChange={(e) => setNewStaffData({...newStaffData, hourly_rate: e.target.value})}
                className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-blue-500"
              />
            </div>
            
            <div className="flex gap-3 mt-6">
              <button
                onClick={addNewStaff}
                disabled={loading}
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg disabled:opacity-50 transition-colors"
              >
                {loading ? 'Adding...' : 'Add Staff'}
              </button>
              
              <button
                onClick={() => {
                  setShowAddStaffModal(false);
                  setNewStaffData({
                    full_name: '', email: '', password: '', phone: '',
                    department: 'service', position: '', base_salary: '', hourly_rate: ''
                  });
                }}
                className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-700 py-2 rounded-lg transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default StaffManagement;