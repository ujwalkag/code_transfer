# apps/staff/urls.py - PRECISE ADDITION to existing URLs

# This is your EXACT current urls.py with ONLY the payroll endpoint added:

from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

# Create router and register viewsets
router = DefaultRouter()
router.register(r'profiles', views.StaffProfileViewSet, basename='staffprofile')
router.register(r'attendance', views.AttendanceViewSet, basename='attendance')

urlpatterns = [
    # Include router URLs
    path('', include(router.urls)),
    
    # ADD ONLY THIS LINE - Payroll generation endpoint
    path('payroll/generate/', views.generate_payroll, name='generate-payroll'),
]