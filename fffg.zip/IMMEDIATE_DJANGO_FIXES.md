# 🚨 IMMEDIATE DJANGO ERROR FIXES

## ❌ **YOUR CURRENT ERROR:**
```bash
ImportError: cannot import name 'TableSerializer' from 'apps.tables.serializers'
```

---

# 🔧 **IMMEDIATE FIX 1: Fix Serializer Import Error**

**Edit this file:** `/home/ubuntu/hotel-management-backend/apps/tables/views.py`

**Find line 9 (the import section) and REPLACE with:**
```python
# REPLACE the import section in views.py with this:
from .serializers import (
    RestaurantTableSerializer,
    TableOrderSerializer, 
    TableOrderCreateSerializer,
    OrderItemSerializer,
    OrderItemCreateSerializer,
    KitchenDisplaySerializer,
    OrderItemUpdateSerializer
)
```

**Then CHANGE line ~25 from:**
```python
serializer_class = TableSerializer
```

**TO:**
```python
serializer_class = RestaurantTableSerializer
```

---

# 🔧 **IMMEDIATE FIX 2: Remove PayrollStaff from views.py**

**Edit this file:** `/home/ubuntu/hotel-management-backend/apps/staff/views.py`

**Find around line 507 and DELETE this entire class:**
```python
# DELETE THIS ENTIRE BLOCK FROM views.py:
class PayrollStaff(models.Model):
    # ... entire class definition
```

**Replace any reference to PayrollStaff in views.py with StaffProfile**

---

# 🔧 **IMMEDIATE FIX 3: Simple Command Sequence**

```bash
cd /home/ubuntu/hotel-management-backend
source venv/bin/activate

# 1. Quick fix for serializers
nano apps/tables/views.py
# Change TableSerializer to RestaurantTableSerializer in the import and class

# 2. Quick fix for staff views
nano apps/staff/views.py  
# Remove the PayrollStaff model class from this file

# 3. Try migrations again
python manage.py check
python manage.py makemigrations
python manage.py migrate

# 4. Restart
sudo systemctl restart gunicorn
```

---

# 🔧 **EXACT FILE CONTENT TO REPLACE**

## **File 1: apps/tables/views.py - Lines 1-20**
```python
# apps/tables/views.py - FIRST 20 LINES REPLACEMENT
from rest_framework import viewsets, status
from rest_framework.decorators import action, api_view, permission_classes
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.shortcuts import get_object_or_404
from django.utils import timezone
from django.db.models import Q, Count, Sum
from datetime import datetime, timedelta
from .models import RestaurantTable, TableOrder, OrderItem, KitchenDisplayItem

# FIXED IMPORTS - Use exact names from serializers.py
from .serializers import (
    RestaurantTableSerializer,
    TableOrderSerializer,
    TableOrderCreateSerializer,
    OrderItemSerializer,
    OrderItemCreateSerializer,
    KitchenDisplaySerializer,
    OrderItemUpdateSerializer
)

class RestaurantTableViewSet(viewsets.ModelViewSet):
    """ViewSet for managing restaurant tables"""
    queryset = RestaurantTable.objects.all()
    serializer_class = RestaurantTableSerializer  # FIXED: Use correct name
    permission_classes = [IsAuthenticated]
```

## **File 2: apps/staff/views.py - Remove Model Class**

**Find this in views.py and DELETE it entirely:**
```python
# DELETE THIS ENTIRE SECTION FROM views.py (around line 507):
class PayrollStaff(models.Model):
    """Separate payroll staff not linked to login accounts"""
    
    DEPARTMENT_CHOICES = (
        ('kitchen', 'Kitchen'),
        ('service', 'Service'),
        ('housekeeping', 'Housekeeping'),
        ('management', 'Management'),
        ('billing', 'Billing'),
    )
    
    employee_id = models.CharField(max_length=20, unique=True, blank=True)
    full_name = models.CharField(max_length=255)
    phone = models.CharField(max_length=15)
    department = models.CharField(max_length=20, choices=DEPARTMENT_CHOICES)
    position = models.CharField(max_length=100)
    base_salary = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    hourly_rate = models.DecimalField(max_digits=8, decimal_places=2, default=0)
    created_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def save(self, *args, **kwargs):
        if not self.employee_id:
            self.employee_id = f"PAY{uuid.uuid4().hex[:6].upper()}"
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.full_name} ({self.employee_id})"

    class Meta:
        db_table = 'payroll_staff'
        verbose_name = 'Payroll Staff'
        verbose_name_plural = 'Payroll Staff'
```

---

# 🎯 **SIMPLEST WORKING SOLUTION**

**Just make these 2 changes:**

1. **In `apps/tables/views.py` line ~12:**
   Change `TableSerializer` to `RestaurantTableSerializer`

2. **In `apps/staff/views.py` around line 507:**
   Delete the entire `class PayrollStaff(models.Model):` block

**Then run:**
```bash
python manage.py check
python manage.py makemigrations
python manage.py migrate
sudo systemctl restart gunicorn
```

**This should immediately resolve your Django errors and get your system running!** 🚀

The main issue is that your `views.py` files are trying to import serializers and models that don't exist or are in the wrong place. These two simple fixes will resolve the import errors.