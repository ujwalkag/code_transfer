// CORRECTED Frontend Enhancements - Integrated with Existing Structure

// ENHANCED WAITER COMPONENT

// pages/waiter/mobile-orders.js - Enhanced Mobile Waiter Interface
// This builds on your existing waiter/index.js and waiter/create-order.js

import { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useLanguage } from '@/context/LanguageContext';
import withRoleGuard from '@/hoc/withRoleGuard';
import { useRouter } from 'next/router';
import toast from 'react-hot-toast';

function EnhancedWaiterOrders() {
  const { user } = useAuth();
  const { language } = useLanguage();
  const router = useRouter();
  const [tables, setTables] = useState([]);
  const [selectedTable, setSelectedTable] = useState(null);
  const [menuItems, setMenuItems] = useState([]);
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [cart, setCart] = useState([]);
  const [customerInfo, setCustomerInfo] = useState({
    name: 'Guest',
    phone: '',
    count: 1
  });
  const [loading, setLoading] = useState(false);
  const [view, setView] = useState('tables'); // 'tables', 'menu', 'cart'

  useEffect(() => {
    fetchInitialData();
  }, [user]);

  const fetchInitialData = async () => {
    if (!user?.access) return;

    try {
      setLoading(true);

      // Use your existing API endpoints
      const [tablesRes, menuRes, categoriesRes] = await Promise.all([
        fetch('/api/tables/tables/', {
          headers: { Authorization: `Bearer ${user.access}` }
        }),
        fetch('/api/menu/items/', {
          headers: { Authorization: `Bearer ${user.access}` }
        }),
        fetch('/api/menu/categories/', {
          headers: { Authorization: `Bearer ${user.access}` }
        })
      ]);

      if (tablesRes.ok) {
        const tablesData = await tablesRes.json();
        setTables(Array.isArray(tablesData) ? tablesData : tablesData.results || []);
      }

      if (menuRes.ok) {
        const menuData = await menuRes.json();
        const items = Array.isArray(menuData) ? menuData : menuData.results || [];
        setMenuItems(items.filter(item => item.available));
      }

      if (categoriesRes.ok) {
        const categoryData = await categoriesRes.json();
        setCategories(Array.isArray(categoryData) ? categoryData : categoryData.results || []);
      }

    } catch (error) {
      console.error('Error fetching data:', error);
      toast.error('Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  const addToCart = (menuItem) => {
    const existingItem = cart.find(item => item.menu_item.id === menuItem.id);
    if (existingItem) {
      setCart(cart.map(item => 
        item.menu_item.id === menuItem.id 
          ? { ...item, quantity: item.quantity + 1 }
          : item
      ));
    } else {
      setCart([...cart, { 
        menu_item: menuItem, 
        quantity: 1, 
        price: parseFloat(menuItem.price),
        special_instructions: ''
      }]);
    }
    toast.success(`${menuItem.name_en} added to cart`);
  };

  const updateQuantity = (menuItemId, quantity) => {
    if (quantity <= 0) {
      setCart(cart.filter(item => item.menu_item.id !== menuItemId));
    } else {
      setCart(cart.map(item => 
        item.menu_item.id === menuItemId ? { ...item, quantity } : item
      ));
    }
  };

  const calculateTotal = () => {
    return cart.reduce((total, item) => total + (item.quantity * item.price), 0);
  };

  const submitOrder = async () => {
    if (!selectedTable || cart.length === 0) {
      toast.error('Please select a table and add items to cart');
      return;
    }

    setLoading(true);
    try {
      // Use your existing order creation API structure
      const orderData = {
        table: selectedTable.id,
        customer_name: customerInfo.name,
        customer_phone: customerInfo.phone,
        customer_count: customerInfo.count,
        items: cart.map(item => ({
          menu_item: item.menu_item.id,
          quantity: item.quantity,
          special_instructions: item.special_instructions || ''
        }))
      };

      const response = await fetch('/api/tables/orders/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${user.access}`
        },
        body: JSON.stringify(orderData)
      });

      if (response.ok) {
        const result = await response.json();
        toast.success(`Order created successfully! Order #${result.order_number || result.id}`);

        // Reset form
        setCart([]);
        setSelectedTable(null);
        setCustomerInfo({ name: 'Guest', phone: '', count: 1 });
        setView('tables');

        // Refresh tables
        fetchInitialData();
      } else {
        const error = await response.json();
        console.error('Order creation error:', error);
        toast.error('Failed to create order: ' + (error.detail || JSON.stringify(error)));
      }
    } catch (error) {
      console.error('Network error:', error);
      toast.error('Network error creating order');
    } finally {
      setLoading(false);
    }
  };

  const filteredMenuItems = selectedCategory 
    ? menuItems.filter(item => item.category?.id === parseInt(selectedCategory))
    : menuItems;

  if (loading && view === 'tables') {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-lg">Loading tables...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Mobile Header */}
      <div className="bg-blue-600 text-white p-4 sticky top-0 z-10">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-xl font-bold">📱 Enhanced Waiter Panel</h1>
            <p className="text-sm opacity-90">
              {selectedTable ? `Table ${selectedTable.table_number}` : 'Select a table'}
            </p>
          </div>
          <div className="text-right">
            <p className="text-sm">{user?.email}</p>
            {cart.length > 0 && (
              <p className="text-sm bg-red-500 rounded-full px-2 py-1 inline-block">
                {cart.length} items
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Navigation Pills */}
      <div className="p-4 bg-white border-b">
        <div className="flex space-x-2 overflow-x-auto">
          <button
            onClick={() => setView('tables')}
            className={`px-4 py-2 rounded-full whitespace-nowrap ${
              view === 'tables' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'
            }`}
          >
            🪑 Tables
          </button>
          <button
            onClick={() => setView('menu')}
            disabled={!selectedTable}
            className={`px-4 py-2 rounded-full whitespace-nowrap ${
              view === 'menu' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'
            } ${!selectedTable ? 'opacity-50' : ''}`}
          >
            🍽️ Menu
          </button>
          <button
            onClick={() => setView('cart')}
            disabled={cart.length === 0}
            className={`px-4 py-2 rounded-full whitespace-nowrap ${
              view === 'cart' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'
            } ${cart.length === 0 ? 'opacity-50' : ''}`}
          >
            🛒 Cart ({cart.length})
          </button>
        </div>
      </div>

      {/* Table Selection View */}
      {view === 'tables' && (
        <div className="p-4">
          <h2 className="text-lg font-semibold mb-4">Select Table</h2>
          <div className="grid grid-cols-3 gap-3">
            {tables.map(table => (
              <button
                key={table.id}
                onClick={() => {
                  setSelectedTable(table);
                  setView('menu');
                }}
                className={`p-4 rounded-lg border-2 text-center transition-colors ${
                  table.is_occupied 
                    ? 'border-red-300 bg-red-50 text-red-700 opacity-50'
                    : 'border-green-300 bg-green-50 text-green-700 hover:bg-green-100'
                }`}
                disabled={table.is_occupied}
              >
                <div className="font-bold text-lg">T{table.table_number}</div>
                <div className="text-sm">
                  {table.is_occupied ? '🔴 Occupied' : '🟢 Available'}
                </div>
                <div className="text-xs mt-1">Cap: {table.capacity}</div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Menu View */}
      {view === 'menu' && selectedTable && (
        <div className="flex flex-col h-full">
          {/* Customer Info */}
          <div className="bg-white p-4 border-b">
            <h3 className="font-semibold mb-2">Customer Information</h3>
            <div className="grid grid-cols-1 gap-2">
              <input
                type="text"
                placeholder="Customer Name"
                value={customerInfo.name}
                onChange={(e) => setCustomerInfo({...customerInfo, name: e.target.value})}
                className="border rounded px-3 py-2"
              />
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="tel"
                  placeholder="Phone"
                  value={customerInfo.phone}
                  onChange={(e) => setCustomerInfo({...customerInfo, phone: e.target.value})}
                  className="border rounded px-3 py-2"
                />
                <input
                  type="number"
                  placeholder="Guests"
                  value={customerInfo.count}
                  onChange={(e) => setCustomerInfo({...customerInfo, count: parseInt(e.target.value)})}
                  className="border rounded px-3 py-2"
                  min="1"
                />
              </div>
            </div>
          </div>

          {/* Category Filter */}
          <div className="bg-white p-3 border-b">
            <div className="flex overflow-x-auto space-x-2">
              <button
                onClick={() => setSelectedCategory('')}
                className={`px-3 py-1 rounded-full text-sm whitespace-nowrap ${
                  selectedCategory === '' ? 'bg-blue-500 text-white' : 'bg-gray-200'
                }`}
              >
                All Items
              </button>
              {categories.map(category => (
                <button
                  key={category.id}
                  onClick={() => setSelectedCategory(category.id.toString())}
                  className={`px-3 py-1 rounded-full text-sm whitespace-nowrap ${
                    selectedCategory === category.id.toString() ? 'bg-blue-500 text-white' : 'bg-gray-200'
                  }`}
                >
                  {language === 'hi' ? category.name_hi : category.name_en}
                </button>
              ))}
            </div>
          </div>

          {/* Menu Items */}
          <div className="flex-1 overflow-y-auto p-4 pb-20">
            <div className="space-y-3">
              {filteredMenuItems.map(item => (
                <div key={item.id} className="bg-white rounded-lg p-3 border shadow-sm">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <h4 className="font-semibold">
                        {language === 'hi' ? item.name_hi : item.name_en}
                      </h4>
                      {item.description_en && (
                        <p className="text-sm text-gray-500 mt-1">
                          {language === 'hi' ? item.description_hi : item.description_en}
                        </p>
                      )}
                      <div className="flex justify-between items-center mt-2">
                        <span className="font-bold text-lg text-green-600">₹{item.price}</span>
                        <span className="text-xs text-gray-500">
                          {item.category?.name_en || 'No category'}
                        </span>
                      </div>
                    </div>
                    <button
                      onClick={() => addToCart(item)}
                      className="bg-blue-500 text-white px-4 py-2 rounded ml-3 hover:bg-blue-600 transition-colors"
                    >
                      Add +
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Cart View */}
      {view === 'cart' && cart.length > 0 && (
        <div className="p-4 pb-24">
          <h2 className="text-lg font-semibold mb-4">Order Summary</h2>
          <div className="space-y-3 mb-6">
            {cart.map(item => (
              <div key={item.menu_item.id} className="bg-white rounded-lg p-3 border">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <h4 className="font-semibold">
                      {language === 'hi' ? item.menu_item.name_hi : item.menu_item.name_en}
                    </h4>
                    <p className="text-sm text-gray-600">₹{item.price} each</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => updateQuantity(item.menu_item.id, item.quantity - 1)}
                      className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center"
                    >
                      -
                    </button>
                    <span className="w-12 text-center font-medium">{item.quantity}</span>
                    <button
                      onClick={() => updateQuantity(item.menu_item.id, item.quantity + 1)}
                      className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center"
                    >
                      +
                    </button>
                  </div>
                </div>
                <div className="flex justify-between items-center mt-2">
                  <input
                    type="text"
                    placeholder="Special instructions..."
                    value={item.special_instructions}
                    onChange={(e) => {
                      setCart(cart.map(cartItem => 
                        cartItem.menu_item.id === item.menu_item.id 
                          ? { ...cartItem, special_instructions: e.target.value }
                          : cartItem
                      ));
                    }}
                    className="text-sm border rounded px-2 py-1 flex-1 mr-2"
                  />
                  <span className="font-bold">₹{(item.quantity * item.price).toFixed(2)}</span>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-white rounded-lg p-4 border">
            <div className="flex justify-between items-center text-lg font-bold border-t pt-3">
              <span>Total Amount:</span>
              <span>₹{calculateTotal().toFixed(2)}</span>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Action Bar */}
      {cart.length > 0 && (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t p-4">
          <div className="flex space-x-3">
            <div className="flex-1">
              <div className="text-sm text-gray-600">
                Table {selectedTable?.table_number} • {cart.length} items
              </div>
              <div className="font-bold text-lg">₹{calculateTotal().toFixed(2)}</div>
            </div>
            <button
              onClick={submitOrder}
              disabled={loading}
              className="bg-green-500 text-white px-6 py-3 rounded-lg font-semibold hover:bg-green-600 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Sending...' : '🍳 Send to Kitchen'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default withRoleGuard(EnhancedWaiterOrders, ['admin', 'staff', 'waiter']);


================================================================================

// ENHANCED BILLING COMPONENT

// pages/admin/enhanced-billing.js - Enhanced billing that extends your existing RestaurantBillingForm
import { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useLanguage } from '@/context/LanguageContext';
import withRoleGuard from '@/hoc/withRoleGuard';
import toast from 'react-hot-toast';

function EnhancedBilling() {
  const { user } = useAuth();
  const { language } = useLanguage();
  const [readyOrders, setReadyOrders] = useState([]);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const [discountPercentage, setDiscountPercentage] = useState(0);
  const [loading, setLoading] = useState(false);
  const [billResult, setBillResult] = useState(null);

  useEffect(() => {
    fetchReadyOrders();
    const interval = setInterval(fetchReadyOrders, 30000);
    return () => clearInterval(interval);
  }, []);

  const fetchReadyOrders = async () => {
    try {
      // Use your existing API structure
      const response = await fetch('/api/tables/orders/?status=completed', {
        headers: { Authorization: `Bearer ${user.access}` }
      });

      if (response.ok) {
        const data = await response.json();
        const orders = Array.isArray(data) ? data : data.results || [];
        // Filter orders that are ready for billing but not yet billed
        const readyForBilling = orders.filter(order => 
          ['completed', 'ready'].includes(order.status) && order.status !== 'billed'
        );
        setReadyOrders(readyForBilling);
      }
    } catch (error) {
      console.error('Error fetching ready orders:', error);
    }
  };

  const generateBillFromOrder = async (order) => {
    setLoading(true);
    try {
      // Use your existing bill creation API
      const billData = {
        customer_name: order.customer_name || 'Guest',
        customer_phone: order.customer_phone || 'N/A',
        items: order.items?.map(item => ({
          item_id: item.menu_item?.id || item.id,
          quantity: item.quantity || 1,
        })) || [],
        apply_gst: true,
        payment_method: paymentMethod,
        discount_percentage: discountPercentage,
        table_number: order.table?.table_number || order.table_number
      };

      const response = await fetch('/api/bills/create/restaurant/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${user.access}`
        },
        body: JSON.stringify(billData)
      });

      if (response.ok) {
        const result = await response.json();

        // Mark order as billed using your existing API
        await fetch(`/api/tables/orders/${order.id}/`, {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${user.access}`
          },
          body: JSON.stringify({ status: 'billed' })
        });

        setBillResult({
          success: true,
          bill_id: result.bill_id,
          receipt_number: result.receipt_number || result.id,
          total_amount: calculateTotalWithGST(order),
          order: order
        });

        toast.success('Bill generated successfully!');
        fetchReadyOrders(); // Refresh the list
      } else {
        const error = await response.json();
        toast.error('Failed to generate bill: ' + (error.detail || JSON.stringify(error)));
      }
    } catch (error) {
      console.error('Error generating bill:', error);
      toast.error('Network error occurred');
    } finally {
      setLoading(false);
    }
  };

  const calculateSubtotal = (order) => {
    if (!order.items) return parseFloat(order.total_amount || 0);
    return order.items.reduce((sum, item) => {
      const price = parseFloat(item.price || item.menu_item?.price || 0);
      return sum + (price * (item.quantity || 1));
    }, 0);
  };

  const calculateTotalWithGST = (order) => {
    const subtotal = calculateSubtotal(order);
    const discountAmount = (subtotal * discountPercentage) / 100;
    const taxableAmount = subtotal - discountAmount;
    const gstAmount = taxableAmount * 0.18; // 18% GST for restaurants
    return taxableAmount + gstAmount;
  };

  const printReceipt = (billData) => {
    const printWindow = window.open('', '_blank');
    const subtotal = calculateSubtotal(billData.order);
    const discountAmount = (subtotal * discountPercentage) / 100;
    const taxableAmount = subtotal - discountAmount;
    const gstAmount = taxableAmount * 0.18;

    printWindow.document.write(`
      <html>
        <head>
          <title>Hotel Receipt</title>
          <style>
            body { font-family: monospace; padding: 20px; max-width: 400px; margin: 0 auto; }
            .header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #000; padding-bottom: 10px; }
            .line-item { display: flex; justify-content: space-between; margin: 5px 0; }
            .total { border-top: 2px solid #000; margin-top: 10px; padding-top: 10px; font-weight: bold; }
            .gst-section { border-top: 1px dashed #000; margin-top: 10px; padding-top: 10px; }
            .footer { text-align: center; margin-top: 20px; font-size: 12px; }
          </style>
        </head>
        <body>
          <div class="header">
            <h2>HOTEL RECEIPT</h2>
            <p>Receipt #: ${billData.receipt_number}</p>
            <p>Table: ${billData.order.table?.table_number || billData.order.table_number}</p>
            <p>Date: ${new Date().toLocaleString()}</p>
            <p>Customer: ${billData.order.customer_name || 'Guest'}</p>
          </div>

          <div class="items">
            ${billData.order.items?.map(item => `
              <div class="line-item">
                <span>${item.menu_item?.name_en || item.name || 'Item'} x ${item.quantity}</span>
                <span>₹${(parseFloat(item.price || item.menu_item?.price || 0) * item.quantity).toFixed(2)}</span>
              </div>
            `).join('') || ''}
          </div>

          <div class="line-item">
            <span>Subtotal:</span>
            <span>₹${subtotal.toFixed(2)}</span>
          </div>

          ${discountAmount > 0 ? `
            <div class="line-item">
              <span>Discount (${discountPercentage}%):</span>
              <span>-₹${discountAmount.toFixed(2)}</span>
            </div>
          ` : ''}

          <div class="line-item">
            <span>Taxable Amount:</span>
            <span>₹${taxableAmount.toFixed(2)}</span>
          </div>

          <div class="gst-section">
            <div class="line-item">
              <span>CGST (9%):</span>
              <span>₹${(gstAmount / 2).toFixed(2)}</span>
            </div>
            <div class="line-item">
              <span>SGST (9%):</span>
              <span>₹${(gstAmount / 2).toFixed(2)}</span>
            </div>
          </div>

          <div class="total">
            <div class="line-item">
              <span>TOTAL:</span>
              <span>₹${billData.total_amount.toFixed(2)}</span>
            </div>
            <div class="line-item">
              <span>Payment Method:</span>
              <span>${paymentMethod.toUpperCase()}</span>
            </div>
          </div>

          <div class="footer">
            <p>Thank you for your visit!</p>
            <p>GST Registration: [Your GST Number]</p>
          </div>
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.print();
  };

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <div className="bg-white rounded-lg shadow-lg">
        <div className="p-6 border-b">
          <h1 className="text-2xl font-bold text-gray-800">
            💳 {language === 'hi' ? 'एक-क्लिक बिलिंग' : 'One-Click Billing'}
          </h1>
          <p className="text-gray-600">
            {language === 'hi' 
              ? 'पूर्ण ऑर्डर के लिए स्वचालित GST गणना के साथ बिल जनरेट करें'
              : 'Generate bills for completed orders with automatic GST calculation'
            }
          </p>
        </div>

        {/* Success Message */}
        {billResult && (
          <div className="p-4 bg-green-50 border-l-4 border-green-400 m-6">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-lg font-medium text-green-800">
                  ✅ {language === 'hi' ? 'बिल सफलतापूर्वक बनाया गया!' : 'Bill Generated Successfully!'}
                </h3>
                <p className="text-green-700">Receipt #{billResult.receipt_number}</p>
                <p className="text-green-700">Amount: ₹{billResult.total_amount.toFixed(2)}</p>
              </div>
              <div className="space-x-2">
                <button
                  onClick={() => printReceipt(billResult)}
                  className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
                >
                  🖨️ {language === 'hi' ? 'प्रिंट रसीद' : 'Print Receipt'}
                </button>
                <button
                  onClick={() => window.open(`/bills/${billResult.bill_id}`, '_blank')}
                  className="px-4 py-2 bg-gray-500 text-white rounded hover:bg-gray-600"
                >
                  👁️ {language === 'hi' ? 'देखें' : 'View'}
                </button>
                <button
                  onClick={() => setBillResult(null)}
                  className="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400"
                >
                  {language === 'hi' ? 'बंद करें' : 'Close'}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Orders Ready for Billing */}
        <div className="p-6">
          <h2 className="text-xl font-semibold mb-4">
            📋 {language === 'hi' ? 'बिलिंग के लिए तैयार ऑर्डर' : 'Orders Ready for Billing'} ({readyOrders.length})
          </h2>

          {readyOrders.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <p className="text-lg">🎉 {language === 'hi' ? 'कोई बिलिंग बाकी नहीं' : 'No orders pending billing'}</p>
              <p className="text-sm">{language === 'hi' ? 'सभी ऑर्डर प्रोसेस हो गए हैं' : 'All orders have been processed'}</p>
            </div>
          ) : (
            <div className="space-y-4">
              {readyOrders.map(order => (
                <div key={order.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center space-x-4 mb-2">
                        <h3 className="font-bold text-lg">
                          🪑 {language === 'hi' ? 'टेबल' : 'Table'} {order.table?.table_number || order.table_number}
                        </h3>
                        <span className="text-sm bg-blue-100 text-blue-800 px-2 py-1 rounded">
                          #{order.order_number || order.id}
                        </span>
                      </div>

                      <div className="grid grid-cols-2 gap-4 text-sm text-gray-600 mb-3">
                        <div>👤 {language === 'hi' ? 'ग्राहक' : 'Customer'}: {order.customer_name || 'Guest'}</div>
                        <div>📱 {language === 'hi' ? 'फोन' : 'Phone'}: {order.customer_phone || 'N/A'}</div>
                        <div>🕒 {language === 'hi' ? 'ऑर्डर समय' : 'Ordered'}: {new Date(order.created_at).toLocaleString()}</div>
                        <div>📦 {language === 'hi' ? 'आइटम' : 'Items'}: {order.items?.length || 0}</div>
                      </div>

                      {/* Order Items */}
                      <div className="bg-gray-50 rounded p-3 mb-3">
                        <h4 className="font-medium mb-2">{language === 'hi' ? 'ऑर्डर आइटम:' : 'Order Items:'}</h4>
                        <div className="space-y-1">
                          {order.items?.map((item, index) => (
                            <div key={index} className="flex justify-between text-sm">
                              <span>
                                {language === 'hi' 
                                  ? (item.menu_item?.name_hi || item.menu_item?.name_en || item.name || 'Item')
                                  : (item.menu_item?.name_en || item.name || 'Item')
                                } x {item.quantity || 1}
                              </span>
                              <span>₹{(parseFloat(item.price || item.menu_item?.price || 0) * (item.quantity || 1)).toFixed(2)}</span>
                            </div>
                          )) || (
                            <div className="text-sm text-gray-500">No items available</div>
                          )}
                        </div>
                        <div className="border-t pt-2 mt-2 font-semibold">
                          <div className="flex justify-between">
                            <span>{language === 'hi' ? 'सबटोटल:' : 'Subtotal:'}</span>
                            <span>₹{calculateSubtotal(order).toFixed(2)}</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Billing Controls */}
                    <div className="ml-6 bg-gray-50 rounded-lg p-4 min-w-[280px]">
                      <h4 className="font-medium mb-3">💰 {language === 'hi' ? 'बिलिंग विकल्प' : 'Billing Options'}</h4>

                      <div className="space-y-3">
                        <div>
                          <label className="block text-sm font-medium mb-1">
                            {language === 'hi' ? 'भुगतान विधि:' : 'Payment Method:'}
                          </label>
                          <select
                            value={paymentMethod}
                            onChange={(e) => setPaymentMethod(e.target.value)}
                            className="w-full border rounded px-2 py-1 text-sm"
                          >
                            <option value="cash">💵 {language === 'hi' ? 'नकद' : 'Cash'}</option>
                            <option value="card">💳 {language === 'hi' ? 'कार्ड' : 'Card'}</option>
                            <option value="upi">📱 UPI</option>
                            <option value="online">🌐 {language === 'hi' ? 'ऑनलाइन' : 'Online'}</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-sm font-medium mb-1">
                            {language === 'hi' ? 'छूट (%):'  : 'Discount (%):'}
                          </label>
                          <input
                            type="number"
                            value={discountPercentage}
                            onChange={(e) => setDiscountPercentage(Number(e.target.value))}
                            className="w-full border rounded px-2 py-1 text-sm"
                            min="0"
                            max="100"
                            step="0.1"
                          />
                        </div>

                        {/* GST Preview */}
                        <div className="bg-white rounded p-2 text-xs">
                          <div className="font-medium mb-1">
                            {language === 'hi' ? 'GST गणना पूर्वावलोकन:' : 'GST Calculation Preview:'}
                          </div>
                          {(() => {
                            const subtotal = calculateSubtotal(order);
                            const discountAmount = (subtotal * discountPercentage) / 100;
                            const taxableAmount = subtotal - discountAmount;
                            const gstAmount = taxableAmount * 0.18;
                            const total = taxableAmount + gstAmount;

                            return (
                              <div className="space-y-1">
                                <div className="flex justify-between">
                                  <span>{language === 'hi' ? 'सबटोटल:' : 'Subtotal:'}</span>
                                  <span>₹{subtotal.toFixed(2)}</span>
                                </div>
                                {discountAmount > 0 && (
                                  <div className="flex justify-between text-red-600">
                                    <span>{language === 'hi' ? 'छूट:' : 'Discount:'}</span>
                                    <span>-₹{discountAmount.toFixed(2)}</span>
                                  </div>
                                )}
                                <div className="flex justify-between">
                                  <span>CGST (9%):</span>
                                  <span>₹{(gstAmount / 2).toFixed(2)}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span>SGST (9%):</span>
                                  <span>₹{(gstAmount / 2).toFixed(2)}</span>
                                </div>
                                <div className="flex justify-between font-semibold border-t pt-1">
                                  <span>{language === 'hi' ? 'कुल:' : 'Total:'}</span>
                                  <span>₹{total.toFixed(2)}</span>
                                </div>
                              </div>
                            );
                          })()}
                        </div>

                        <button
                          onClick={() => generateBillFromOrder(order)}
                          disabled={loading}
                          className="w-full bg-green-500 text-white py-2 rounded font-medium hover:bg-green-600 disabled:opacity-50"
                        >
                          {loading ? (language === 'hi' ? 'बना रहे हैं...' : 'Generating...') : '🧾 ' + (language === 'hi' ? 'बिल बनाएं' : 'Generate Bill')}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default withRoleGuard(EnhancedBilling, ['admin', 'staff']);


================================================================================

// STAFF MANAGEMENT INTEGRATION

// pages/admin/staff-management.js - Staff Management integrated with your existing structure
import { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useLanguage } from '@/context/LanguageContext';
import withRoleGuard from '@/hoc/withRoleGuard';
import toast from 'react-hot-toast';

function StaffManagement() {
  const { user } = useAuth();
  const { language } = useLanguage();
  const [staff, setStaff] = useState([]);
  const [attendanceRecords, setAttendanceRecords] = useState([]);
  const [selectedStaff, setSelectedStaff] = useState(null);
  const [activeTab, setActiveTab] = useState('overview');
  const [currentMonth, setCurrentMonth] = useState(new Date().getMonth() + 1);
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchStaff();
    fetchAttendance();
  }, [currentMonth, currentYear]);

  const fetchStaff = async () => {
    try {
      // Use your existing user API structure
      const response = await fetch('/api/users/staff/', {
        headers: { Authorization: `Bearer ${user.access}` }
      });
      if (response.ok) {
        const data = await response.json();
        setStaff(Array.isArray(data) ? data : data.results || []);
      }
    } catch (error) {
      console.error('Error fetching staff:', error);
      toast.error('Failed to load staff data');
    }
  };

  const fetchAttendance = async () => {
    try {
      // This would need to be implemented in your backend
      const response = await fetch(`/api/staff/attendance/?month=${currentMonth}&year=${currentYear}`, {
        headers: { Authorization: `Bearer ${user.access}` }
      });
      if (response.ok) {
        const data = await response.json();
        setAttendanceRecords(Array.isArray(data) ? data : data.results || []);
      }
    } catch (error) {
      console.error('Error fetching attendance:', error);
      // Don't show error for attendance as this is new functionality
    }
  };

  const markAttendance = async (staffId, status) => {
    setLoading(true);
    try {
      const response = await fetch('/api/staff/attendance/mark/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${user.access}`
        },
        body: JSON.stringify({
          staff_id: staffId,
          status: status,
          date: new Date().toISOString().split('T')[0]
        })
      });

      if (response.ok) {
        fetchAttendance();
        toast.success(`Attendance marked as ${status} successfully!`);
      } else {
        toast.error('Failed to mark attendance');
      }
    } catch (error) {
      console.error('Error marking attendance:', error);
      toast.error('Network error occurred');
    } finally {
      setLoading(false);
    }
  };

  const getAttendanceStatus = (staffId) => {
    const today = new Date().toISOString().split('T')[0];
    const todayAttendance = attendanceRecords.find(
      record => record.staff_id === staffId && record.date === today
    );
    return todayAttendance ? todayAttendance.status : 'not_marked';
  };

  const getMonthlyStats = (staffId) => {
    const staffAttendance = attendanceRecords.filter(record => record.staff_id === staffId);
    const present = staffAttendance.filter(record => record.status === 'present').length;
    const absent = staffAttendance.filter(record => record.status === 'absent').length;
    const totalHours = staffAttendance.reduce((sum, record) => sum + (record.total_hours || 8), 0);
    const overtimeHours = staffAttendance.reduce((sum, record) => sum + (record.overtime_hours || 0), 0);

    return { present, absent, totalHours, overtimeHours };
  };

  const tabs = [
    { id: 'overview', label: language === 'hi' ? 'अवलोकन' : 'Overview' },
    { id: 'attendance', label: language === 'hi' ? 'उपस्थिति' : 'Attendance' },
    { id: 'payroll', label: language === 'hi' ? 'वेतन' : 'Payroll' }
  ];

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="bg-white rounded-lg shadow-lg">
        {/* Header */}
        <div className="p-6 border-b">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-gray-800">
                👥 {language === 'hi' ? 'कर्मचारी प्रबंधन' : 'Staff Management'}
              </h1>
              <p className="text-gray-600">
                {language === 'hi' 
                  ? 'उपस्थिति, वेतन, और कर्मचारी जानकारी प्रबंधित करें'
                  : 'Manage attendance, payroll, and staff information'
                }
              </p>
            </div>
            <div className="flex items-center space-x-4">
              <select
                value={currentMonth}
                onChange={(e) => setCurrentMonth(Number(e.target.value))}
                className="border rounded px-3 py-2"
              >
                {Array.from({length: 12}, (_, i) => (
                  <option key={i + 1} value={i + 1}>
                    {new Date(2024, i).toLocaleString(language === 'hi' ? 'hi-IN' : 'default', { month: 'long' })}
                  </option>
                ))}
              </select>
              <select
                value={currentYear}
                onChange={(e) => setCurrentYear(Number(e.target.value))}
                className="border rounded px-3 py-2"
              >
                {Array.from({length: 5}, (_, i) => (
                  <option key={2022 + i} value={2022 + i}>
                    {2022 + i}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="border-b">
          <nav className="flex space-x-8 px-6">
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-4 px-2 border-b-2 font-medium text-sm ${
                  activeTab === tab.id
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </nav>
        </div>

        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {staff.map(member => {
                const attendanceStatus = getAttendanceStatus(member.id);
                const monthlyStats = getMonthlyStats(member.id);

                return (
                  <div key={member.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <h3 className="font-bold text-lg">{member.email}</h3>
                        <p className="text-sm text-gray-600 capitalize">{member.role}</p>
                        <p className="text-xs text-gray-500">ID: {member.id}</p>
                      </div>
                      <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                        attendanceStatus === 'present' ? 'bg-green-100 text-green-800' :
                        attendanceStatus === 'absent' ? 'bg-red-100 text-red-800' :
                        'bg-gray-100 text-gray-800'
                      }`}>
                        {attendanceStatus === 'not_marked' 
                          ? (language === 'hi' ? 'अंकित नहीं' : 'Not Marked')
                          : attendanceStatus === 'present'
                          ? (language === 'hi' ? 'उपस्थित' : 'Present')
                          : (language === 'hi' ? 'अनुपस्थित' : 'Absent')
                        }
                      </div>
                    </div>

                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>{language === 'hi' ? 'विभाग:' : 'Department:'}</span>
                        <span className="font-medium capitalize">{member.role}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>{language === 'hi' ? 'उपस्थित दिन:' : 'Days Present:'}</span>
                        <span className="font-medium">{monthlyStats.present}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>{language === 'hi' ? 'कुल घंटे:' : 'Total Hours:'}</span>
                        <span className="font-medium">{monthlyStats.totalHours.toFixed(1)}h</span>
                      </div>
                    </div>

                    {/* Quick Actions */}
                    <div className="mt-4 space-y-2">
                      {attendanceStatus === 'not_marked' && (
                        <div className="flex space-x-2">
                          <button
                            onClick={() => markAttendance(member.id, 'present')}
                            disabled={loading}
                            className="flex-1 bg-green-500 text-white py-1 px-2 rounded text-xs hover:bg-green-600 disabled:opacity-50"
                          >
                            ✓ {language === 'hi' ? 'उपस्थित' : 'Present'}
                          </button>
                          <button
                            onClick={() => markAttendance(member.id, 'absent')}
                            disabled={loading}
                            className="flex-1 bg-red-500 text-white py-1 px-2 rounded text-xs hover:bg-red-600 disabled:opacity-50"
                          >
                            ✗ {language === 'hi' ? 'अनुपस्थित' : 'Absent'}
                          </button>
                        </div>
                      )}

                      <button
                        onClick={() => setSelectedStaff(member)}
                        className="w-full bg-blue-500 text-white py-1 px-2 rounded text-xs hover:bg-blue-600"
                      >
                        📊 {language === 'hi' ? 'विवरण देखें' : 'View Details'}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Attendance Tab */}
        {activeTab === 'attendance' && (
          <div className="p-6">
            <div className="overflow-x-auto">
              <table className="min-w-full table-auto">
                <thead>
                  <tr className="bg-gray-50">
                    <th className="px-4 py-2 text-left font-medium text-gray-900">
                      {language === 'hi' ? 'कर्मचारी' : 'Staff'}
                    </th>
                    <th className="px-4 py-2 text-left font-medium text-gray-900">
                      {language === 'hi' ? 'आज की स्थिति' : 'Today Status'}
                    </th>
                    <th className="px-4 py-2 text-left font-medium text-gray-900">
                      {language === 'hi' ? 'इस महीने' : 'This Month'}
                    </th>
                    <th className="px-4 py-2 text-left font-medium text-gray-900">
                      {language === 'hi' ? 'कुल घंटे' : 'Total Hours'}
                    </th>
                    <th className="px-4 py-2 text-left font-medium text-gray-900">
                      {language === 'hi' ? 'कार्य' : 'Actions'}
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {staff.map(member => {
                    const attendanceStatus = getAttendanceStatus(member.id);
                    const monthlyStats = getMonthlyStats(member.id);

                    return (
                      <tr key={member.id} className="border-t">
                        <td className="px-4 py-3">
                          <div>
                            <div className="font-medium">{member.email}</div>
                            <div className="text-sm text-gray-500 capitalize">{member.role}</div>
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            attendanceStatus === 'present' ? 'bg-green-100 text-green-800' :
                            attendanceStatus === 'absent' ? 'bg-red-100 text-red-800' :
                            'bg-gray-100 text-gray-800'
                          }`}>
                            {attendanceStatus === 'not_marked' 
                              ? (language === 'hi' ? 'अंकित नहीं' : 'Not Marked')
                              : attendanceStatus === 'present'
                              ? (language === 'hi' ? 'उपस्थित' : 'Present')
                              : (language === 'hi' ? 'अनुपस्थित' : 'Absent')
                            }
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <div className="text-sm">
                            <div>{language === 'hi' ? 'उपस्थित' : 'Present'}: {monthlyStats.present}</div>
                            <div>{language === 'hi' ? 'अनुपस्थित' : 'Absent'}: {monthlyStats.absent}</div>
                          </div>
                        </td>
                        <td className="px-4 py-3 font-medium">
                          {monthlyStats.totalHours.toFixed(1)}h
                        </td>
                        <td className="px-4 py-3">
                          {attendanceStatus === 'not_marked' && (
                            <div className="flex space-x-1">
                              <button
                                onClick={() => markAttendance(member.id, 'present')}
                                disabled={loading}
                                className="bg-green-500 text-white px-2 py-1 rounded text-xs hover:bg-green-600 disabled:opacity-50"
                              >
                                {language === 'hi' ? 'उपस्थित' : 'Present'}
                              </button>
                              <button
                                onClick={() => markAttendance(member.id, 'absent')}
                                disabled={loading}
                                className="bg-red-500 text-white px-2 py-1 rounded text-xs hover:bg-red-600 disabled:opacity-50"
                              >
                                {language === 'hi' ? 'अनुपस्थित' : 'Absent'}
                              </button>
                            </div>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Payroll Tab */}
        {activeTab === 'payroll' && (
          <div className="p-6">
            <div className="text-center py-8 text-gray-500">
              <p className="text-lg">💰 {language === 'hi' ? 'वेतन प्रबंधन' : 'Payroll Management'}</p>
              <p className="text-sm">{language === 'hi' ? 'जल्द आ रहा है...' : 'Coming soon...'}</p>
              <p className="text-xs mt-2">{language === 'hi' ? 'बैकएंड API कार्यान्वयन की आवश्यकता है' : 'Requires backend API implementation'}</p>
            </div>
          </div>
        )}
      </div>

      {/* Staff Detail Modal */}
      {selectedStaff && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">
                {selectedStaff.email} - {language === 'hi' ? 'विवरण' : 'Details'}
              </h2>
              <button
                onClick={() => setSelectedStaff(null)}
                className="text-gray-500 hover:text-gray-700 text-xl"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    {language === 'hi' ? 'ईमेल' : 'Email'}
                  </label>
                  <div className="mt-1 text-sm">{selectedStaff.email}</div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    {language === 'hi' ? 'भूमिका' : 'Role'}
                  </label>
                  <div className="mt-1 text-sm capitalize">{selectedStaff.role}</div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    {language === 'hi' ? 'स्थिति' : 'Status'}
                  </label>
                  <div className="mt-1 text-sm">
                    {selectedStaff.is_active 
                      ? (language === 'hi' ? 'सक्रिय' : 'Active')
                      : (language === 'hi' ? 'निष्क्रिय' : 'Inactive')
                    }
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    {language === 'hi' ? 'कर्मचारी ID' : 'Employee ID'}
                  </label>
                  <div className="mt-1 text-sm">{selectedStaff.id}</div>
                </div>
              </div>

              {/* Monthly Performance placeholder */}
              <div className="bg-gray-50 rounded p-4">
                <h3 className="font-medium mb-2">
                  {language === 'hi' ? 'मासिक प्रदर्शन' : 'Monthly Performance'}
                </h3>
                <div className="text-sm text-gray-600">
                  {language === 'hi' 
                    ? 'उपस्थिति चार्ट और प्रदर्शन मेट्रिक्स यहाँ प्रदर्शित होंगे'
                    : 'Attendance chart and performance metrics would be displayed here'
                  }
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default withRoleGuard(StaffManagement, ['admin']);


================================================================================

