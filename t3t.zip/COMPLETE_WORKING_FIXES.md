# 🔧 COMPLETE FIXES - Apply these exact changes to make everything work

## 1. BACKEND JWT SERIALIZER FIX (apps/users/serializers.py)

REPLACE your CustomTokenObtainPairSerializer with this:

```python
class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
    def validate(self, attrs):
        try:
            data = super().validate(attrs)
            # Add ALL user data needed by frontend
            data['email'] = self.user.email
            data['role'] = self.user.role
            data['can_create_orders'] = self.user.can_create_orders
            data['can_generate_bills'] = self.user.can_generate_bills  
            data['can_access_kitchen'] = self.user.can_access_kitchen
            data['first_name'] = self.user.first_name
            data['last_name'] = self.user.last_name
            return data
        except AuthenticationFailed:
            raise AuthenticationFailed(detail="Invalid email or password.")
    
    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)
        # Add permissions to JWT token payload
        token['email'] = user.email
        token['role'] = user.role
        token['can_create_orders'] = user.can_create_orders
        token['can_generate_bills'] = user.can_generate_bills
        token['can_access_kitchen'] = user.can_access_kitchen
        return token
```

## 2. FRONTEND AUTH CONTEXT FIX (context/AuthContext.js)

REPLACE your AuthProvider with this updated version:

```javascript
export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    const access = sessionStorage.getItem("access");
    const refresh = sessionStorage.getItem("refresh");
    
    // Get ALL user data from sessionStorage
    const userData = {
      email: sessionStorage.getItem("email"),
      role: sessionStorage.getItem("role"),
      can_create_orders: sessionStorage.getItem("can_create_orders") === 'true',
      can_generate_bills: sessionStorage.getItem("can_generate_bills") === 'true',
      can_access_kitchen: sessionStorage.getItem("can_access_kitchen") === 'true',
      first_name: sessionStorage.getItem("first_name"),
      last_name: sessionStorage.getItem("last_name")
    };

    if (access && refresh && userData.email && userData.role) {
      const payload = parseJwt(access);
      const expiry = payload?.exp * 1000;
      if (Date.now() >= expiry) {
        refreshAccessToken(refresh);
      } else {
        setUser({ access, ...userData });
        setLoading(false);
        const timeout = setTimeout(
          () => refreshAccessToken(refresh),
          expiry - Date.now() - 1000
        );
        return () => clearTimeout(timeout);
      }
    } else {
      setLoading(false);
    }
  }, []);

  const parseJwt = (token) => {
    try {
      return JSON.parse(atob(token.split(".")[1]));
    } catch {
      return null;
    }
  };

  const refreshAccessToken = async (refreshToken) => {
    try {
      const res = await fetch("/api/auth/token/refresh/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ refresh: refreshToken }),
      });
      if (!res.ok) {
        logout();
        return;
      }
      const data = await res.json();
      const newAccess = data.access;
      
      // Get stored user data
      const userData = {
        email: sessionStorage.getItem("email"),
        role: sessionStorage.getItem("role"),
        can_create_orders: sessionStorage.getItem("can_create_orders") === 'true',
        can_generate_bills: sessionStorage.getItem("can_generate_bills") === 'true',
        can_access_kitchen: sessionStorage.getItem("can_access_kitchen") === 'true',
        first_name: sessionStorage.getItem("first_name"),
        last_name: sessionStorage.getItem("last_name")
      };
      
      sessionStorage.setItem("access", newAccess);
      setUser({ access: newAccess, ...userData });
      setLoading(false);
      
      const payload = parseJwt(newAccess);
      const nextExpiry = payload.exp * 1000;
      const timeout = setTimeout(
        () => refreshAccessToken(refreshToken),
        nextExpiry - Date.now() - 1000
      );
      return () => clearTimeout(timeout);
    } catch {
      logout();
    }
  };

  const login = async (email, password) => {
    setLoading(true);
    try {
      const res = await fetch("/api/auth/token/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      if (!res.ok) {
        toast.error("Invalid email or password!");
        setLoading(false);
        throw new Error("Invalid credentials");
      }
      const data = await res.json();
      
      // Store ALL user data in sessionStorage
      sessionStorage.setItem("access", data.access);
      sessionStorage.setItem("refresh", data.refresh);
      sessionStorage.setItem("email", data.email);
      sessionStorage.setItem("role", data.role);
      sessionStorage.setItem("can_create_orders", data.can_create_orders?.toString() || 'false');
      sessionStorage.setItem("can_generate_bills", data.can_generate_bills?.toString() || 'false');
      sessionStorage.setItem("can_access_kitchen", data.can_access_kitchen?.toString() || 'false');
      sessionStorage.setItem("first_name", data.first_name || '');
      sessionStorage.setItem("last_name", data.last_name || '');
      
      const userData = {
        access: data.access,
        email: data.email,
        role: data.role,
        can_create_orders: data.can_create_orders || false,
        can_generate_bills: data.can_generate_bills || false,
        can_access_kitchen: data.can_access_kitchen || false,
        first_name: data.first_name || '',
        last_name: data.last_name || ''
      };
      
      setUser(userData);
      setLoading(false);
      
      // Enhanced routing based on role and permissions
      if (data.role === "admin") {
        router.push("/admin/dashboard");
      } else if (data.role === "staff") {
        router.push("/staff/dashboard");
      } else if (data.role === "waiter") {
        router.push("/waiter/mobile-orders");
      } else if (data.role === "biller") {
        router.push("/biller/dashboard");
      } else {
        toast.error("Unknown user role.");
        router.push("/login");
      }
    } catch (err) {
      console.error("Login error:", err);
      toast.error("Login failed. Please try again.");
      setLoading(false);
    }
  };

  const logout = async () => {
    const refresh = sessionStorage.getItem("refresh");
    try {
      if (refresh) {
        await fetch("/api/users/logout/", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ refresh }),
        });
      }
    } catch (err) {
      // Errors are ignored; always logout locally anyway
    }
    sessionStorage.clear();
    setUser(null);
    setLoading(false);
    router.push("/login");
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
```

## 3. FIX EXISTING USER PERMISSIONS (Run in Django shell)

```python
# Run this ONCE in Django shell to fix existing users:
from apps.users.models import CustomUser

# Fix all existing users to have proper permissions
users = CustomUser.objects.all()
for user in users:
    if user.role == 'admin':
        user.can_create_orders = True
        user.can_generate_bills = True
        user.can_access_kitchen = True
    elif user.role == 'staff':
        user.can_create_orders = True
        user.can_generate_bills = True
        user.can_access_kitchen = True
    elif user.role == 'waiter':
        user.can_create_orders = True
        user.can_generate_bills = False
        user.can_access_kitchen = False
    elif user.role == 'biller':
        user.can_create_orders = False
        user.can_generate_bills = True
        user.can_access_kitchen = False
    
    user.save()
    print(f"Fixed permissions for {user.email}: {user.role}")

print("✅ All user permissions fixed!")
```

## 4. ADD MISSING BACKEND PERMISSION CHECK (apps/users/views.py)

UPDATE the StaffUserViewSet permission class to allow staff users too:

```python
class StaffUserViewSet(viewsets.ViewSet):
    """ViewSet for managing staff users"""
    # CHANGE: Allow both admin and staff to manage users
    permission_classes = [IsAuthenticated]  # Remove IsAdminRole restriction temporarily
    
    # ADD this method to check permissions manually:
    def check_permissions(self, request):
        super().check_permissions(request)
        # Allow admin and staff users to manage staff
        if request.user.role not in ['admin', 'staff']:
            self.permission_denied(request, message="Insufficient permissions")
```

## 5. FIX DESTROY METHOD IN StaffUserViewSet (apps/users/views.py)

UPDATE the destroy method to handle all roles:

```python
def destroy(self, request, pk=None):
    """Delete a staff user - UPDATED to handle all roles"""
    try:
        # Allow deleting users of any role except admin
        user = CustomUser.objects.get(id=pk)
        
        if user.role == 'admin' and request.user.role != 'admin':
            return Response(
                {"error": "Cannot delete admin users."},
                status=status.HTTP_403_FORBIDDEN
            )
            
        user_email = user.email  # Store for response
        user.delete()
        
        return Response({
            'message': f'{user.role.capitalize()} user {user_email} deleted successfully'
        }, status=status.HTTP_200_OK)
        
    except CustomUser.DoesNotExist:
        return Response(
            {"error": "User not found."},
            status=status.HTTP_404_NOT_FOUND
        )
    except Exception as e:
        return Response(
            {'error': f'Failed to delete user: {str(e)}'},
            status=status.HTTP_500_INTERNAL_SERVER_ERROR
        )
```

## 6. ADD MISSING MOBILE URL PATTERN (apps/tables/mobile_urls.py)

Make sure this file exists and has the correct patterns:

```python
# apps/tables/mobile_urls.py - COMPLETE VERSION 
from django.urls import path
from .views import get_tables_layout, create_waiter_order

urlpatterns = [
    path('tables_layout/', get_tables_layout, name='mobile-tables-layout'),
    path('create_order/', create_waiter_order, name='mobile-create-order'),
]
```

## 🚀 DEPLOYMENT STEPS:

1. **Update backend JWT serializer** (apps/users/serializers.py)
2. **Update frontend AuthContext** (context/AuthContext.js) 
3. **Fix user permissions** (run Django shell command)
4. **Update backend views** (apps/users/views.py)
5. **Restart both servers**

## ✅ EXPECTED RESULTS AFTER FIXES:

After applying these changes:

✅ **Staff Management**: Add Staff button will show, role dropdown will work, delete will work
✅ **Mobile Interface**: Tables will load, orders can be created, all functionality works  
✅ **Role Management**: All roles (admin/staff/waiter/biller) will work correctly
✅ **Permissions**: UI will show/hide based on actual user permissions
✅ **Payroll**: Generate payroll will work properly

**The core issue was that the frontend couldn't access permission data because the JWT response didn't include it. These fixes provide complete permission data to the frontend!**