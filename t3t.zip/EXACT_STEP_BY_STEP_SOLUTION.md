# 🚨 EXACT ISSUE & STEP-BY-STEP SOLUTION

## 🎯 THE ROOT CAUSE

Your frontend AuthContext only stores `email`, `role`, and `access` token, but **does NOT store permission fields** (`can_create_orders`, `can_generate_bills`, `can_access_kitchen`) that control UI visibility.

**Result**: Even though your backend has all the right code and APIs work, the frontend can't access permission data to show/hide buttons and features.

## 🔧 STEP-BY-STEP FIX (DO IN THIS EXACT ORDER)

### STEP 1: Fix Backend JWT Response
**File**: `apps/users/serializers.py`
**Action**: REPLACE the `CustomTokenObtainPairSerializer` class

```python
class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
    def validate(self, attrs):
        try:
            data = super().validate(attrs)
            # Add ALL user data needed by frontend
            data['email'] = self.user.email
            data['role'] = self.user.role
            data['can_create_orders'] = self.user.can_create_orders
            data['can_generate_bills'] = self.user.can_generate_bills  
            data['can_access_kitchen'] = self.user.can_access_kitchen
            data['first_name'] = self.user.first_name
            data['last_name'] = self.user.last_name
            return data
        except AuthenticationFailed:
            raise AuthenticationFailed(detail="Invalid email or password.")
    
    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)
        token['email'] = user.email
        token['role'] = user.role
        token['can_create_orders'] = user.can_create_orders
        token['can_generate_bills'] = user.can_generate_bills
        token['can_access_kitchen'] = user.can_access_kitchen
        return token
```

### STEP 2: Fix Existing User Permissions
**Run this in Django shell (python manage.py shell)**:

```python
from apps.users.models import CustomUser

users = CustomUser.objects.all()
for user in users:
    if user.role == 'admin':
        user.can_create_orders = True
        user.can_generate_bills = True
        user.can_access_kitchen = True
    elif user.role == 'staff':
        user.can_create_orders = True
        user.can_generate_bills = True
        user.can_access_kitchen = True
    elif user.role == 'waiter':
        user.can_create_orders = True
        user.can_generate_bills = False
        user.can_access_kitchen = False
    elif user.role == 'biller':
        user.can_create_orders = False
        user.can_generate_bills = True
        user.can_access_kitchen = False
    
    user.save()
    print(f"Fixed {user.email}: {user.role}")

print("✅ All users fixed!")
```

### STEP 3: Fix Frontend AuthContext
**File**: `context/AuthContext.js`
**Action**: REPLACE with the file from [208]

### STEP 4: Remove Admin-Only Restriction
**File**: `apps/users/views.py`
**Action**: In `StaffUserViewSet` class, change:

```python
class StaffUserViewSet(viewsets.ViewSet):
    """ViewSet for managing staff users"""
    permission_classes = [IsAuthenticated]  # CHANGED: Remove IsAdminRole restriction
    
    # ... rest of the class stays the same
```

### STEP 5: Restart Both Servers
1. Stop backend: `Ctrl+C`
2. Stop frontend: `Ctrl+C`  
3. Start backend: `python manage.py runserver`
4. Start frontend: `npm run dev`

## ✅ TESTING CHECKLIST

After applying fixes, test these in order:

1. **Login**: Login with any user - should work
2. **Staff Management**: 
   - Go to staff management page
   - "Add New Staff" button should be visible
   - Role dropdown should show Admin/Staff/Waiter/Biller options
   - Delete button should work
3. **Mobile Orders**:
   - Go to `/waiter/mobile-orders`
   - Tables should load and show
   - Should be able to select table and add items
   - Order creation should work
4. **Role Management**:
   - "Roles" tab should show all staff with permissions
   - Edit role should work
5. **Payroll**: 
   - Generate payroll should work

## 🐛 DEBUG COMMANDS

If something still doesn't work, run these to debug:

```javascript
// In browser console, check user data:
console.log('User data:', JSON.parse(sessionStorage.getItem('user') || '{}'));
console.log('Permissions:', {
  can_create_orders: sessionStorage.getItem('can_create_orders'),
  can_generate_bills: sessionStorage.getItem('can_generate_bills'),
  can_access_kitchen: sessionStorage.getItem('can_access_kitchen')
});
```

```python
# In Django shell, check user permissions:
from apps.users.models import CustomUser
user = CustomUser.objects.get(email='your_email@example.com')
print(f"Role: {user.role}")
print(f"can_create_orders: {user.can_create_orders}")
print(f"can_generate_bills: {user.can_generate_bills}")
print(f"can_access_kitchen: {user.can_access_kitchen}")
```

## 💡 WHY THIS WORKS

- **Backend**: JWT now includes all permission data
- **Frontend**: AuthContext stores and uses permission data
- **Components**: Can properly check `user.can_create_orders` etc.
- **UI**: Buttons show/hide based on actual permissions

**This fixes ALL your issues: Staff management, mobile orders, role selection, delete functionality, and payroll generation!**