# COMPLETE FRONTEND SOLUTION - JavaScript Components (.js format)

## 📱 REACT FRONTEND COMPONENTS (JavaScript Format)

### Enhanced Billing Component - src/pages/Billing/EnhancedBilling.js

```javascript
// src/pages/Billing/EnhancedBilling.js - ENHANCED BILLING DASHBOARD
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const EnhancedBilling = () => {
  const [activeTables, setActiveTables] = useState([]);
  const [selectedTable, setSelectedTable] = useState(null);
  const [currentBill, setCurrentBill] = useState(null);
  const [customItem, setCustomItem] = useState({
    item_name: '',
    quantity: 1,
    price: ''
  });
  const [gstSettings, setGstSettings] = useState({
    apply_gst: true,
    interstate: false
  });
  const [loading, setLoading] = useState(false);

  // Fetch active tables with orders
  useEffect(() => {
    fetchActiveTables();
    const interval = setInterval(fetchActiveTables, 10000); // Refresh every 10 seconds
    return () => clearInterval(interval);
  }, []);

  const fetchActiveTables = async () => {
    try {
      const response = await axios.get('/api/tables/mobile/active-orders/');
      setActiveTables(response.data.active_tables || []);
    } catch (error) {
      console.error('Error fetching active tables:', error);
    }
  };

  const createBillForTable = async (tableId) => {
    setLoading(true);
    try {
      const response = await axios.post('/api/bills/enhanced/create-table-bill/', {
        table_id: tableId,
        customer_name: 'Enhanced Billing Customer'
      });
      
      setCurrentBill(response.data.bill);
      setSelectedTable(tableId);
      alert('Bill created successfully!');
    } catch (error) {
      console.error('Error creating bill:', error);
      alert('Error creating bill: ' + (error.response?.data?.error || 'Unknown error'));
    } finally {
      setLoading(false);
    }
  };

  const addCustomItem = async () => {
    if (!currentBill || !customItem.item_name || !customItem.price) {
      alert('Please fill all required fields');
      return;
    }

    setLoading(true);
    try {
      const response = await axios.post('/api/bills/enhanced/add-item/', {
        bill_id: currentBill.id,
        item_name: customItem.item_name,
        quantity: parseInt(customItem.quantity),
        price: parseFloat(customItem.price)
      });
      
      // Reset form
      setCustomItem({ item_name: '', quantity: 1, price: '' });
      
      // Refresh bill data
      fetchBillDetails(currentBill.id);
      alert('Item added successfully!');
    } catch (error) {
      console.error('Error adding item:', error);
      alert('Error adding item: ' + (error.response?.data?.error || 'Unknown error'));
    } finally {
      setLoading(false);
    }
  };

  const fetchBillDetails = async (billId) => {
    try {
      const response = await axios.get(`/api/bills/${billId}/`);
      setCurrentBill(response.data);
    } catch (error) {
      console.error('Error fetching bill details:', error);
    }
  };

  const applyGST = async () => {
    if (!currentBill) return;

    setLoading(true);
    try {
      const response = await axios.post('/api/bills/enhanced/apply-gst/', {
        bill_id: currentBill.id,
        apply_gst: gstSettings.apply_gst,
        interstate: gstSettings.interstate
      });
      
      setCurrentBill(response.data.bill);
      alert('GST applied successfully!');
    } catch (error) {
      console.error('Error applying GST:', error);
      alert('Error applying GST: ' + (error.response?.data?.error || 'Unknown error'));
    } finally {
      setLoading(false);
    }
  };

  const deleteItem = async (itemId) => {
    if (!window.confirm('Are you sure you want to delete this item?')) {
      return;
    }

    setLoading(true);
    try {
      await axios.delete('/api/bills/enhanced/delete-item/', {
        data: { item_id: itemId }
      });
      
      fetchBillDetails(currentBill.id);
      alert('Item deleted successfully!');
    } catch (error) {
      console.error('Error deleting item:', error);
      alert('Error deleting item: ' + (error.response?.data?.error || 'Unknown error'));
    } finally {
      setLoading(false);
    }
  };

  const finalizeBill = async () => {
    if (!currentBill) return;

    if (!window.confirm('Are you sure you want to finalize this bill?')) {
      return;
    }

    setLoading(true);
    try {
      const response = await axios.post('/api/bills/enhanced/finalize-bill/', {
        bill_id: currentBill.id
      });
      
      alert('Bill finalized and table released!');
      setCurrentBill(null);
      setSelectedTable(null);
      fetchActiveTables(); // Refresh tables list
    } catch (error) {
      console.error('Error finalizing bill:', error);
      alert('Error finalizing bill: ' + (error.response?.data?.error || 'Unknown error'));
    } finally {
      setLoading(false);
    }
  };

  return React.createElement('div', { className: 'container mx-auto p-6' }, [
    // Header
    React.createElement('div', { 
      key: 'header',
      className: 'flex justify-between items-center mb-6' 
    }, [
      React.createElement('div', { key: 'title' }, [
        React.createElement('h1', { 
          key: 'h1',
          className: 'text-3xl font-bold text-gray-900' 
        }, '🧾 Enhanced Billing System'),
        React.createElement('p', { 
          key: 'subtitle',
          className: 'text-gray-600 mt-2' 
        }, 'Dynamic billing with GST calculation and admin controls')
      ]),
      React.createElement('div', { 
        key: 'stats',
        className: 'text-right' 
      }, [
        React.createElement('div', { 
          key: 'count',
          className: 'text-2xl font-bold text-blue-600' 
        }, activeTables.length),
        React.createElement('div', { 
          key: 'label',
          className: 'text-gray-500' 
        }, 'Active Tables')
      ])
    ]),

    // Main Content Grid
    React.createElement('div', { 
      key: 'main',
      className: 'grid grid-cols-1 lg:grid-cols-3 gap-6' 
    }, [
      // Active Tables Section
      React.createElement('div', { 
        key: 'tables-section',
        className: 'lg:col-span-1' 
      }, [
        React.createElement('div', { className: 'bg-white rounded-lg shadow-md p-6' }, [
          React.createElement('h2', { 
            key: 'tables-title',
            className: 'text-xl font-semibold mb-4' 
          }, '📍 Active Tables'),
          
          React.createElement('div', { 
            key: 'tables-list',
            className: 'space-y-4 max-h-96 overflow-y-auto' 
          }, 
            activeTables.map(table => 
              React.createElement('div', {
                key: table.table_id,
                className: `border rounded-lg p-4 cursor-pointer transition-colors ${
                  selectedTable === table.table_id 
                    ? 'border-blue-500 bg-blue-50' 
                    : 'border-gray-200 hover:border-gray-300'
                }`,
                onClick: () => setSelectedTable(table.table_id)
              }, [
                React.createElement('div', { 
                  key: 'table-header',
                  className: 'flex justify-between items-center' 
                }, [
                  React.createElement('div', { key: 'table-info' }, [
                    React.createElement('h3', { 
                      key: 'table-num',
                      className: 'font-medium' 
                    }, `Table ${table.table_number}`),
                    React.createElement('p', { 
                      key: 'table-amount',
                      className: 'text-sm text-gray-500' 
                    }, `${table.orders_count} orders • ₹${table.total_amount}`)
                  ]),
                  table.can_generate_bill && 
                    React.createElement('button', {
                      key: 'create-bill-btn',
                      onClick: (e) => {
                        e.stopPropagation();
                        createBillForTable(table.table_id);
                      },
                      className: 'bg-green-600 text-white px-3 py-1 rounded text-sm hover:bg-green-700',
                      disabled: loading
                    }, 'Create Bill')
                ])
              ])
            )
          )
        ])
      ]),

      // Bill Management Section
      React.createElement('div', { 
        key: 'bill-section',
        className: 'lg:col-span-2' 
      }, [
        currentBill ? 
          // Bill Details
          React.createElement('div', { className: 'space-y-6' }, [
            // Bill Header
            React.createElement('div', { 
              key: 'bill-header',
              className: 'bg-white rounded-lg shadow-md p-6' 
            }, [
              React.createElement('div', { className: 'flex justify-between items-center' }, [
                React.createElement('div', { key: 'bill-info' }, [
                  React.createElement('h2', { 
                    key: 'bill-title',
                    className: 'text-xl font-semibold' 
                  }, `Bill #${currentBill.receipt_number || currentBill.id}`),
                  React.createElement('p', { 
                    key: 'customer-name',
                    className: 'text-gray-600' 
                  }, currentBill.customer_name)
                ]),
                React.createElement('div', { 
                  key: 'bill-amount',
                  className: 'text-right' 
                }, [
                  React.createElement('div', { 
                    key: 'amount',
                    className: 'text-2xl font-bold text-green-600' 
                  }, `₹${currentBill.total_amount}`),
                  React.createElement('div', { 
                    key: 'payment-method',
                    className: 'text-sm text-gray-500' 
                  }, `Payment: ${currentBill.payment_method}`)
                ])
              ])
            ]),

            // Add Custom Item
            React.createElement('div', { 
              key: 'add-item',
              className: 'bg-white rounded-lg shadow-md p-6' 
            }, [
              React.createElement('h3', { 
                key: 'add-item-title',
                className: 'text-lg font-medium mb-4' 
              }, '➕ Add Custom Item'),
              
              React.createElement('div', { 
                key: 'add-item-form',
                className: 'grid grid-cols-1 md:grid-cols-4 gap-4' 
              }, [
                React.createElement('input', {
                  key: 'item-name',
                  type: 'text',
                  placeholder: 'Item Name',
                  value: customItem.item_name,
                  onChange: (e) => setCustomItem({ ...customItem, item_name: e.target.value }),
                  className: 'border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500'
                }),
                React.createElement('input', {
                  key: 'quantity',
                  type: 'number',
                  placeholder: 'Quantity',
                  value: customItem.quantity,
                  onChange: (e) => setCustomItem({ ...customItem, quantity: e.target.value }),
                  className: 'border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500',
                  min: 1
                }),
                React.createElement('input', {
                  key: 'price',
                  type: 'number',
                  step: '0.01',
                  placeholder: 'Unit Price',
                  value: customItem.price,
                  onChange: (e) => setCustomItem({ ...customItem, price: e.target.value }),
                  className: 'border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500',
                  min: 0
                }),
                React.createElement('button', {
                  key: 'add-btn',
                  onClick: addCustomItem,
                  disabled: loading,
                  className: 'bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 disabled:opacity-50'
                }, loading ? 'Adding...' : '➕ Add Item')
              ])
            ]),

            // GST Settings
            React.createElement('div', { 
              key: 'gst-section',
              className: 'bg-white rounded-lg shadow-md p-6' 
            }, [
              React.createElement('h3', { 
                key: 'gst-title',
                className: 'text-lg font-medium mb-4' 
              }, '💰 GST Settings'),
              
              React.createElement('div', { 
                key: 'gst-controls',
                className: 'grid grid-cols-1 md:grid-cols-3 gap-4' 
              }, [
                React.createElement('label', { 
                  key: 'apply-gst-label',
                  className: 'flex items-center' 
                }, [
                  React.createElement('input', {
                    key: 'apply-gst-checkbox',
                    type: 'checkbox',
                    checked: gstSettings.apply_gst,
                    onChange: (e) => setGstSettings({ ...gstSettings, apply_gst: e.target.checked }),
                    className: 'mr-2'
                  }),
                  'Apply GST (18%)'
                ]),
                
                React.createElement('label', { 
                  key: 'interstate-label',
                  className: 'flex items-center' 
                }, [
                  React.createElement('input', {
                    key: 'interstate-checkbox',
                    type: 'checkbox',
                    checked: gstSettings.interstate,
                    onChange: (e) => setGstSettings({ ...gstSettings, interstate: e.target.checked }),
                    disabled: !gstSettings.apply_gst,
                    className: 'mr-2'
                  }),
                  'Interstate Transaction'
                ]),
                
                React.createElement('button', {
                  key: 'apply-gst-btn',
                  onClick: applyGST,
                  disabled: loading,
                  className: 'bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700 disabled:opacity-50'
                }, loading ? 'Applying...' : 'Apply GST')
              ])
            ]),

            // Action Buttons
            React.createElement('div', { 
              key: 'actions',
              className: 'bg-white rounded-lg shadow-md p-6' 
            }, [
              React.createElement('div', { className: 'flex space-x-4' }, [
                React.createElement('button', {
                  key: 'print-btn',
                  onClick: () => window.print(),
                  className: 'bg-gray-600 text-white px-6 py-2 rounded-md hover:bg-gray-700'
                }, '🖨️ Print Bill'),
                
                React.createElement('button', {
                  key: 'finalize-btn',
                  onClick: finalizeBill,
                  disabled: loading,
                  className: 'bg-purple-600 text-white px-6 py-2 rounded-md hover:bg-purple-700 disabled:opacity-50'
                }, loading ? 'Finalizing...' : '✅ Finalize & Release Table')
              ])
            ])
          ])
        :
          // No Bill Selected
          React.createElement('div', { 
            key: 'no-bill',
            className: 'bg-white rounded-lg shadow-md p-12 text-center' 
          }, [
            React.createElement('div', { 
              key: 'no-bill-icon',
              className: 'text-6xl mb-4' 
            }, '📋'),
            React.createElement('h3', { 
              key: 'no-bill-title',
              className: 'text-xl font-medium text-gray-900 mb-2' 
            }, 'Select a Table'),
            React.createElement('p', { 
              key: 'no-bill-desc',
              className: 'text-gray-500' 
            }, 'Choose a table from the left panel to create or manage a bill')
          ])
      ])
    ])
  ]);
};

export default EnhancedBilling;
```

### Mobile Ordering Component - src/pages/Mobile/MobileOrdering.js

```javascript
// src/pages/Mobile/MobileOrdering.js - MOBILE ORDERING INTERFACE
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const MobileOrdering = () => {
  const [tables, setTables] = useState([]);
  const [menuData, setMenuData] = useState([]);
  const [selectedTable, setSelectedTable] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState(0);
  const [cart, setCart] = useState([]);
  const [customerInfo, setCustomerInfo] = useState({
    customer_name: '',
    customer_phone: '',
    special_instructions: ''
  });
  const [loading, setLoading] = useState(false);

  // Fetch data on component mount
  useEffect(() => {
    fetchTables();
    fetchMenu();
  }, []);

  const fetchTables = async () => {
    try {
      const response = await axios.get('/api/tables/mobile/available-tables/');
      setTables(response.data);
    } catch (error) {
      console.error('Error fetching tables:', error);
    }
  };

  const fetchMenu = async () => {
    try {
      const response = await axios.get('/api/tables/mobile/menu/');
      setMenuData(response.data);
    } catch (error) {
      console.error('Error fetching menu:', error);
    }
  };

  const addToCart = (item) => {
    const existingItem = cart.find(cartItem => cartItem.id === item.id);
    
    if (existingItem) {
      setCart(cart.map(cartItem =>
        cartItem.id === item.id
          ? { ...cartItem, quantity: cartItem.quantity + 1 }
          : cartItem
      ));
    } else {
      setCart([...cart, { ...item, quantity: 1 }]);
    }
  };

  const updateCartQuantity = (itemId, quantity) => {
    if (quantity <= 0) {
      setCart(cart.filter(item => item.id !== itemId));
    } else {
      setCart(cart.map(item =>
        item.id === itemId ? { ...item, quantity } : item
      ));
    }
  };

  const calculateTotal = () => {
    return cart.reduce((total, item) => total + (item.price * item.quantity), 0);
  };

  const submitOrder = async () => {
    if (!selectedTable || cart.length === 0) {
      alert('Please select a table and add items to cart');
      return;
    }

    setLoading(true);
    try {
      const orderData = {
        table_id: selectedTable.id,
        customer_name: customerInfo.customer_name || 'Walk-in Customer',
        customer_phone: customerInfo.customer_phone,
        special_instructions: customerInfo.special_instructions,
        items: cart.map(item => ({
          item_id: item.id,
          quantity: item.quantity
        }))
      };

      const response = await axios.post('/api/tables/mobile/create-order/', orderData);
      
      alert(`Order created successfully for Table ${selectedTable.table_number}!`);
      
      // Reset form
      setCart([]);
      setCustomerInfo({ customer_name: '', customer_phone: '', special_instructions: '' });
      setSelectedTable(null);
      
    } catch (error) {
      console.error('Error submitting order:', error);
      alert('Error submitting order: ' + (error.response?.data?.error || 'Unknown error'));
    } finally {
      setLoading(false);
    }
  };

  return React.createElement('div', { className: 'min-h-screen bg-gray-50' }, [
    // Header
    React.createElement('div', { 
      key: 'header',
      className: 'bg-white shadow-sm border-b' 
    }, [
      React.createElement('div', { 
        key: 'header-content',
        className: 'container mx-auto px-4 py-4' 
      }, [
        React.createElement('h1', { 
          key: 'title',
          className: 'text-2xl font-bold text-gray-900' 
        }, '📱 Mobile Ordering System'),
        selectedTable &&
          React.createElement('p', { 
            key: 'selected-table',
            className: 'text-blue-600 mt-1' 
          }, `Selected: Table ${selectedTable.table_number} (Capacity: ${selectedTable.capacity})`)
      ])
    ]),

    // Main Content
    React.createElement('div', { 
      key: 'main',
      className: 'container mx-auto px-4 py-6' 
    }, [
      React.createElement('div', { className: 'grid grid-cols-1 lg:grid-cols-4 gap-6' }, [
        
        // Table Selection
        React.createElement('div', { 
          key: 'table-selection',
          className: 'lg:col-span-1' 
        }, [
          React.createElement('div', { className: 'bg-white rounded-lg shadow-md p-6 mb-6' }, [
            React.createElement('h2', { 
              key: 'table-title',
              className: 'text-lg font-semibold mb-4' 
            }, '🪑 Select Table'),
            
            React.createElement('div', { 
              key: 'tables-grid',
              className: 'grid grid-cols-2 gap-3' 
            }, 
              tables.map(table =>
                React.createElement('button', {
                  key: table.id,
                  onClick: () => setSelectedTable(table),
                  className: `p-3 border rounded-lg text-center transition-colors ${
                    selectedTable?.id === table.id
                      ? 'border-blue-500 bg-blue-50 text-blue-700'
                      : table.status === 'occupied'
                      ? 'border-red-300 bg-red-50 text-red-700'
                      : 'border-gray-300 hover:border-gray-400'
                  }`,
                  disabled: table.status === 'occupied'
                }, [
                  React.createElement('div', { 
                    key: 'table-num',
                    className: 'font-medium' 
                  }, `T${table.table_number}`),
                  React.createElement('div', { 
                    key: 'table-status',
                    className: 'text-xs' 
                  }, table.status === 'occupied' ? 'Occupied' : `Cap: ${table.capacity}`)
                ])
              )
            )
          ]),

          // Customer Info
          React.createElement('div', { className: 'bg-white rounded-lg shadow-md p-6' }, [
            React.createElement('h3', { 
              key: 'customer-title',
              className: 'text-lg font-semibold mb-4' 
            }, '👤 Customer Info'),
            
            React.createElement('div', { 
              key: 'customer-form',
              className: 'space-y-3' 
            }, [
              React.createElement('input', {
                key: 'customer-name',
                type: 'text',
                placeholder: 'Customer Name',
                value: customerInfo.customer_name,
                onChange: (e) => setCustomerInfo({ ...customerInfo, customer_name: e.target.value }),
                className: 'w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500'
              }),
              React.createElement('input', {
                key: 'customer-phone',
                type: 'tel',
                placeholder: 'Phone Number',
                value: customerInfo.customer_phone,
                onChange: (e) => setCustomerInfo({ ...customerInfo, customer_phone: e.target.value }),
                className: 'w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500'
              }),
              React.createElement('textarea', {
                key: 'special-instructions',
                placeholder: 'Special Instructions',
                value: customerInfo.special_instructions,
                onChange: (e) => setCustomerInfo({ ...customerInfo, special_instructions: e.target.value }),
                className: 'w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500',
                rows: 3
              })
            ])
          ])
        ]),

        // Menu Categories & Items
        React.createElement('div', { 
          key: 'menu-section',
          className: 'lg:col-span-2' 
        }, [
          React.createElement('div', { className: 'bg-white rounded-lg shadow-md p-6' }, [
            React.createElement('h2', { 
              key: 'menu-title',
              className: 'text-lg font-semibold mb-4' 
            }, '🍽️ Menu'),

            // Category Tabs
            menuData.length > 0 && React.createElement('div', { 
              key: 'category-tabs',
              className: 'flex flex-wrap gap-2 mb-6' 
            }, 
              menuData.map((category, index) =>
                React.createElement('button', {
                  key: index,
                  onClick: () => setSelectedCategory(index),
                  className: `px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                    selectedCategory === index
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                  }`
                }, category.category.name_en)
              )
            ),

            // Menu Items
            menuData[selectedCategory] && React.createElement('div', { 
              key: 'menu-items',
              className: 'grid grid-cols-1 md:grid-cols-2 gap-4 max-h-96 overflow-y-auto' 
            }, 
              menuData[selectedCategory].items.map(item =>
                React.createElement('div', {
                  key: item.id,
                  className: 'border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow'
                }, [
                  React.createElement('div', { 
                    key: 'item-info',
                    className: 'flex justify-between items-start mb-2' 
                  }, [
                    React.createElement('div', { key: 'item-details' }, [
                      React.createElement('h4', { 
                        key: 'item-name',
                        className: 'font-medium' 
                      }, item.name_en),
                      item.description_en && React.createElement('p', { 
                        key: 'item-desc',
                        className: 'text-sm text-gray-600' 
                      }, item.description_en),
                      React.createElement('p', { 
                        key: 'item-price',
                        className: 'text-lg font-semibold text-green-600' 
                      }, `₹${item.price}`)
                    ])
                  ]),
                  
                  React.createElement('button', {
                    key: 'add-to-cart',
                    onClick: () => addToCart(item),
                    disabled: !item.available,
                    className: `w-full py-2 px-4 rounded-md text-white font-medium ${
                      item.available
                        ? 'bg-blue-600 hover:bg-blue-700'
                        : 'bg-gray-400 cursor-not-allowed'
                    }`
                  }, item.available ? '➕ Add to Cart' : 'Not Available')
                ])
              )
            )
          ])
        ]),

        // Cart & Order Summary
        React.createElement('div', { 
          key: 'cart-section',
          className: 'lg:col-span-1' 
        }, [
          React.createElement('div', { className: 'bg-white rounded-lg shadow-md p-6 sticky top-6' }, [
            React.createElement('h2', { 
              key: 'cart-title',
              className: 'text-lg font-semibold mb-4' 
            }, `🛒 Cart (${cart.length})`),

            React.createElement('div', { 
              key: 'cart-items',
              className: 'space-y-3 mb-6 max-h-64 overflow-y-auto' 
            }, 
              cart.length > 0 ?
                cart.map(item =>
                  React.createElement('div', {
                    key: item.id,
                    className: 'flex justify-between items-center border-b border-gray-100 pb-3'
                  }, [
                    React.createElement('div', { key: 'cart-item-info' }, [
                      React.createElement('h5', { 
                        key: 'cart-item-name',
                        className: 'font-medium' 
                      }, item.name_en),
                      React.createElement('p', { 
                        key: 'cart-item-price',
                        className: 'text-sm text-gray-600' 
                      }, `₹${item.price} each`)
                    ]),
                    
                    React.createElement('div', { 
                      key: 'cart-item-controls',
                      className: 'flex items-center space-x-2' 
                    }, [
                      React.createElement('button', {
                        key: 'decrease',
                        onClick: () => updateCartQuantity(item.id, item.quantity - 1),
                        className: 'w-6 h-6 bg-red-500 text-white rounded-full text-sm hover:bg-red-600'
                      }, '−'),
                      
                      React.createElement('span', { 
                        key: 'quantity',
                        className: 'font-medium' 
                      }, item.quantity),
                      
                      React.createElement('button', {
                        key: 'increase',
                        onClick: () => updateCartQuantity(item.id, item.quantity + 1),
                        className: 'w-6 h-6 bg-green-500 text-white rounded-full text-sm hover:bg-green-600'
                      }, '+')
                    ])
                  ])
                ) :
                React.createElement('p', { 
                  key: 'empty-cart',
                  className: 'text-gray-500 text-center py-8' 
                }, 'Cart is empty')
            ),

            // Total
            cart.length > 0 && React.createElement('div', { 
              key: 'cart-total',
              className: 'border-t border-gray-200 pt-4 mb-6' 
            }, [
              React.createElement('div', { className: 'flex justify-between items-center text-xl font-bold' }, [
                React.createElement('span', { key: 'total-label' }, 'Total:'),
                React.createElement('span', { 
                  key: 'total-amount',
                  className: 'text-green-600' 
                }, `₹${calculateTotal().toFixed(2)}`)
              ])
            ]),

            // Submit Order Button
            React.createElement('button', {
              key: 'submit-order',
              onClick: submitOrder,
              disabled: loading || !selectedTable || cart.length === 0,
              className: 'w-full py-3 px-4 bg-green-600 text-white font-semibold rounded-md hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed'
            }, loading ? '🔄 Submitting...' : '📤 Submit Order')
          ])
        ])
      ])
    ])
  ]);
};

export default MobileOrdering;
```

### Kitchen Display Component - src/pages/Kitchen/KitchenDisplay.js

```javascript
// src/pages/Kitchen/KitchenDisplay.js - KITCHEN DISPLAY WITH AUDIO
import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';

const KitchenDisplay = () => {
  const [orders, setOrders] = useState([]);
  const [stats, setStats] = useState({});
  const [audioEnabled, setAudioEnabled] = useState(true);
  const [loading, setLoading] = useState(false);
  const audioRef = useRef(null);

  // Fetch kitchen orders
  useEffect(() => {
    fetchActiveOrders();
    fetchKitchenStats();
    
    const ordersInterval = setInterval(fetchActiveOrders, 5000); // Refresh every 5 seconds
    const statsInterval = setInterval(fetchKitchenStats, 30000); // Refresh every 30 seconds
    
    return () => {
      clearInterval(ordersInterval);
      clearInterval(statsInterval);
    };
  }, []);

  const fetchActiveOrders = async () => {
    try {
      const response = await axios.get('/api/kitchen/orders/active_orders/');
      const newOrders = response.data;
      
      // Check for new orders and play audio
      if (audioEnabled && orders.length > 0 && newOrders.length > orders.length) {
        playNewOrderAlert();
      }
      
      setOrders(newOrders);
    } catch (error) {
      console.error('Error fetching kitchen orders:', error);
    }
  };

  const fetchKitchenStats = async () => {
    try {
      const response = await axios.get('/api/kitchen/orders/kitchen_stats/');
      setStats(response.data);
    } catch (error) {
      console.error('Error fetching kitchen stats:', error);
    }
  };

  const playNewOrderAlert = () => {
    if (audioRef.current) {
      audioRef.current.play().catch(console.error);
    } else {
      // Fallback: create audio dynamically
      const audio = new Audio('/sounds/kitchen-alert.mp3');
      audio.volume = 0.7;
      audio.play().catch(console.error);
    }
  };

  const updateOrderStatus = async (orderId, newStatus, chefName = '') => {
    setLoading(true);
    try {
      await axios.post(`/api/kitchen/orders/${orderId}/update_order_status/`, {
        status: newStatus,
        chef_name: chefName
      });
      
      // Refresh orders
      await fetchActiveOrders();
      
    } catch (error) {
      console.error('Error updating order status:', error);
      alert('Error updating order status');
    } finally {
      setLoading(false);
    }
  };

  const acknowledgeAudio = async (orderId) => {
    try {
      await axios.post(`/api/kitchen/orders/${orderId}/acknowledge_audio/`);
      await fetchActiveOrders();
    } catch (error) {
      console.error('Error acknowledging audio:', error);
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      'received': 'bg-blue-100 text-blue-800 border-blue-200',
      'preparing': 'bg-yellow-100 text-yellow-800 border-yellow-200',
      'ready': 'bg-green-100 text-green-800 border-green-200',
      'cancelled': 'bg-red-100 text-red-800 border-red-200'
    };
    return colors[status] || colors['received'];
  };

  const getPriorityColor = (priority) => {
    const colors = {
      1: 'border-l-green-500',
      2: 'border-l-blue-500',
      3: 'border-l-yellow-500',
      4: 'border-l-red-500'
    };
    return colors[priority] || colors[2];
  };

  return React.createElement('div', { className: 'min-h-screen bg-gray-900 text-white' }, [
    // Audio element
    React.createElement('audio', {
      key: 'audio',
      ref: audioRef,
      preload: 'auto'
    }, [
      React.createElement('source', { 
        key: 'audio-source',
        src: '/sounds/kitchen-alert.mp3',
        type: 'audio/mpeg' 
      })
    ]),

    // Header
    React.createElement('div', { 
      key: 'header',
      className: 'bg-gray-800 p-6 shadow-lg' 
    }, [
      React.createElement('div', { className: 'flex justify-between items-center' }, [
        React.createElement('div', { key: 'title-section' }, [
          React.createElement('h1', { 
            key: 'title',
            className: 'text-3xl font-bold' 
          }, '🍳 Kitchen Display System'),
          React.createElement('p', { 
            key: 'subtitle',
            className: 'text-gray-300 mt-2' 
          }, 'Real-time order management with audio alerts')
        ]),
        
        React.createElement('div', { 
          key: 'controls',
          className: 'flex items-center space-x-6' 
        }, [
          React.createElement('div', { 
            key: 'order-count',
            className: 'text-center' 
          }, [
            React.createElement('div', { 
              key: 'count',
              className: 'text-2xl font-bold text-green-400' 
            }, orders.length),
            React.createElement('div', { 
              key: 'label',
              className: 'text-sm text-gray-300' 
            }, 'Active Orders')
          ]),
          
          React.createElement('button', {
            key: 'audio-toggle',
            onClick: () => setAudioEnabled(!audioEnabled),
            className: `px-4 py-2 rounded-lg font-medium ${
              audioEnabled
                ? 'bg-green-600 hover:bg-green-700'
                : 'bg-gray-600 hover:bg-gray-700'
            }`
          }, audioEnabled ? '🔊 Audio ON' : '🔇 Audio OFF'),
          
          React.createElement('div', { 
            key: 'time',
            className: 'text-sm text-gray-300' 
          }, new Date().toLocaleTimeString())
        ])
      ])
    ]),

    // Kitchen Stats
    React.createElement('div', { 
      key: 'stats',
      className: 'bg-gray-800 px-6 py-4' 
    }, [
      React.createElement('div', { className: 'grid grid-cols-2 md:grid-cols-4 gap-6' }, [
        React.createElement('div', { 
          key: 'total-orders',
          className: 'text-center' 
        }, [
          React.createElement('div', { 
            key: 'total-count',
            className: 'text-2xl font-bold text-blue-400' 
          }, stats.total_orders || 0),
          React.createElement('div', { 
            key: 'total-label',
            className: 'text-sm text-gray-400' 
          }, 'Total Today')
        ]),
        
        React.createElement('div', { 
          key: 'completed',
          className: 'text-center' 
        }, [
          React.createElement('div', { 
            key: 'completed-count',
            className: 'text-2xl font-bold text-green-400' 
          }, stats.completed || 0),
          React.createElement('div', { 
            key: 'completed-label',
            className: 'text-sm text-gray-400' 
          }, 'Completed')
        ]),
        
        React.createElement('div', { 
          key: 'preparing-orders',
          className: 'text-center' 
        }, [
          React.createElement('div', { 
            key: 'preparing-count',
            className: 'text-2xl font-bold text-yellow-400' 
          }, stats.preparing || 0),
          React.createElement('div', { 
            key: 'preparing-label',
            className: 'text-sm text-gray-400' 
          }, 'Preparing')
        ]),
        
        React.createElement('div', { 
          key: 'avg-time',
          className: 'text-center' 
        }, [
          React.createElement('div', { 
            key: 'avg-count',
            className: 'text-2xl font-bold text-purple-400' 
          }, `${stats.average_prep_time || 0}m`),
          React.createElement('div', { 
            key: 'avg-label',
            className: 'text-sm text-gray-400' 
          }, 'Avg Prep Time')
        ])
      ])
    ]),

    // Orders Grid
    React.createElement('div', { 
      key: 'orders-grid',
      className: 'p-6' 
    }, [
      orders.length > 0 ?
        React.createElement('div', { className: 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6' }, 
          orders.map(order =>
            React.createElement('div', {
              key: order.id,
              className: `bg-white text-gray-900 rounded-lg shadow-lg p-4 border-l-4 ${getPriorityColor(order.priority)} ${
                !order.audio_acknowledged ? 'animate-pulse ring-2 ring-red-500' : ''
              }`
            }, [
              // Order Header
              React.createElement('div', { 
                key: 'order-header',
                className: 'flex justify-between items-center mb-3' 
              }, [
                React.createElement('div', { key: 'order-info' }, [
                  React.createElement('h3', { 
                    key: 'receipt-num',
                    className: 'font-bold text-lg' 
                  }, `#${order.bill_receipt}`),
                  React.createElement('p', { 
                    key: 'table-info',
                    className: 'text-gray-600' 
                  }, order.table_number !== 'Takeaway' ? `Table ${order.table_number}` : 'Takeaway')
                ]),
                
                React.createElement('div', { 
                  key: 'order-status',
                  className: 'text-right' 
                }, [
                  React.createElement('span', { 
                    key: 'status-badge',
                    className: `inline-flex px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(order.status)}`
                  }, order.status_display),
                  React.createElement('div', { 
                    key: 'time-elapsed',
                    className: 'text-sm text-gray-500 mt-1' 
                  }, `⏱️ ${order.time_elapsed}m ago`)
                ])
              ]),

              // Order Items
              React.createElement('div', { 
                key: 'order-items',
                className: 'mb-4' 
              }, [
                React.createElement('h4', { 
                  key: 'items-title',
                  className: 'font-medium text-gray-900 mb-2' 
                }, 'Items:'),
                React.createElement('div', { 
                  key: 'items-list',
                  className: 'space-y-1 max-h-32 overflow-y-auto' 
                }, 
                  order.items?.map((item, index) =>
                    React.createElement('div', {
                      key: index,
                      className: 'bg-gray-50 p-2 rounded text-sm flex justify-between'
                    }, [
                      React.createElement('span', { 
                        key: 'item-name',
                        className: 'font-medium' 
                      }, item.name),
                      React.createElement('span', { 
                        key: 'item-qty',
                        className: 'text-gray-600' 
                      }, `×${item.quantity}`)
                    ])
                  )
                )
              ]),

              // Special Instructions
              order.special_instructions && React.createElement('div', { 
                key: 'special-instructions',
                className: 'mb-4 p-2 bg-yellow-50 border-l-4 border-yellow-400' 
              }, [
                React.createElement('p', { 
                  key: 'instructions-text',
                  className: 'text-sm text-yellow-800' 
                }, [
                  React.createElement('strong', { key: 'instructions-label' }, 'Special: '),
                  order.special_instructions
                ])
              ]),

              // Action Buttons
              React.createElement('div', { 
                key: 'action-buttons',
                className: 'flex flex-col space-y-2' 
              }, [
                // Status-based buttons
                order.status === 'received' && React.createElement('button', {
                  key: 'start-cooking',
                  onClick: () => updateOrderStatus(order.id, 'preparing', 'Chef'),
                  disabled: loading,
                  className: 'w-full bg-blue-600 text-white py-2 px-3 rounded text-sm font-medium hover:bg-blue-700 disabled:opacity-50'
                }, '👨‍🍳 Start Cooking'),
                
                order.status === 'preparing' && React.createElement('button', {
                  key: 'mark-ready',
                  onClick: () => updateOrderStatus(order.id, 'ready'),
                  disabled: loading,
                  className: 'w-full bg-green-600 text-white py-2 px-3 rounded text-sm font-medium hover:bg-green-700 disabled:opacity-50'
                }, '✅ Ready to Serve'),
                
                order.status === 'ready' && React.createElement('button', {
                  key: 'mark-served',
                  onClick: () => updateOrderStatus(order.id, 'served'),
                  disabled: loading,
                  className: 'w-full bg-purple-600 text-white py-2 px-3 rounded text-sm font-medium hover:bg-purple-700 disabled:opacity-50'
                }, '🍽️ Mark Served'),

                // Audio acknowledgment button
                !order.audio_acknowledged && React.createElement('button', {
                  key: 'ack-audio',
                  onClick: () => acknowledgeAudio(order.id),
                  className: 'w-full bg-red-600 text-white py-1 px-3 rounded text-xs font-medium hover:bg-red-700'
                }, '🔕 Acknowledge Alert'),

                // Cancel button
                React.createElement('button', {
                  key: 'cancel-order',
                  onClick: () => {
                    if (window.confirm('Are you sure you want to cancel this order?')) {
                      updateOrderStatus(order.id, 'cancelled');
                    }
                  },
                  disabled: loading,
                  className: 'w-full bg-gray-600 text-white py-1 px-3 rounded text-xs font-medium hover:bg-gray-700 disabled:opacity-50'
                }, '❌ Cancel')
              ]),

              // Estimated Time
              React.createElement('div', { 
                key: 'estimated-time',
                className: 'mt-3 text-center text-xs text-gray-500 border-t pt-2' 
              }, `Est. Time: ${order.estimated_time}min`)
            ])
          )
        )
      :
        React.createElement('div', { 
          key: 'no-orders',
          className: 'text-center py-12' 
        }, [
          React.createElement('div', { 
            key: 'no-orders-icon',
            className: 'text-6xl mb-4' 
          }, '🍽️'),
          React.createElement('h3', { 
            key: 'no-orders-title',
            className: 'text-xl font-medium mb-2' 
          }, 'No Active Orders'),
          React.createElement('p', { 
            key: 'no-orders-desc',
            className: 'text-gray-400' 
          }, 'Orders will appear here when placed')
        ])
    ])
  ]);
};

export default KitchenDisplay;
```

## 🔧 IMMEDIATE SETUP STEPS

### 1. Fix Backend Errors First

```bash
# 1. Fix config/settings.py (remove duplicate 'tables')
# 2. Update all staff app files with provided code
# 3. Create kitchen app structure and files
# 4. Run migrations

python manage.py makemigrations staff
python manage.py makemigrations kitchen
python manage.py migrate
python manage.py check
python manage.py runserver
```

### 2. Frontend Setup

```bash
# Create audio files directory
mkdir public/sounds

# Add kitchen-alert.mp3 to public/sounds/ directory
# You can use any short alert sound file

# Install required dependencies if not already installed
npm install axios react-router-dom

# Start React development server
npm start
```

### 3. Test Complete System

1. **Staff Management**: `/admin` → Staff profiles
2. **Enhanced Billing**: `/admin/billing` → Create bills, add items, apply GST
3. **Mobile Ordering**: `/mobile` → Select tables, place orders
4. **Kitchen Display**: `/kitchen` → View orders with audio alerts

This complete solution provides all requested functionality while preserving your existing system!