# COMPLETE SYSTEM ANALYSIS & SOLUTION

## 🚨 IMMEDIATE ERROR FIXES

### 1. Fix config/settings.py - Duplicate 'tables' Error

Your `config/settings.py` probably has duplicate 'tables' entries. Here's the correct INSTALLED_APPS:

```python
# config/settings.py - FIXED INSTALLED_APPS
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'rest_framework',
    'rest_framework_simplejwt',
    'corsheaders',
    'django_extensions',
    'django_admin_interface',
    'colorfield',
    
    # Your existing apps (NO DUPLICATES)
    'apps.core',
    'apps.users',
    'apps.rooms', 
    'apps.menu',
    'apps.bills',
    'apps.inventory',
    'apps.notifications',
    'apps.staff',
    'apps.tables',  # Only ONE entry for tables
]

# Make sure AUTH_USER_MODEL points to your CustomUser
AUTH_USER_MODEL = 'users.CustomUser'
```

### 2. Fix apps/staff/admin.py - Import Error

```python
# apps/staff/admin.py - FIXED (Only import what exists)
from django.contrib import admin
from .models import StaffProfile

@admin.register(StaffProfile)
class StaffProfileAdmin(admin.ModelAdmin):
    list_display = ['employee_id', 'name', 'department', 'position', 'is_active']
    list_filter = ['department', 'is_active']
    search_fields = ['employee_id', 'name']
    readonly_fields = ['created_at', 'updated_at']
```

### 3. Complete apps/staff/models.py - Keep Existing + Add Missing

```python
# apps/staff/models.py - COMPLETE VERSION (Build on existing)
from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from apps.users.models import CustomUser

class StaffProfile(models.Model):
    """Staff Profile for HR purposes (separate from User authentication)"""
    DEPARTMENT_CHOICES = [
        ('kitchen', 'Kitchen'),
        ('service', 'Service'),
        ('management', 'Management'),
        ('housekeeping', 'Housekeeping'),
        ('reception', 'Reception'),
        ('billing', 'Billing'),
    ]
    
    EMPLOYMENT_TYPE_CHOICES = [
        ('full_time', 'Full Time'),
        ('part_time', 'Part Time'),
        ('contract', 'Contract'),
    ]

    # Link to User (optional - for staff who need system access)
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE, null=True, blank=True)
    
    # Basic Information
    employee_id = models.CharField(max_length=20, unique=True)
    name = models.CharField(max_length=100)
    department = models.CharField(max_length=20, choices=DEPARTMENT_CHOICES)
    position = models.CharField(max_length=50)
    employment_type = models.CharField(max_length=20, choices=EMPLOYMENT_TYPE_CHOICES, default='full_time')
    
    # Contact Information
    phone = models.CharField(max_length=15)
    email = models.EmailField()
    address = models.TextField()
    
    # Employment Details
    hire_date = models.DateField()
    basic_salary = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    
    # Status
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'staff_profiles'
        verbose_name = 'Staff Profile'
        verbose_name_plural = 'Staff Profiles'

    def __str__(self):
        return f"{self.name} ({self.employee_id})"

class AttendanceRecord(models.Model):
    """Daily attendance tracking"""
    STATUS_CHOICES = [
        ('present', 'Present'),
        ('absent', 'Absent'),
        ('late', 'Late'),
        ('half_day', 'Half Day'),
    ]

    staff = models.ForeignKey(StaffProfile, on_delete=models.CASCADE, related_name='attendance_records')
    date = models.DateField()
    check_in = models.TimeField(null=True, blank=True)
    check_out = models.TimeField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='present')
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'staff_attendance_records'
        unique_together = ['staff', 'date']

    def __str__(self):
        return f"{self.staff.name} - {self.date} - {self.status}"

class AdvancePayment(models.Model):
    """Staff advance payments"""
    staff = models.ForeignKey(StaffProfile, on_delete=models.CASCADE, related_name='advance_payments')
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    reason = models.CharField(max_length=200)
    date_requested = models.DateField()
    is_approved = models.BooleanField(default=False)
    is_paid = models.BooleanField(default=False)
    approved_by = models.CharField(max_length=100, blank=True)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'staff_advance_payments'

    def __str__(self):
        return f"{self.staff.name} - ₹{self.amount}"
```

### 4. Complete apps/staff/views.py - Add Missing ViewSet

```python
# apps/staff/views.py - COMPLETE VERSION
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.shortcuts import get_object_or_404
from django.db.models import Q, Count
from datetime import datetime, date

from .models import StaffProfile, AttendanceRecord, AdvancePayment
from .serializers import StaffProfileSerializer, AttendanceRecordSerializer, AdvancePaymentSerializer

class StaffProfileViewSet(viewsets.ModelViewSet):
    """Staff Profile Management - FIXED Missing ViewSet"""
    queryset = StaffProfile.objects.all()
    serializer_class = StaffProfileSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        queryset = StaffProfile.objects.all()
        department = self.request.query_params.get('department')
        is_active = self.request.query_params.get('is_active')
        
        if department:
            queryset = queryset.filter(department=department)
        if is_active is not None:
            queryset = queryset.filter(is_active=is_active.lower() == 'true')
            
        return queryset.order_by('-created_at')
    
    @action(detail=False, methods=['get'])
    def department_stats(self, request):
        """Get staff statistics by department"""
        stats = StaffProfile.objects.values('department').annotate(
            total=Count('id'),
            active=Count('id', filter=Q(is_active=True))
        ).order_by('department')
        
        return Response(list(stats))
    
    @action(detail=True, methods=['get'])
    def attendance_summary(self, request, pk=None):
        """Get attendance summary for staff member"""
        staff = self.get_object()
        month = int(request.query_params.get('month', datetime.now().month))
        year = int(request.query_params.get('year', datetime.now().year))
        
        records = AttendanceRecord.objects.filter(
            staff=staff,
            date__month=month,
            date__year=year
        )
        
        summary = {
            'staff_name': staff.name,
            'month': month,
            'year': year,
            'total_days': records.count(),
            'present_days': records.filter(status='present').count(),
            'absent_days': records.filter(status='absent').count(),
            'late_days': records.filter(status='late').count(),
        }
        
        return Response(summary)

class AttendanceRecordViewSet(viewsets.ModelViewSet):
    """Attendance Management"""
    queryset = AttendanceRecord.objects.all()
    serializer_class = AttendanceRecordSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        queryset = AttendanceRecord.objects.all()
        staff_id = self.request.query_params.get('staff_id')
        date_from = self.request.query_params.get('date_from')
        
        if staff_id:
            queryset = queryset.filter(staff_id=staff_id)
        if date_from:
            queryset = queryset.filter(date__gte=date_from)
            
        return queryset.order_by('-date')
    
    @action(detail=False, methods=['get'])
    def today_attendance(self, request):
        """Get today's attendance report"""
        today = date.today()
        records = AttendanceRecord.objects.filter(date=today)
        
        report = {
            'date': today,
            'total_staff': StaffProfile.objects.filter(is_active=True).count(),
            'present': records.filter(status='present').count(),
            'absent': records.filter(status='absent').count(),
            'late': records.filter(status='late').count(),
            'records': AttendanceRecordSerializer(records, many=True).data
        }
        
        return Response(report)

class AdvancePaymentViewSet(viewsets.ModelViewSet):
    """Advance Payment Management"""
    queryset = AdvancePayment.objects.all()
    serializer_class = AdvancePaymentSerializer
    permission_classes = [IsAuthenticated]
    
    @action(detail=True, methods=['post'])
    def approve_payment(self, request, pk=None):
        """Approve advance payment"""
        payment = self.get_object()
        payment.is_approved = True
        payment.approved_by = request.user.email
        payment.save()
        
        return Response({'message': 'Payment approved successfully'})
```

### 5. Complete apps/staff/serializers.py

```python
# apps/staff/serializers.py - COMPLETE VERSION
from rest_framework import serializers
from .models import StaffProfile, AttendanceRecord, AdvancePayment

class StaffProfileSerializer(serializers.ModelSerializer):
    department_display = serializers.CharField(source='get_department_display', read_only=True)
    employment_type_display = serializers.CharField(source='get_employment_type_display', read_only=True)
    
    class Meta:
        model = StaffProfile
        fields = '__all__'
        read_only_fields = ['created_at', 'updated_at']

class AttendanceRecordSerializer(serializers.ModelSerializer):
    staff_name = serializers.CharField(source='staff.name', read_only=True)
    status_display = serializers.CharField(source='get_status_display', read_only=True)
    
    class Meta:
        model = AttendanceRecord
        fields = '__all__'
        read_only_fields = ['created_at']

class AdvancePaymentSerializer(serializers.ModelSerializer):
    staff_name = serializers.CharField(source='staff.name', read_only=True)
    
    class Meta:
        model = AdvancePayment
        fields = '__all__'
        read_only_fields = ['created_at']
```

### 6. Complete apps/staff/urls.py

```python
# apps/staff/urls.py - COMPLETE VERSION
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register(r'profiles', views.StaffProfileViewSet, basename='staff-profile')
router.register(r'attendance', views.AttendanceRecordViewSet, basename='attendance')
router.register(r'advances', views.AdvancePaymentViewSet, basename='advance')

urlpatterns = [
    path('', include(router.urls)),
]
```

## 🍽️ ENHANCED BILLING SYSTEM (Build on Existing Bills App)

### Enhanced Bills Views - apps/bills/enhanced_views.py (NEW FILE)

```python
# apps/bills/enhanced_views.py - NEW ENHANCED BILLING
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.shortcuts import get_object_or_404
from django.db import transaction
from decimal import Decimal
from datetime import datetime

from .models import Bill, BillItem
from .serializers import BillSerializer
from apps.tables.models import Table

class EnhancedBillingViewSet(viewsets.ViewSet):
    """Enhanced Billing System with GST and Dynamic Item Management"""
    permission_classes = [IsAuthenticated]

    @action(detail=False, methods=['get'])
    def active_tables_dashboard(self, request):
        """Get all active tables for enhanced billing dashboard"""
        # Get tables that might have orders (you can customize this logic)
        active_tables = Table.objects.filter(is_active=True)
        
        dashboard_data = []
        for table in active_tables:
            # Get bills for this table (customize based on your Bill model)
            table_bills = Bill.objects.filter(
                customer_name__icontains=f"Table {table.table_number}",
                bill_type='restaurant'
            ).order_by('-created_at')[:5]  # Latest 5 bills
            
            total_amount = sum(bill.total_amount for bill in table_bills)
            
            dashboard_data.append({
                'table_id': table.id,
                'table_number': table.table_number,
                'table_capacity': getattr(table, 'capacity', 4),
                'status': getattr(table, 'status', 'available'),
                'bills_count': table_bills.count(),
                'total_amount': float(total_amount),
                'latest_bills': [
                    {
                        'id': bill.id,
                        'receipt_number': bill.receipt_number,
                        'total_amount': float(bill.total_amount),
                        'created_at': bill.created_at.isoformat(),
                        'payment_method': bill.payment_method
                    }
                    for bill in table_bills
                ]
            })
        
        return Response({
            'active_tables': dashboard_data,
            'total_tables': len(dashboard_data)
        })

    @action(detail=False, methods=['post'])
    def create_table_bill(self, request):
        """Create new bill for table"""
        table_id = request.data.get('table_id')
        customer_name = request.data.get('customer_name', '')
        
        if not table_id:
            return Response(
                {'error': 'table_id is required'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            table = Table.objects.get(id=table_id)
        except Table.DoesNotExist:
            return Response(
                {'error': 'Table not found'}, 
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Create bill
        bill = Bill.objects.create(
            user=request.user,
            bill_type='restaurant',
            customer_name=f"Table {table.table_number} - {customer_name}",
            customer_phone=request.data.get('customer_phone', 'N/A'),
            total_amount=0
        )
        
        # Mark table as occupied if it has status field
        if hasattr(table, 'status'):
            table.status = 'occupied'
            table.save()
        
        return Response({
            'message': 'Bill created successfully',
            'bill': {
                'id': bill.id,
                'receipt_number': bill.receipt_number,
                'table_number': table.table_number
            }
        })

    @action(detail=False, methods=['post'])
    def add_item_to_bill(self, request):
        """Add custom item to bill - Admin functionality"""
        bill_id = request.data.get('bill_id')
        item_name = request.data.get('item_name')
        quantity = int(request.data.get('quantity', 1))
        price = Decimal(str(request.data.get('price', 0)))
        
        if not all([bill_id, item_name, price]):
            return Response(
                {'error': 'bill_id, item_name, and price are required'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            bill = Bill.objects.get(id=bill_id)
        except Bill.DoesNotExist:
            return Response(
                {'error': 'Bill not found'}, 
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Add item to bill
        BillItem.objects.create(
            bill=bill,
            item_name=item_name,
            quantity=quantity,
            price=price
        )
        
        # Recalculate bill total
        self._recalculate_bill_total(bill)
        
        return Response({
            'message': 'Item added successfully',
            'bill_total': float(bill.total_amount)
        })

    @action(detail=False, methods=['post'])
    def apply_gst_to_bill(self, request):
        """Apply GST calculation to bill"""
        bill_id = request.data.get('bill_id')
        apply_gst = request.data.get('apply_gst', True)
        interstate = request.data.get('interstate', False)
        
        if not bill_id:
            return Response(
                {'error': 'bill_id is required'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            bill = Bill.objects.get(id=bill_id)
        except Bill.DoesNotExist:
            return Response(
                {'error': 'Bill not found'}, 
                status=status.HTTP_404_NOT_FOUND
            )
        
        if apply_gst:
            # Calculate items total
            items_total = sum(item.quantity * item.price for item in bill.items.all())
            
            if interstate:
                # IGST 18%
                igst_amount = items_total * Decimal('0.18')
                gst_total = igst_amount
                gst_breakdown = {
                    'type': 'IGST',
                    'rate': 18.0,
                    'igst_amount': float(igst_amount),
                    'cgst_amount': 0,
                    'sgst_amount': 0
                }
            else:
                # CGST + SGST 9% each
                cgst_amount = items_total * Decimal('0.09')
                sgst_amount = items_total * Decimal('0.09')
                gst_total = cgst_amount + sgst_amount
                gst_breakdown = {
                    'type': 'CGST + SGST',
                    'rate': 18.0,
                    'cgst_amount': float(cgst_amount),
                    'sgst_amount': float(sgst_amount),
                    'igst_amount': 0
                }
            
            bill.total_amount = items_total + gst_total
            bill.save()
            
            return Response({
                'message': 'GST applied successfully',
                'bill_details': {
                    'items_total': float(items_total),
                    'gst_total': float(gst_total),
                    'final_total': float(bill.total_amount),
                    'gst_breakdown': gst_breakdown
                }
            })
        
        return Response({'message': 'GST not applied'})

    @action(detail=False, methods=['delete'])
    def delete_bill_item(self, request):
        """Delete item from bill"""
        item_id = request.data.get('item_id')
        
        if not item_id:
            return Response(
                {'error': 'item_id is required'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            item = BillItem.objects.get(id=item_id)
            bill = item.bill
            item.delete()
            
            # Recalculate bill total
            self._recalculate_bill_total(bill)
            
            return Response({
                'message': 'Item deleted successfully',
                'bill_total': float(bill.total_amount)
            })
        except BillItem.DoesNotExist:
            return Response(
                {'error': 'Item not found'}, 
                status=status.HTTP_404_NOT_FOUND
            )

    @action(detail=False, methods=['post'])
    def finalize_bill_and_release_table(self, request):
        """Generate final bill and mark table as available"""
        bill_id = request.data.get('bill_id')
        
        if not bill_id:
            return Response(
                {'error': 'bill_id is required'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            bill = Bill.objects.get(id=bill_id)
            
            # Extract table number from customer name
            if 'Table' in bill.customer_name:
                table_number = bill.customer_name.split('Table ')[1].split(' -')[0]
                try:
                    table = Table.objects.get(table_number=table_number)
                    if hasattr(table, 'status'):
                        table.status = 'available'  # Mark table as available
                        table.save()
                except Table.DoesNotExist:
                    pass
            
            return Response({
                'message': 'Bill finalized and table released',
                'bill': {
                    'id': bill.id,
                    'receipt_number': bill.receipt_number,
                    'total_amount': float(bill.total_amount),
                    'finalized_at': datetime.now().isoformat()
                }
            })
            
        except Bill.DoesNotExist:
            return Response(
                {'error': 'Bill not found'}, 
                status=status.HTTP_404_NOT_FOUND
            )

    def _recalculate_bill_total(self, bill):
        """Helper method to recalculate bill total"""
        total = sum(item.quantity * item.price for item in bill.items.all())
        bill.total_amount = total
        bill.save()
```

### Enhanced Bills URLs - apps/bills/enhanced_urls.py (NEW FILE)

```python
# apps/bills/enhanced_urls.py - NEW FILE
from django.urls import path
from .enhanced_views import EnhancedBillingViewSet

urlpatterns = [
    path('dashboard/', EnhancedBillingViewSet.as_view({'get': 'active_tables_dashboard'}), name='billing-dashboard'),
    path('create-table-bill/', EnhancedBillingViewSet.as_view({'post': 'create_table_bill'}), name='create-table-bill'),
    path('add-item/', EnhancedBillingViewSet.as_view({'post': 'add_item_to_bill'}), name='add-bill-item'),
    path('apply-gst/', EnhancedBillingViewSet.as_view({'post': 'apply_gst_to_bill'}), name='apply-gst'),
    path('delete-item/', EnhancedBillingViewSet.as_view({'delete': 'delete_bill_item'}), name='delete-bill-item'),
    path('finalize-bill/', EnhancedBillingViewSet.as_view({'post': 'finalize_bill_and_release_table'}), name='finalize-bill'),
]
```

## IMMEDIATE SETUP COMMANDS

```bash
# 1. Fix settings.py first (remove duplicate 'tables')
# 2. Fix staff admin.py 
# 3. Update all the staff app files above

# 4. Create migrations
python manage.py makemigrations staff
python manage.py makemigrations
python manage.py migrate

# 5. Test the system
python manage.py check

# 6. Run server
python manage.py runserver
```

This fixes all immediate errors while preserving your existing functionality!