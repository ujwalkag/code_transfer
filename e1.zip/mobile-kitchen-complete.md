# COMPLETE SOLUTION PART 2 - Mobile Ordering & Kitchen Display

## 📱 MOBILE ORDERING SYSTEM (Enhance Existing Tables App)

### Enhanced Mobile Views - apps/tables/mobile_views.py (NEW FILE)

```python
# apps/tables/mobile_views.py - MOBILE ORDERING SYSTEM
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.shortcuts import get_object_or_404
from datetime import datetime

from .models import Table
from .serializers import TableSerializer
from apps.menu.models import MenuItem, MenuCategory
from apps.menu.serializers import MenuItemSerializer, MenuCategorySerializer
from apps.bills.models import Bill, BillItem

class MobileOrderingViewSet(viewsets.ViewSet):
    """Mobile Ordering System for Waiters - Table-specific orders"""
    permission_classes = [IsAuthenticated]
    
    @action(detail=False, methods=['get'])
    def available_tables(self, request):
        """Get all tables for mobile ordering"""
        tables = Table.objects.filter(is_active=True).order_by('table_number')
        return Response([
            {
                'id': table.id,
                'table_number': table.table_number,
                'capacity': getattr(table, 'capacity', 4),
                'status': getattr(table, 'status', 'available'),
                'location': getattr(table, 'location', 'main_hall')
            }
            for table in tables
        ])
    
    @action(detail=False, methods=['get'])
    def menu_for_ordering(self, request):
        """Get complete menu organized by categories"""
        categories = MenuCategory.objects.all()
        menu_data = []
        
        for category in categories:
            items = MenuItem.objects.filter(category=category, available=True)
            menu_data.append({
                'category': {
                    'id': category.id,
                    'name_en': category.name_en,
                    'name_hi': category.name_hi,
                },
                'items': [
                    {
                        'id': item.id,
                        'name_en': item.name_en,
                        'name_hi': item.name_hi,
                        'description_en': item.description_en,
                        'description_hi': item.description_hi,
                        'price': float(item.price),
                        'image': item.image.url if item.image else None,
                        'available': item.available
                    }
                    for item in items
                ]
            })
        
        return Response(menu_data)
    
    @action(detail=False, methods=['post'])
    def create_table_order(self, request):
        """Create new order for specific table - T1, T2, T3 etc"""
        table_id = request.data.get('table_id')
        items = request.data.get('items', [])  # [{'item_id': 1, 'quantity': 2}, ...]
        customer_name = request.data.get('customer_name', 'Walk-in Customer')
        special_instructions = request.data.get('special_instructions', '')
        
        if not table_id or not items:
            return Response(
                {'error': 'table_id and items are required'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            table = Table.objects.get(id=table_id)
        except Table.DoesNotExist:
            return Response(
                {'error': 'Table not found'}, 
                status=status.HTTP_404_NOT_FOUND
            )
        
        # Create bill for the order
        bill = Bill.objects.create(
            user=request.user,
            bill_type='restaurant',
            customer_name=f"Table {table.table_number} - {customer_name}",
            customer_phone=request.data.get('customer_phone', 'N/A'),
            total_amount=0
        )
        
        # Add items to bill
        total_amount = 0
        order_items = []
        
        for item_data in items:
            try:
                menu_item = MenuItem.objects.get(id=item_data['item_id'], available=True)
                quantity = int(item_data['quantity'])
                
                bill_item = BillItem.objects.create(
                    bill=bill,
                    item_name=menu_item.name_en,  # Using English name
                    quantity=quantity,
                    price=menu_item.price
                )
                
                total_amount += menu_item.price * quantity
                order_items.append({
                    'name': menu_item.name_en,
                    'quantity': quantity,
                    'price': float(menu_item.price),
                    'total': float(menu_item.price * quantity)
                })
                
            except MenuItem.DoesNotExist:
                continue
        
        # Update bill total
        bill.total_amount = total_amount
        bill.save()
        
        # Mark table as occupied
        if hasattr(table, 'status'):
            table.status = 'occupied'
            table.save()
        
        return Response({
            'message': f'Order created successfully for Table {table.table_number}',
            'order_details': {
                'bill_id': bill.id,
                'receipt_number': bill.receipt_number,
                'table_number': table.table_number,
                'total_amount': float(bill.total_amount),
                'items': order_items,
                'special_instructions': special_instructions,
                'created_at': bill.created_at.isoformat()
            }
        })
    
    @action(detail=False, methods=['post'])
    def add_items_to_existing_order(self, request):
        """Add more items to existing table order - Dynamic updates"""
        table_id = request.data.get('table_id')
        items = request.data.get('items', [])
        
        if not table_id or not items:
            return Response(
                {'error': 'table_id and items are required'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            table = Table.objects.get(id=table_id)
            
            # Find latest active bill for this table
            latest_bill = Bill.objects.filter(
                customer_name__icontains=f"Table {table.table_number}",
                bill_type='restaurant'
            ).order_by('-created_at').first()
            
            if not latest_bill:
                return Response(
                    {'error': 'No active order found for this table'}, 
                    status=status.HTTP_404_NOT_FOUND
                )
            
            # Add new items
            additional_amount = 0
            new_items = []
            
            for item_data in items:
                try:
                    menu_item = MenuItem.objects.get(id=item_data['item_id'], available=True)
                    quantity = int(item_data['quantity'])
                    
                    BillItem.objects.create(
                        bill=latest_bill,
                        item_name=menu_item.name_en,
                        quantity=quantity,
                        price=menu_item.price
                    )
                    
                    item_total = menu_item.price * quantity
                    additional_amount += item_total
                    
                    new_items.append({
                        'name': menu_item.name_en,
                        'quantity': quantity,
                        'price': float(menu_item.price),
                        'total': float(item_total)
                    })
                    
                except MenuItem.DoesNotExist:
                    continue
            
            # Update bill total
            latest_bill.total_amount += additional_amount
            latest_bill.save()
            
            return Response({
                'message': 'Items added successfully to existing order',
                'order_update': {
                    'bill_id': latest_bill.id,
                    'table_number': table.table_number,
                    'previous_total': float(latest_bill.total_amount - additional_amount),
                    'additional_amount': float(additional_amount),
                    'new_total': float(latest_bill.total_amount),
                    'added_items': new_items,
                    'updated_at': datetime.now().isoformat()
                }
            })
            
        except Table.DoesNotExist:
            return Response(
                {'error': 'Table not found'}, 
                status=status.HTTP_404_NOT_FOUND
            )
    
    @action(detail=True, methods=['get'])
    def table_current_orders(self, request, pk=None):
        """Get current active orders for specific table"""
        try:
            table = Table.objects.get(id=pk)
            
            # Get all bills for this table (active orders)
            bills = Bill.objects.filter(
                customer_name__icontains=f"Table {table.table_number}",
                bill_type='restaurant'
            ).order_by('-created_at')
            
            orders_data = []
            total_table_amount = 0
            
            for bill in bills:
                items = bill.items.all()
                bill_items = []
                
                for item in items:
                    bill_items.append({
                        'id': item.id,
                        'name': item.item_name,
                        'quantity': item.quantity,
                        'price': float(item.price),
                        'total': float(item.quantity * item.price)
                    })
                
                orders_data.append({
                    'bill_id': bill.id,
                    'receipt_number': bill.receipt_number,
                    'total_amount': float(bill.total_amount),
                    'created_at': bill.created_at.isoformat(),
                    'customer_name': bill.customer_name,
                    'payment_method': bill.payment_method,
                    'items': bill_items,
                    'items_count': len(bill_items)
                })
                
                total_table_amount += bill.total_amount
            
            return Response({
                'table_info': {
                    'id': table.id,
                    'table_number': table.table_number,
                    'capacity': getattr(table, 'capacity', 4),
                    'status': getattr(table, 'status', 'available'),
                    'location': getattr(table, 'location', 'main_hall')
                },
                'orders': orders_data,
                'total_orders': len(orders_data),
                'total_amount': float(total_table_amount),
                'last_updated': datetime.now().isoformat()
            })
            
        except Table.DoesNotExist:
            return Response(
                {'error': 'Table not found'}, 
                status=status.HTTP_404_NOT_FOUND
            )
    
    @action(detail=False, methods=['get'])
    def all_active_table_orders(self, request):
        """Get orders for all tables - Enhanced billing view"""
        tables_with_orders = []
        
        # Get all tables
        tables = Table.objects.filter(is_active=True).order_by('table_number')
        
        for table in tables:
            # Check if table has any recent bills
            recent_bills = Bill.objects.filter(
                customer_name__icontains=f"Table {table.table_number}",
                bill_type='restaurant'
            ).order_by('-created_at')[:3]  # Last 3 orders
            
            if recent_bills.exists():
                total_amount = sum(bill.total_amount for bill in recent_bills)
                
                tables_with_orders.append({
                    'table_id': table.id,
                    'table_number': table.table_number,
                    'status': getattr(table, 'status', 'available'),
                    'orders_count': recent_bills.count(),
                    'total_amount': float(total_amount),
                    'latest_order_time': recent_bills.first().created_at.isoformat(),
                    'can_generate_bill': getattr(table, 'status', 'available') == 'occupied'
                })
        
        return Response({
            'active_tables': tables_with_orders,
            'total_active_tables': len(tables_with_orders),
            'total_pending_amount': sum(table['total_amount'] for table in tables_with_orders)
        })
```

### Mobile URLs - apps/tables/mobile_urls.py (ENHANCE EXISTING)

```python
# apps/tables/mobile_urls.py - MOBILE ORDERING URLS
from django.urls import path
from .mobile_views import MobileOrderingViewSet

urlpatterns = [
    path('available-tables/', MobileOrderingViewSet.as_view({'get': 'available_tables'}), name='mobile-tables'),
    path('menu/', MobileOrderingViewSet.as_view({'get': 'menu_for_ordering'}), name='mobile-menu'),
    path('create-order/', MobileOrderingViewSet.as_view({'post': 'create_table_order'}), name='mobile-create-order'),
    path('add-items/', MobileOrderingViewSet.as_view({'post': 'add_items_to_existing_order'}), name='mobile-add-items'),
    path('table/<int:pk>/orders/', MobileOrderingViewSet.as_view({'get': 'table_current_orders'}), name='mobile-table-orders'),
    path('active-orders/', MobileOrderingViewSet.as_view({'get': 'all_active_table_orders'}), name='mobile-active-orders'),
]
```

## 🍳 KITCHEN DISPLAY SYSTEM WITH AUDIO

### Kitchen Models - apps/kitchen/models.py (NEW APP)

```python
# apps/kitchen/models.py - KITCHEN SYSTEM WITH AUDIO
from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from apps.bills.models import Bill
from django.utils import timezone

class KitchenOrder(models.Model):
    """Kitchen orders from restaurant bills"""
    STATUS_CHOICES = [
        ('received', 'Order Received'),
        ('preparing', 'Preparing'),
        ('ready', 'Ready to Serve'),
        ('served', 'Served'),
        ('cancelled', 'Cancelled'),
    ]
    
    PRIORITY_CHOICES = [
        (1, 'Low'),
        (2, 'Normal'),
        (3, 'High'),
        (4, 'Urgent'),
    ]

    bill = models.OneToOneField(Bill, on_delete=models.CASCADE, related_name='kitchen_order')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='received')
    priority = models.IntegerField(choices=PRIORITY_CHOICES, default=2)
    estimated_time = models.IntegerField(default=30, help_text="Estimated time in minutes")
    actual_prep_time = models.IntegerField(null=True, blank=True)
    
    # Kitchen staff
    assigned_chef = models.CharField(max_length=100, blank=True)
    
    # Timestamps
    received_at = models.DateTimeField(auto_now_add=True)
    started_at = models.DateTimeField(null=True, blank=True)
    ready_at = models.DateTimeField(null=True, blank=True)
    served_at = models.DateTimeField(null=True, blank=True)
    
    # Special instructions
    special_instructions = models.TextField(blank=True)
    kitchen_notes = models.TextField(blank=True)
    
    # Audio alerts
    audio_played = models.BooleanField(default=False)
    audio_acknowledged = models.BooleanField(default=False)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'kitchen_orders'
        ordering = ['priority', 'received_at']

    def __str__(self):
        table_info = "Takeaway"
        if 'Table' in self.bill.customer_name:
            table_info = self.bill.customer_name.split(' - ')[0]
        return f"{self.bill.receipt_number} - {table_info} - {self.get_status_display()}"

    def start_preparation(self, chef_name=''):
        """Mark order as being prepared"""
        if self.status == 'received':
            self.status = 'preparing'
            self.started_at = timezone.now()
            self.assigned_chef = chef_name
            self.audio_acknowledged = True
            self.save()

    def mark_ready(self):
        """Mark order as ready to serve"""
        if self.status == 'preparing':
            self.status = 'ready'
            self.ready_at = timezone.now()
            
            # Calculate prep time
            if self.started_at:
                prep_time = (self.ready_at - self.started_at).total_seconds() / 60
                self.actual_prep_time = int(prep_time)
            
            self.save()

    def mark_served(self):
        """Mark order as served"""
        if self.status == 'ready':
            self.status = 'served'
            self.served_at = timezone.now()
            self.save()

class AudioAlert(models.Model):
    """Kitchen audio alert settings"""
    ALERT_TYPES = [
        ('new_order', 'New Order'),
        ('order_ready', 'Order Ready'),
        ('priority_order', 'Priority Order'),
    ]

    name = models.CharField(max_length=100)
    alert_type = models.CharField(max_length=20, choices=ALERT_TYPES)
    audio_file = models.FileField(upload_to='kitchen_audio/', null=True, blank=True)
    is_active = models.BooleanField(default=True)
    volume = models.IntegerField(default=80, validators=[MinValueValidator(0), MaxValueValidator(100)])
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'kitchen_audio_alerts'

    def __str__(self):
        return f"{self.name} - {self.get_alert_type_display()}"
```

### Kitchen Views - apps/kitchen/views.py (NEW)

```python
# apps/kitchen/views.py - KITCHEN DISPLAY WITH AUDIO
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import AllowAny  # Kitchen display is public access
from django.shortcuts import get_object_or_404
from django.db.models import Q
from datetime import datetime, date

from .models import KitchenOrder, AudioAlert
from .serializers import KitchenOrderSerializer, AudioAlertSerializer

class KitchenDisplayViewSet(viewsets.ModelViewSet):
    """Kitchen Display System with Audio Notifications"""
    queryset = KitchenOrder.objects.exclude(status='served')
    serializer_class = KitchenOrderSerializer
    permission_classes = [AllowAny]  # Kitchen display accessible without auth
    
    def get_queryset(self):
        queryset = KitchenOrder.objects.exclude(status='served')
        status_filter = self.request.query_params.get('status')
        priority = self.request.query_params.get('priority')
        
        if status_filter:
            queryset = queryset.filter(status=status_filter)
        if priority:
            queryset = queryset.filter(priority=priority)
            
        return queryset.order_by('priority', 'received_at')

    @action(detail=False, methods=['get'])
    def active_orders(self, request):
        """Get all active kitchen orders"""
        orders = KitchenOrder.objects.filter(
            status__in=['received', 'preparing', 'ready']
        ).order_by('priority', 'received_at')
        
        serializer = KitchenOrderSerializer(orders, many=True)
        return Response(serializer.data)

    @action(detail=True, methods=['post'])
    def update_order_status(self, request, pk=None):
        """Update order status from kitchen interface"""
        order = self.get_object()
        new_status = request.data.get('status')
        chef_name = request.data.get('chef_name', '')
        
        if new_status not in [choice[0] for choice in KitchenOrder.STATUS_CHOICES]:
            return Response(
                {'error': 'Invalid status'}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        
        old_status = order.status
        
        if new_status == 'preparing':
            order.start_preparation(chef_name)
        elif new_status == 'ready':
            order.mark_ready()
        elif new_status == 'served':
            order.mark_served()
        elif new_status == 'cancelled':
            order.status = 'cancelled'
            order.save()
        
        return Response({
            'message': f'Order status updated from {old_status} to {new_status}',
            'order': KitchenOrderSerializer(order).data
        })

    @action(detail=True, methods=['post'])
    def acknowledge_audio(self, request, pk=None):
        """Acknowledge audio alert"""
        order = self.get_object()
        order.audio_acknowledged = True
        order.save()
        
        return Response({'message': 'Audio alert acknowledged'})

    @action(detail=False, methods=['get'])
    def kitchen_stats(self, request):
        """Get kitchen performance stats"""
        today = date.today()
        orders_today = KitchenOrder.objects.filter(received_at__date=today)
        
        stats = {
            'date': today.isoformat(),
            'total_orders': orders_today.count(),
            'completed': orders_today.filter(status='served').count(),
            'preparing': orders_today.filter(status='preparing').count(),
            'ready': orders_today.filter(status='ready').count(),
            'cancelled': orders_today.filter(status='cancelled').count(),
            'average_prep_time': 0
        }
        
        # Calculate average prep time
        completed_orders = orders_today.filter(status='served', actual_prep_time__isnull=False)
        if completed_orders.exists():
            total_time = sum(order.actual_prep_time for order in completed_orders)
            stats['average_prep_time'] = round(total_time / completed_orders.count(), 1)
        
        return Response(stats)

class AudioAlertViewSet(viewsets.ModelViewSet):
    """Audio alert management"""
    queryset = AudioAlert.objects.filter(is_active=True)
    serializer_class = AudioAlertSerializer
    permission_classes = [AllowAny]

    @action(detail=False, methods=['get'])
    def active_alerts(self, request):
        """Get active audio alerts"""
        alerts = AudioAlert.objects.filter(is_active=True).order_by('alert_type')
        return Response(AudioAlertSerializer(alerts, many=True).data)
```

### Kitchen Serializers - apps/kitchen/serializers.py (NEW)

```python
# apps/kitchen/serializers.py - KITCHEN SERIALIZERS
from rest_framework import serializers
from .models import KitchenOrder, AudioAlert
from datetime import datetime

class KitchenOrderSerializer(serializers.ModelSerializer):
    bill_receipt = serializers.CharField(source='bill.receipt_number', read_only=True)
    customer_info = serializers.SerializerMethodField()
    table_number = serializers.SerializerMethodField()
    status_display = serializers.CharField(source='get_status_display', read_only=True)
    priority_display = serializers.CharField(source='get_priority_display', read_only=True)
    items = serializers.SerializerMethodField()
    time_elapsed = serializers.SerializerMethodField()
    
    class Meta:
        model = KitchenOrder
        fields = '__all__'
        read_only_fields = ['received_at', 'created_at', 'updated_at']

    def get_customer_info(self, obj):
        return obj.bill.customer_name

    def get_table_number(self, obj):
        if 'Table' in obj.bill.customer_name:
            return obj.bill.customer_name.split('Table ')[1].split(' -')[0]
        return 'Takeaway'

    def get_items(self, obj):
        """Get bill items for kitchen display"""
        items = obj.bill.items.all()
        return [
            {
                'id': item.id,
                'name': item.item_name,
                'quantity': item.quantity,
                'price': float(item.price)
            }
            for item in items
        ]

    def get_time_elapsed(self, obj):
        """Minutes since order received"""
        if obj.received_at:
            elapsed = datetime.now() - obj.received_at.replace(tzinfo=None)
            return int(elapsed.total_seconds() / 60)
        return 0

class AudioAlertSerializer(serializers.ModelSerializer):
    alert_type_display = serializers.CharField(source='get_alert_type_display', read_only=True)
    
    class Meta:
        model = AudioAlert
        fields = '__all__'
        read_only_fields = ['created_at']
```

### Kitchen URLs - apps/kitchen/urls.py (NEW)

```python
# apps/kitchen/urls.py - KITCHEN URLS
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register(r'orders', views.KitchenDisplayViewSet, basename='kitchen-order')
router.register(r'audio', views.AudioAlertViewSet, basename='kitchen-audio')

urlpatterns = [
    path('', include(router.urls)),
]
```

### Kitchen Signals - apps/kitchen/signals.py (NEW - Auto Create Kitchen Orders)

```python
# apps/kitchen/signals.py - AUTO CREATE KITCHEN ORDERS
from django.db.models.signals import post_save
from django.dispatch import receiver
from apps.bills.models import Bill
from .models import KitchenOrder

@receiver(post_save, sender=Bill)
def create_kitchen_order(sender, instance, created, **kwargs):
    """Auto-create kitchen order when restaurant bill is created"""
    if created and instance.bill_type == 'restaurant':
        KitchenOrder.objects.create(
            bill=instance,
            status='received',
            priority=2,  # Normal priority
            special_instructions=getattr(instance, 'notes', '')
        )
        print(f"🍳 Kitchen Order Created: {instance.receipt_number}")
```

### Kitchen Apps Config - apps/kitchen/apps.py (NEW)

```python
# apps/kitchen/apps.py
from django.apps import AppConfig

class KitchenConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.kitchen'
    
    def ready(self):
        import apps.kitchen.signals
```

## ⚙️ UPDATE MAIN CONFIG FILES

### Update config/urls.py - Add New Routes

```python
# config/urls.py - COMPLETE UPDATED VERSION
from django.contrib import admin
from django.urls import path, include
from apps.users.views import CustomTokenObtainPairView
from rest_framework_simplejwt.views import TokenRefreshView

urlpatterns = [
    # Authentication
    path('api/auth/token/', CustomTokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/auth/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    
    # Admin
    path('admin/', admin.site.urls),
    
    # Existing APIs
    path('api/core/', include('apps.core.urls')),
    path('api/menu/', include('apps.menu.urls')),
    path('api/rooms/', include('apps.rooms.urls')),
    path('api/users/', include('apps.users.urls')),
    path('api/bills/', include('apps.bills.urls')),
    path('api/inventory/', include('apps.inventory.urls')),
    path('api/notifications/', include('apps.notifications.urls')),
    path('api/staff/', include('apps.staff.urls')),  # FIXED
    path('api/tables/', include('apps.tables.urls')),
    
    # NEW Enhanced APIs
    path('api/bills/enhanced/', include('apps.bills.enhanced_urls')),  # Enhanced billing
    path('api/tables/mobile/', include('apps.tables.mobile_urls')),     # Mobile ordering  
    path('api/kitchen/', include('apps.kitchen.urls')),                 # Kitchen display
]
```

### Update config/settings.py - Add Kitchen App

```python
# config/settings.py - ADD KITCHEN TO INSTALLED_APPS
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes', 
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'rest_framework',
    'rest_framework_simplejwt',
    'corsheaders',
    'django_extensions',
    'django_admin_interface', 
    'colorfield',
    
    # Your existing apps
    'apps.core',
    'apps.users',
    'apps.rooms',
    'apps.menu', 
    'apps.bills',
    'apps.inventory',
    'apps.notifications',
    'apps.staff',      # FIXED - Now complete
    'apps.tables',     # Only ONE entry
    'apps.kitchen',    # NEW - Kitchen system
]

# Audio files storage
MEDIA_URL = '/media/'
MEDIA_ROOT = os.path.join(BASE_DIR, 'media')
```

## 🚀 GUARANTEED WORKING SETUP COMMANDS

```bash
# 1. Fix settings.py (remove duplicate 'tables')
# 2. Update all staff app files
# 3. Create kitchen app structure
mkdir -p apps/kitchen
touch apps/kitchen/__init__.py apps/kitchen/apps.py
touch apps/kitchen/models.py apps/kitchen/views.py apps/kitchen/serializers.py
touch apps/kitchen/urls.py apps/kitchen/admin.py apps/kitchen/signals.py

# 4. Copy all provided code into respective files

# 5. Create migrations
python manage.py makemigrations staff
python manage.py makemigrations kitchen
python manage.py makemigrations

# 6. Apply migrations  
python manage.py migrate

# 7. Test system
python manage.py check

# 8. Run server
python manage.py runserver
```

This completes the backend with all required functionality while preserving your existing system!