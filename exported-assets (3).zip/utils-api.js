// utils/api.js - API utility for HTTP requests
import axios from 'axios';
import toast from 'react-hot-toast';

// Create axios instance with base configuration
const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL || 'https://hotelrshammad.co.in/api',
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 10000, // 10 seconds timeout
});

// Request interceptor to add auth token if available
api.interceptors.request.use(
  (config) => {
    // Add auth token from localStorage or cookie if available
    const token = typeof window !== 'undefined' ? localStorage.getItem('auth_token') : null;
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor for error handling
api.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    // Handle common errors
    if (error.response) {
      const { status, data } = error.response;
      
      switch (status) {
        case 401:
          toast.error('Authentication required. Please login.');
          // Redirect to login if needed
          if (typeof window !== 'undefined') {
            localStorage.removeItem('auth_token');
            window.location.href = '/login';
          }
          break;
        case 403:
          toast.error('Access denied. Insufficient permissions.');
          break;
        case 404:
          toast.error('Resource not found.');
          break;
        case 500:
          toast.error('Server error. Please try again later.');
          break;
        default:
          toast.error(data.message || 'An error occurred.');
      }
    } else if (error.request) {
      toast.error('Network error. Please check your connection.');
    } else {
      toast.error('An unexpected error occurred.');
    }
    
    return Promise.reject(error);
  }
);

// Inventory API functions
export const inventoryApi = {
  // Categories
  getCategories: () => api.get('/inventory/categories/'),
  createCategory: (data) => api.post('/inventory/categories/', data),
  updateCategory: (id, data) => api.put(`/inventory/categories/${id}/`, data),
  deleteCategory: (id) => api.delete(`/inventory/categories/${id}/`),
  
  // Items
  getItems: (params = {}) => api.get('/inventory/items/', { params }),
  getItem: (id) => api.get(`/inventory/items/${id}/`),
  createItem: (data) => api.post('/inventory/items/', data),
  updateItem: (id, data) => api.put(`/inventory/items/${id}/`, data),
  deleteItem: (id) => api.delete(`/inventory/items/${id}/`),
  
  // Stock Movements
  getMovements: (params = {}) => api.get('/inventory/movements/', { params }),
  createMovement: (data) => api.post('/inventory/movements/', data),
  
  // Low Stock Alerts
  getAlerts: () => api.get('/inventory/alerts/'),
  markAlertResolved: (id) => api.patch(`/inventory/alerts/${id}/`, { is_resolved: true }),
  
  // Suppliers
  getSuppliers: () => api.get('/inventory/suppliers/'),
  createSupplier: (data) => api.post('/inventory/suppliers/', data),
  updateSupplier: (id, data) => api.put(`/inventory/suppliers/${id}/`, data),
  deleteSupplier: (id) => api.delete(`/inventory/suppliers/${id}/`),
  
  // Purchase Orders
  getPurchaseOrders: (params = {}) => api.get('/inventory/purchase-orders/', { params }),
  getPurchaseOrder: (id) => api.get(`/inventory/purchase-orders/${id}/`),
  createPurchaseOrder: (data) => api.post('/inventory/purchase-orders/', data),
  updatePurchaseOrder: (id, data) => api.put(`/inventory/purchase-orders/${id}/`, data),
  markOrderReceived: (id) => api.patch(`/inventory/purchase-orders/${id}/`, { status: 'received' }),
};

export default api;