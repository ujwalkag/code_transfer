// pages/inventory/index.js - Main inventory items list page
import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import Head from 'next/head';
import toast from 'react-hot-toast';
import { 
  PlusIcon, 
  MagnifyingGlassIcon, 
  FunnelIcon,
  ArrowDownTrayIcon,
  ExclamationTriangleIcon
} from '@heroicons/react/24/outline';

import { inventoryApi } from '../../utils/api';
import ItemTable from '../../components/inventory/ItemTable';
import ItemForm from '../../components/inventory/ItemForm';

const InventoryPage = () => {
  const router = useRouter();
  
  // State management
  const [items, setItems] = useState([]);
  const [categories, setCategories] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [formLoading, setFormLoading] = useState(false);
  
  // Form and modal state
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  
  // Filter and search state
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [stockFilter, setStockFilter] = useState('all'); // all, low-stock, out-of-stock
  const [showFilters, setShowFilters] = useState(false);
  
  // Load initial data
  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [itemsRes, categoriesRes, suppliersRes] = await Promise.all([
        inventoryApi.getItems(),
        inventoryApi.getCategories(),
        inventoryApi.getSuppliers()
      ]);
      
      setItems(itemsRes.data.results || itemsRes.data);
      setCategories(categoriesRes.data.results || categoriesRes.data);
      setSuppliers(suppliersRes.data.results || suppliersRes.data);
    } catch (error) {
      console.error('Error loading data:', error);
      toast.error('Failed to load inventory data');
    } finally {
      setLoading(false);
    }
  };

  // Filter items based on search and filters
  const filteredItems = items.filter(item => {
    // Search filter
    if (searchTerm && !item.name.toLowerCase().includes(searchTerm.toLowerCase()) && 
        !item.sku.toLowerCase().includes(searchTerm.toLowerCase())) {
      return false;
    }
    
    // Category filter
    if (categoryFilter && item.category.toString() !== categoryFilter) {
      return false;
    }
    
    // Stock filter
    if (stockFilter === 'low-stock' && item.current_stock > item.min_stock_level) {
      return false;
    }
    if (stockFilter === 'out-of-stock' && item.current_stock > 0) {
      return false;
    }
    
    return true;
  });

  // Get low stock count for alerts
  const lowStockCount = items.filter(item => 
    item.current_stock <= item.min_stock_level && item.current_stock > 0
  ).length;
  
  const outOfStockCount = items.filter(item => item.current_stock === 0).length;

  // Handle form submission
  const handleFormSubmit = async (formData) => {
    try {
      setFormLoading(true);
      
      if (editingItem) {
        await inventoryApi.updateItem(editingItem.id, formData);
        toast.success('Item updated successfully');
      } else {
        await inventoryApi.createItem(formData);
        toast.success('Item added successfully');
      }
      
      // Reload data
      await loadData();
      setIsFormOpen(false);
      setEditingItem(null);
    } catch (error) {
      console.error('Error saving item:', error);
      const message = error.response?.data?.message || 'Failed to save item';
      toast.error(message);
    } finally {
      setFormLoading(false);
    }
  };

  // Handle item edit
  const handleEdit = (item) => {
    setEditingItem(item);
    setIsFormOpen(true);
  };

  // Handle item delete
  const handleDelete = async (itemId) => {
    if (!window.confirm('Are you sure you want to delete this item?')) {
      return;
    }
    
    try {
      await inventoryApi.deleteItem(itemId);
      toast.success('Item deleted successfully');
      await loadData();
    } catch (error) {
      console.error('Error deleting item:', error);
      toast.error('Failed to delete item');
    }
  };

  // Handle add new item
  const handleAddNew = () => {
    setEditingItem(null);
    setIsFormOpen(true);
  };

  // Clear filters
  const clearFilters = () => {
    setSearchTerm('');
    setCategoryFilter('');
    setStockFilter('all');
  };

  // Export to CSV
  const handleExport = () => {
    const csvContent = [
      ['Name', 'SKU', 'Category', 'Supplier', 'Current Stock', 'Min Stock', 'Unit Price', 'Location'].join(','),
      ...filteredItems.map(item => {
        const category = categories.find(c => c.id === item.category)?.name || '';
        const supplier = suppliers.find(s => s.id === item.supplier)?.name || '';
        return [
          item.name,
          item.sku,
          category,
          supplier,
          item.current_stock,
          item.min_stock_level,
          item.unit_price,
          item.location || ''
        ].join(',');
      })
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `inventory-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  };

  return (
    <>
      <Head>
        <title>Inventory Management - Hotel Management</title>
      </Head>

      <div className="min-h-screen bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Header */}
          <div className="mb-8">
            <div className="flex justify-between items-center">
              <div>
                <h1 className="text-3xl font-bold text-gray-900">Inventory Management</h1>
                <p className="text-gray-600 mt-2">Manage your hotel inventory items and stock levels</p>
              </div>
              <button
                onClick={handleAddNew}
                className="inline-flex items-center px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
              >
                <PlusIcon className="h-5 w-5 mr-2" />
                Add Item
              </button>
            </div>
          </div>

          {/* Alert Cards */}
          {(lowStockCount > 0 || outOfStockCount > 0) && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              {lowStockCount > 0 && (
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                  <div className="flex items-center">
                    <ExclamationTriangleIcon className="h-5 w-5 text-yellow-400 mr-3" />
                    <div>
                      <h3 className="text-sm font-medium text-yellow-800">Low Stock Alert</h3>
                      <p className="text-yellow-700 text-sm">{lowStockCount} items are running low on stock</p>
                    </div>
                    <button
                      onClick={() => setStockFilter('low-stock')}
                      className="ml-auto text-yellow-700 hover:text-yellow-900 text-sm font-medium"
                    >
                      View Items
                    </button>
                  </div>
                </div>
              )}
              
              {outOfStockCount > 0 && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                  <div className="flex items-center">
                    <ExclamationTriangleIcon className="h-5 w-5 text-red-400 mr-3" />
                    <div>
                      <h3 className="text-sm font-medium text-red-800">Out of Stock</h3>
                      <p className="text-red-700 text-sm">{outOfStockCount} items are out of stock</p>
                    </div>
                    <button
                      onClick={() => setStockFilter('out-of-stock')}
                      className="ml-auto text-red-700 hover:text-red-900 text-sm font-medium"
                    >
                      View Items
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Search and Filters */}
          <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
            <div className="flex flex-col sm:flex-row gap-4">
              {/* Search */}
              <div className="flex-1 relative">
                <MagnifyingGlassIcon className="h-5 w-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search items by name or SKU..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              </div>

              {/* Filter Toggle */}
              <button
                onClick={() => setShowFilters(!showFilters)}
                className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <FunnelIcon className="h-4 w-4 mr-2" />
                Filters
                {(categoryFilter || stockFilter !== 'all') && (
                  <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                    Active
                  </span>
                )}
              </button>

              {/* Export Button */}
              <button
                onClick={handleExport}
                className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <ArrowDownTrayIcon className="h-4 w-4 mr-2" />
                Export CSV
              </button>
            </div>

            {/* Filter Options */}
            {showFilters && (
              <div className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4 border-t">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
                  <select
                    value={categoryFilter}
                    onChange={(e) => setCategoryFilter(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="">All Categories</option>
                    {categories.map(category => (
                      <option key={category.id} value={category.id.toString()}>
                        {category.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Stock Status</label>
                  <select
                    value={stockFilter}
                    onChange={(e) => setStockFilter(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="all">All Items</option>
                    <option value="low-stock">Low Stock</option>
                    <option value="out-of-stock">Out of Stock</option>
                  </select>
                </div>

                <div className="flex items-end">
                  <button
                    onClick={clearFilters}
                    className="w-full px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 border border-gray-300 rounded-lg hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-gray-500"
                  >
                    Clear Filters
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Results Summary */}
          <div className="flex justify-between items-center mb-4">
            <p className="text-sm text-gray-700">
              Showing {filteredItems.length} of {items.length} items
            </p>
          </div>

          {/* Items Table */}
          <ItemTable
            items={filteredItems}
            categories={categories}
            suppliers={suppliers}
            onEdit={handleEdit}
            onDelete={handleDelete}
            loading={loading}
          />

          {/* Item Form Modal */}
          <ItemForm
            isOpen={isFormOpen}
            onClose={() => {
              setIsFormOpen(false);
              setEditingItem(null);
            }}
            onSubmit={handleFormSubmit}
            item={editingItem}
            categories={categories}
            suppliers={suppliers}
            loading={formLoading}
          />
        </div>
      </div>
    </>
  );
};

export default InventoryPage;