# Let me analyze the provided paste.txt file to find existing axios instances and API utilities
with open('paste.txt', 'r') as f:
    content = f.read()

# Look for axios related imports and configurations
lines = content.split('\n')
axios_related = []
api_related = []
utils_files = []

for i, line in enumerate(lines):
    if 'axios' in line.lower() or 'api' in line.lower():
        # Get some context around axios/api mentions
        start = max(0, i-2)
        end = min(len(lines), i+3)
        context = lines[start:end]
        axios_related.append(f"Line {i+1}: {' | '.join(context)}")
    
    if 'utils' in line.lower():
        utils_files.append(f"Line {i+1}: {line}")

print("AXIOS/API RELATED:")
for item in axios_related[:10]:  # Show first 10 matches
    print(item)
    
print("\nUTILS FILES:")
for item in utils_files[:5]:
    print(item)