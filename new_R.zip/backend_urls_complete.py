
# apps/staff/urls.py - Complete Staff Management URLs
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import StaffProfileViewSet, AttendanceViewSet
from . import views

router = DefaultRouter()
router.register(r'profiles', StaffProfileViewSet, basename='staff-profiles')
router.register(r'attendance', AttendanceViewSet, basename='staff-attendance')

urlpatterns = [
    path('', include(router.urls)),
]

# apps/tables/mobile_urls.py - Mobile Waiter URLs
from django.urls import path
from .views import get_tables_layout, create_waiter_order

urlpatterns = [
    path('tables_layout/', get_tables_layout, name='mobile-tables-layout'),
    path('create_order/', create_waiter_order, name='mobile-create-order'),
]

# apps/bills/enhanced_urls.py - Enhanced Billing URLs  
from django.urls import path
from .views import get_orders_ready_for_billing, generate_bill_from_order

enhanced_billing_urls = [
    path('orders_ready_for_billing/', get_orders_ready_for_billing, name='orders-ready-billing'),
    path('generate_bill_from_order/', generate_bill_from_order, name='generate-bill-from-order'),
]
